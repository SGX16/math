# A题支撑材料

本包与随附论文及其最新TeX对应。根目录的main.tex、各TeX子文件、code/、figures/和tables/保留论文排版与完整程序；AI工具使用情况见AI工具使用详情.pdf。AI_DETAILS.md仅是历史过程记录，不代表当前文件清单或当前验收状态。

## 结果文件

根目录result1.xlsx至result4.xlsx为无潜热基线；latent/中的四份同名文件为表面蒸发潜热条件扩展。二者不可混用。

- result1：1至1800 s，逐秒、每0.1 cm记录温度及干基含水率。
- result2：全过程逐秒、每0.1 cm温度及含水率，包含严格达标结束行；不止前3 h。
- result3：全过程每60 s及严格终点的含水率。
- result4：全过程每60 s及严格终点的含水率；当前域外位置为空，实际表面另列。

工作簿按四位小数导出；未舍入的指定截面与终点状态保留在机器记录中，严格判停在导出舍入前完成。显示0.1500不等于严格判停成立；临界时间、向上取整后的严格终点和全节点回代分别记录。两问八角点方案只针对声明的有限情景。

八份工作簿沿用逐单元等价检查通过的版本。XML仅压缩冗余地址和默认类型，未删时刻、单元格、数值、格式或域外空值；记录见results/workbook_equivalence.json。2026-09-13又对8组BDF和8组Radau生产轨道复算，但本次未重新导出全部Excel；本次运行保存在results/recheck_20260913/，workbooks_requested=false不可解释成导出过新工作簿。

## 官方输入与环境

按竞赛规范，包内不重复提交题目给出的原始附件。复现前，在data/下准备未经修改的两份工作簿：附件1命名为input1.xlsx，附件2命名为input2.xlsx。SHA-256必须分别为：

```text
input1.xlsx  7ef32870abeef420b89560b2530ff60dfe4255917805151d89988d0311af9dd7
input2.xlsx  5563acbfa4b4afb10cc6c03e2207e5369bf39da27576672aff14cc5c32e704af
```

数值环境锁定Python 3.12、NumPy 1.26.4、SciPy 1.13.1、openpyxl 3.1.5。安装依赖后，先在一个新的解压副本运行小网格检查：

```text
python -m pip install -r requirements-numerical.txt
python -X utf8 code/reproduce.py --mode smoke --out smoke_new
python -X utf8 -m unittest discover -s code -p test_revision.py -v
```

生产双模型从零复现：

```text
python -X utf8 code/reproduce_dual.py --out dual_new --workbooks
```

dual_new必须不存在。该入口不读取历史数值缓存；分别输出两种热边界的未舍入记录和完整工作簿。Q1--Q3采用1280区间，无潜热Q4采用2560区间，含潜热Q4采用1280区间。不同机器耗时可能不同；smoke不能替代生产结果。

## 双算法及表格复现

runs/cold_dual_20260912/output/保存已核对身份的BDF历史生产记录，supplement/algorithm_crosscheck/保存Radau配对记录及源哈希。恢复官方输入后，现有记录可以重新生成指定结果表：

```text
python -X utf8 code/answer_table_pairs.py --out table_rebuild
```

这一步是数表重建，不重新积分；数据行应与论文一致，排版微调由TeX负责。需要从零复算两种算法时，只将code/、requirements-numerical.txt和恢复后的data/放到一个全新的目录，再依次运行：

```text
python -X utf8 code/reproduce_dual.py --out runs/cold_dual_20260912/output
python -X utf8 code/algorithm_crosscheck.py --out supplement/algorithm_crosscheck
```

两个输出目录必须事先不存在。不能在带历史记录的当前副本中直接使用同一路径。BDF/Radau采用同一空间离散，吻合只支持时间积分一致性，不是独立物理实验验证。

## 扩展计算与制图

evidence/和supplement/保存论文使用的答案、模型比较、网格、冻结物性、端面、收支、参数扰动和情景结果。code/experiments.py、revision_experiments.py、time_sensitivity.py、pitfall_audit.py、latent_extension.py分别提供相应计算入口。部分历史试验采用存在即复用的缓存策略；重算时须使用新解压副本并将对应旧输出目录改名保留。程序参数和缓存行为以源代码为准。

为满足20 MB上限，不重复打包大型NPZ场缓存；完整结果工作簿和全部计算程序均保留。基线绘图缓存由以下入口重建：

```text
python -X utf8 code/rebuild_plot_cache.py --out plot_cache_new
```

将生成的inputs.npz、q1_fields.npz至q4_fields.npz放入evidence/，安装requirements.txt后重绘。新增定稿图脚本为：

```text
python -X utf8 code/refine_comparison_figures.py
python -X utf8 code/refine_q3_figures.py
python -X utf8 code/refine_final_figures.py
```

上述脚本读取冻结数据，不求解新的PDE；字体采用Times New Roman及SimSun，其他系统须安装字体。所有重绘操作应在工作副本执行，避免覆盖包内冻结图件。生成式机制图和问题二流程图原PNG随包保留，不承诺随机生图可逐像素复现。

总体路线及第一、三、四问流程由source_refinement.tex定义，问题二在main.tex直接装配现有图片；5张流程图的贴边圆角虚线框属于LaTeX排版。图题和引用不烘焙进图片。使用XeLaTeX连续编译main.tex至少两次，直到引用稳定；数学结果复现不依赖LaTeX。

## 文件索引与校验

FILE_LIST.csv列出每个内容文件的路径、大小和SHA-256；SHA256SUMS.txt覆盖内容文件及FILE_LIST.csv，自身不作自引用。解压后可执行：

```text
python packaging/verify_manifest.py
```

sources/保存合法获取的公开方法资料及书目信息。DOI元数据只能证明文献身份，不能替代原文对主张的支持。source_evidence性质、历史计算、新复算、AI检查和队员人工核验须分别理解。

本包不含承诺书、编号专用页、官方原始附件、用户名路径、编译缓存或依赖库目录。

2026-09-13，队员已逐条人工核对论文所列13条参考文献，确认文献真实存在、书目信息正确，原文支持正文对应的引用表述。核验结果由本队确认并负责，补充记录见results/recheck_20260913/team_reference_confirmation.json。此前记录中的“人工复核未完成”仅反映当时的进度，保留为历史记录，不代表本次确认后的状态。
