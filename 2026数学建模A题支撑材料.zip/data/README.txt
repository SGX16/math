Official input files are intentionally excluded. Restore attachments 1 and 2 as input1.xlsx and input2.xlsx here. Verify the SHA-256 values listed in the root README before running.
