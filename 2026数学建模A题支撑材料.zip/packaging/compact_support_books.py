"""Lossless cell-content compaction of generated, dense OOXML sheets."""
import hashlib
import json
from pathlib import Path
import shutil
import xml.sax
from xml.sax.saxutils import XMLGenerator
from xml.sax.xmlreader import AttributesImpl
import zipfile

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT/'runs/cold_dual_20260912/output'
OUT = ROOT/'deliverables/support_compact_20260912'


class DenseSheet(XMLGenerator):
    def __init__(self, stream):
        super().__init__(stream, encoding='utf-8', short_empty_elements=True)
        self.row = 0
        self.col = 0

    def startElement(self, name, attrs):
        attrs = dict(attrs)
        if name == 'row':
            self.row = int(attrs['r'])
            self.col = 0
        if name == 'c':
            self.col += 1
            letters = ''
            n = self.col
            while n:
                n, rem = divmod(n-1, 26)
                letters = chr(65+rem)+letters
            assert attrs['r'] == f'{letters}{self.row}', 'Non-dense input'
            # The implicit next column is equivalent in these dense rows.
            if self.col > 1 and self.row > 1:
                attrs.pop('r')
            if attrs.get('t') == 'n':
                attrs.pop('t')
        super().startElement(name, AttributesImpl(attrs))


def main():
    OUT.mkdir(exist_ok=True)
    records = []
    for family in ('baseline', 'latent'):
        for q in range(1, 5):
            src = SOURCE/family/f'result{q}.xlsx'
            dest = OUT/('' if family == 'baseline' else 'latent')/src.name
            dest.parent.mkdir(exist_ok=True)
            if dest.exists() and zipfile.is_zipfile(dest):
                with zipfile.ZipFile(dest) as existing:
                    assert existing.testzip() is None
                records.append(dict(file=dest.relative_to(OUT).as_posix(), bytes=dest.stat().st_size))
                print(f'RESUME verified complete container {family} Q{q}', flush=True)
                continue
            with zipfile.ZipFile(src) as z, zipfile.ZipFile(dest, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as out:
                for name in z.namelist():
                    if name.startswith('xl/worksheets/sheet') and name.endswith('.xml'):
                        with z.open(name) as a, out.open(name, 'w') as b:
                            parser = xml.sax.make_parser()
                            parser.setFeature(xml.sax.handler.feature_external_ges, False)
                            parser.setContentHandler(DenseSheet(b))
                            parser.parse(a)
                    else:
                        out.writestr(name, z.read(name))
            records.append(dict(file=dest.relative_to(OUT).as_posix(), bytes=dest.stat().st_size))
            print(f'COMPACT {family} Q{q}: {dest.stat().st_size}', flush=True)
    (ROOT/'audit/SUPPORT_COMPACT_SIZES.json').write_text(json.dumps(records, indent=2), encoding='utf-8')


if __name__ == '__main__':
    main()
