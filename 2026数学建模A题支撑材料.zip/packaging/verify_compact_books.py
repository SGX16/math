"""Compare every cell value, position and style using a streaming XML parser."""
import hashlib
import json
from pathlib import Path
import xml.sax
import zipfile

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT/'runs/cold_dual_20260912/output'
TARGET = ROOT/'deliverables/support_compact_20260912'


class Cells(xml.sax.ContentHandler):
    def __init__(self):
        self.hash = hashlib.sha256()
        self.count = 0
        self.row = 0
        self.col = 0
        self.active = False
        self.cell = None

    def startElement(self, name, attrs):
        if name == 'row':
            self.row = int(attrs['r'])
            self.col = 0
        elif name == 'c':
            self.col += 1
            attrs = dict(attrs)
            ref = attrs.pop('r', None)
            if ref:
                letters = ''.join(c for c in ref if c.isalpha())
                n = 0
                for c in letters:
                    n = n*26+ord(c)-64
                assert n == self.col
                assert int(ref[len(letters):]) == self.row
            attrs.setdefault('t', 'n')
            self.cell = [self.row, self.col, sorted(attrs.items()), []]
        elif self.cell is not None:
            self.cell[3].append(['start', name, sorted(dict(attrs).items())])
            self.active = True

    def characters(self, text):
        if self.active and self.cell is not None:
            if self.cell[3] and self.cell[3][-1][0] == 'text':
                self.cell[3][-1][1] += text
            else:
                self.cell[3].append(['text', text])

    def endElement(self, name):
        if name == 'c':
            self.hash.update(json.dumps(self.cell, ensure_ascii=False, separators=(',', ':')).encode())
            self.count += 1
            self.cell = None
            self.active = False
        elif self.cell is not None:
            self.cell[3].append(['end', name])


def sheet_digest(z, name):
    handler = Cells()
    parser = xml.sax.make_parser()
    parser.setFeature(xml.sax.handler.feature_external_ges, False)
    parser.setContentHandler(handler)
    with z.open(name) as stream:
        parser.parse(stream)
    return dict(cells=handler.count, rows=handler.row, sha256=handler.hash.hexdigest())


def main():
    records = []
    for family in ('baseline', 'latent'):
        for q in range(1, 5):
            src = SOURCE/family/f'result{q}.xlsx'
            dest = TARGET/('' if family == 'baseline' else 'latent')/src.name
            record = dict(file=dest.relative_to(TARGET).as_posix(), sheets={})
            with zipfile.ZipFile(src) as a, zipfile.ZipFile(dest) as b:
                assert a.namelist() == b.namelist()
                assert b.testzip() is None
                for name in a.namelist():
                    if name.startswith('xl/worksheets/sheet') and name.endswith('.xml'):
                        da, db = sheet_digest(a, name), sheet_digest(b, name)
                        assert da == db, (record['file'], name, da, db)
                        record['sheets'][name] = da
                    else:
                        assert a.read(name) == b.read(name), name
            record.update(ready=True, sha256=hashlib.sha256(dest.read_bytes()).hexdigest(),
                          original_sha256=hashlib.sha256(src.read_bytes()).hexdigest())
            records.append(record)
            print(f'PASS all cells/styles/positions: {family} Q{q}', flush=True)
    (ROOT/'audit/SUPPORT_CELL_EQUIVALENCE.json').write_text(json.dumps(dict(
        ready=True, scope='All cell values, types, formats, coordinates; all non-sheet parts identical',
        books=records), ensure_ascii=False, indent=2), encoding='utf-8')


if __name__ == '__main__':
    main()
