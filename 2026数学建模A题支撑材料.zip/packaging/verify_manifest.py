"""Read-only verification of a support archive after extraction."""
import hashlib
from pathlib import Path
import sys

root = Path(__file__).resolve().parents[1]
failed = []
records = (root / 'SHA256SUMS.txt').read_text(encoding='utf-8-sig').splitlines()
for row in records:
    expected, relative = row.split('  ', 1)
    target = (root / relative).resolve()
    if not target.is_relative_to(root) or not target.is_file():
        failed.append(relative + ': missing or unsafe')
        continue
    actual = hashlib.sha256(target.read_bytes()).hexdigest()
    if actual != expected:
        failed.append(relative + ': SHA-256 differs')
for item in failed:
    print('FAIL', item)
print(f'Checked {len(records)} files; failures={len(failed)}')
sys.exit(1 if failed else 0)
