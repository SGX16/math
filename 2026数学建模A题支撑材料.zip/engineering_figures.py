"""Editable engineering diagrams; no textures, generated images or measured pores."""
from pathlib import Path
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, Circle, Polygon, FancyArrowPatch

ROOT = Path(__file__).resolve().parent
FIG = ROOT / 'figures'
plt.rcParams.update({'font.family':'sans-serif', 'font.sans-serif':['Microsoft YaHei'],
    'font.size':9, 'svg.fonttype':'none', 'pdf.fonttype':42,
    'axes.unicode_minus':False, 'lines.linewidth':.8})
INK='#252B30'; BLUE='#286378'; GRAY='#79848B'


def canvas(h):
    fig=plt.figure(figsize=(155/25.4,h/25.4))
    ax=fig.add_axes([0,0,1,1],xlim=(0,155),ylim=(0,h))
    ax.axis('off')
    return fig,ax


def save(fig,name):
    fig.savefig(FIG/f'{name}.svg',facecolor='white')
    fig.savefig(FIG/f'{name}.pdf',facecolor='white')
    fig.savefig(FIG/f'{name}.png',dpi=450,facecolor='white')
    plt.close(fig)


def label(ax,x,y,s,size=9,align='center',color=INK):
    ax.text(x,y,s,fontsize=size,ha=align,va='center',color=color,linespacing=1.45)


def node(ax,x,y,w,h,s,accent=False):
    ax.add_patch(Rectangle((x,y),w,h,ec=BLUE if accent else INK,
        fc='#EEF4F6' if accent else 'white',lw=.8))
    label(ax,x+w/2,y+h/2,s)


def edge(ax,points,s=None,at=None):
    xx,yy=zip(*points)
    ax.plot(xx,yy,color=GRAY,lw=.85)
    ax.add_patch(FancyArrowPatch(points[-2],points[-1],arrowstyle='-|>',
        mutation_scale=8,lw=.85,color=GRAY,shrinkA=0,shrinkB=0))
    if s: label(ax,*at,s,8,color=INK)


def dim(ax,a,b,s,offset=(0,2)):
    ax.annotate('',xy=b,xytext=a,arrowprops={'arrowstyle':'<->','lw':.65,'color':INK})
    label(ax,(a[0]+b[0])/2+offset[0],(a[1]+b[1])/2+offset[1],s,8)


def mechanisms():
    fig,ax=canvas(72)
    for x in (52,104): ax.plot([x,x],[9,67],color='#CED3D5',lw=.5)
    label(ax,26,66,'(a) 纵剖面：表面交换')
    ax.add_patch(Rectangle((8,27),36,17,fc='white',ec=INK,hatch='///',lw=1))
    ax.plot([4,48],[35.5,35.5],color=GRAY,ls='-.',lw=.7)
    for x in (13,26,39):
        edge(ax,[(x,56),(x,45)])
        edge(ax,[(x,26),(x,17)])
    label(ax,26,60,'热量进入：h(Ta − Ts)',8)
    label(ax,26,12,'水分外迁：hm(Cs − Ca)',8)
    label(ax,78,66,'(b) 横截面：径向扩散')
    ax.add_patch(Circle((78,36),18,fill=False,ec=INK,lw=1))
    ax.add_patch(Circle((78,36),10,fill=False,ec=GRAY,lw=.6,ls='--'))
    ax.plot([55,101],[36,36],color=GRAY,ls='-.',lw=.6)
    ax.plot([78,78],[13,59],color=GRAY,ls='-.',lw=.6)
    for angle in (45,135,225,315):
        a=np.deg2rad(angle); d=np.array([np.cos(a),np.sin(a)])
        edge(ax,[np.array([78,36])+11*d,np.array([78,36])+22*d])
    dim(ax,(78,36),(96,36),'R',(0,3))
    label(ax,78,9,'虚线为示意等半径线',8)
    label(ax,130,66,'(c) 均匀收缩：物质映射')
    ax.add_patch(Circle((130,36),19,fill=False,ec=GRAY,ls='--',lw=.8))
    ax.add_patch(Circle((130,36),11.4,fill=False,ec=INK,lw=1))
    ax.plot([107,151],[36,36],color=GRAY,ls='-.',lw=.6)
    for a in (35,145,215,325):
        d=np.array([np.cos(np.deg2rad(a)),np.sin(np.deg2rad(a))])
        edge(ax,[np.array([130,36])+18*d,np.array([130,36])+12*d])
    label(ax,130,60,'虚线 R(0)；实线 R(t)',8)
    label(ax,130,9,'同一物质点：r = ηR(t)',8)
    save(fig,'mechanism_engineering')

    fig,ax=canvas(59)
    label(ax,52,53,'A—A 纵剖面')
    ax.add_patch(Rectangle((7,21),90,18,fc='white',ec=INK,hatch='///',lw=1))
    ax.plot([3,102],[30,30],color=GRAY,ls='-.',lw=.6)
    ax.plot([7,7],[10,20],color=GRAY,lw=.6)
    ax.plot([97,97],[10,20],color=GRAY,lw=.6)
    dim(ax,(7,12),(97,12),'L = 250 mm')
    label(ax,126,53,'端视图')
    ax.add_patch(Circle((126,30),16,fill=False,ec=INK,lw=1))
    ax.plot([106,146],[30,30],color=GRAY,ls='-.',lw=.6)
    ax.plot([126,126],[10,50],color=GRAY,ls='-.',lw=.6)
    dim(ax,(126,30),(142,30),r'$R_0$ = 20 mm',(-8,-7))
    label(ax,77.5,4,'斜线表示剖切到的实体；纵剖面径向已放大，标注尺寸为准。',8)
    save(fig,'cylinder_engineering')
    # CAD source uses true millimetres; PDF presentation exaggerates radial scale.
    # Minimal ASCII DXF: simple editable LINE/CIRCLE/TEXT entities, in mm.
    pairs=[(0,'SECTION'),(2,'HEADER'),(9,'$ACADVER'),(1,'AC1009'),
           (0,'ENDSEC'),(0,'SECTION'),(2,'ENTITIES')]
    def line(p,q,layer='OUTLINE'):
        pairs.extend([(0,'LINE'),(8,layer),(10,p[0]),(20,p[1]),(30,0),
                      (11,q[0]),(21,q[1]),(31,0)])
    pts=[(0,0),(250,0),(250,40),(0,40),(0,0)]
    for p,q in zip(pts[:-1],pts[1:]): line(p,q)
    pairs.extend([(0,'CIRCLE'),(8,'OUTLINE'),(10,310),(20,20),(30,0),(40,20)])
    for p,q in [((-10,20),(260,20)),((280,20),(340,20)),((310,-10),(310,50))]:
        line(p,q,'CENTER')
    for x in range(-40,251,8):
        a=max(0,-x);b=min(40,250-x)
        if b>a: line((x+a,a),(x+b,b),'SECTION')
    for p,q in [((0,-15),(250,-15)),((0,-18),(0,-2)),((250,-18),(250,-2))]:
        line(p,q,'DIMENSION')
    for x,y,s in [(85,-12,'L = 250 mm'),(285,48,'R0 = 20 mm'),(0,52,'LONGITUDINAL SECTION - SOLID CYLINDER')]:
        pairs.extend([(0,'TEXT'),(8,'DIMENSION'),(10,x),(20,y),(30,0),(40,4),(1,s)])
    pairs.extend([(0,'ENDSEC'),(0,'EOF')])
    (FIG/'cylinder_engineering.dxf').write_text(''.join(f'{k}\n{v}\n' for k,v in pairs),encoding='ascii')


def overview():
    fig,ax=canvas(135)
    node(ax,12,119,131,12,'环境观测、均匀初态与圆柱几何：共同输入',True)
    edge(ax,[(38,119),(38,109)])
    edge(ax,[(111,119),(111,109)])
    node(ax,6,91,64,18,'问题一 / 附录2\n定热物性，0—1800 s')
    node(ax,85,91,64,18,'问题二 / 附录3\n统一变物性，从 t = 0 重算')
    edge(ax,[(38,91),(38,81)])
    node(ax,6,66,64,15,'七时刻截面、逐秒输出\n端面与集中参数对照')
    edge(ax,[(117,91),(117,81)],'同一动力系统',(97,86))
    node(ax,85,63,64,18,'问题三 / 全域阈值\n事件定位与严格停机')
    edge(ax,[(117,63),(117,51)])
    node(ax,85,33,64,18,'名义时间与八情景回代\n输出全程状态')
    node(ax,6,33,64,22,'问题四 / 附录4 + 半径观测\n干基守恒 → 物质坐标\n独立求解收缩过程',True)
    edge(ax,[(12,124),(2,124),(2,44),(6,44)])
    edge(ax,[(38,33),(38,22)])
    edge(ax,[(117,33),(117,22)])
    node(ax,6,4,143,18,'同口径核验：网格与收支 / 物性×几何对照 / 有限情景约束\n输出逐问答案、工作簿和可复现程序',True)
    label(ax,37,59,'问题一末态不传入问题二',8)
    save(fig,'overview')


def q1():
    fig,ax=canvas(80)
    node(ax,3,58,32,18,'几何与初态\n附录2、环境')
    node(ax,48,59,46,17,'热量支路\n显热容量 + 导热通量')
    node(ax,48,32,46,17,'水分支路\n干基容量 + 状态积分')
    edge(ax,[(35,67),(48,67)])
    edge(ax,[(35,67),(41,67),(41,40),(48,40)])
    node(ax,109,32,43,44,'共同环形网格\n中心正则\n表面交换\nBDF 联立积分',True)
    edge(ax,[(94,67),(109,67)])
    edge(ax,[(94,40),(109,40)])
    node(ax,3,4,68,18,'物理检验：端面 / 集中参数\n数值检验：收支 / 网格 / 扰动')
    node(ax,87,4,65,18,'T(r,t)、C(r,t)\n七个截面时刻 + 逐秒工作簿',True)
    edge(ax,[(130,32),(130,22)])
    edge(ax,[(87,13),(71,13)])
    label(ax,19,42,'输入分流，\n状态联立求解',8)
    save(fig,'q1_flow')


def q2():
    fig,ax=canvas(88)
    node(ax,32,73,91,11,'附录3统一适用；从 28 ℃、2.55 kg/kg 初始化',True)
    node(ax,6,45,45,17,'含水率 C\n更新 ρ(C)、cp(C)、k(C)')
    node(ax,103,45,45,17,'温度 T\n更新 D(C,T)')
    edge(ax,[(32,78),(28,78),(28,62)])
    edge(ax,[(123,78),(125,78),(125,62)])
    edge(ax,[(51,57),(103,57)],'热方程的系数',(77,61))
    edge(ax,[(103,49),(51,49)],'水分方程的系数',(77,45))
    node(ax,31,21,94,14,'稀疏半离散系统：联立更新 [T, C]\n状态积分通量 + 自适应刚性积分',True)
    edge(ax,[(28,45),(28,28),(31,28)])
    edge(ax,[(125,45),(135,45),(135,28),(125,28)])
    node(ax,6,1,65,11,'0.5—3 h 截面：题问表格')
    node(ax,84,1,64,11,'全程轨迹：第三问继续判停')
    edge(ax,[(53,21),(53,12)])
    edge(ax,[(108,21),(108,12)])
    save(fig,'q2_flow')


def q3():
    fig,ax=canvas(112)
    node(ax,34,97,87,11,'第二问动力系统 + 0.15 kg/kg 阈值',True)
    node(ax,34,76,87,11,'推进状态，计算全节点最大含水率')
    edge(ax,[(77,97),(77,87)])
    ax.add_patch(Polygon([(77,69),(105,58),(77,47),(49,58)],fc='white',ec=INK,lw=.8))
    label(ax,77,58,'首次向下穿越阈值？',9)
    edge(ax,[(77,76),(77,69)])
    edge(ax,[(49,58),(11,58),(11,81),(34,81)],'否：继续',(25,63))
    edge(ax,[(77,47),(77,38)],'是',(85,42))
    node(ax,34,23,87,15,'连续输出定位临界根\n续算 5 s，时间向上舍入')
    edge(ax,[(77,23),(77,13)])
    node(ax,34,1,87,12,'未舍入全域严格检查 → 名义停机',True)
    edge(ax,[(121,7),(139,7),(139,23)],None)
    label(ax,139,32,'检查失败\n报错退出',8)
    label(ax,18,26,'独立扩展\n八角点在\n统一时刻\n逐一回代',8)
    save(fig,'q3_flow')


def q4():
    fig,ax=canvas(105)
    node(ax,3,85,59,15,'干物质连续性\n水分相对扩散连续性')
    node(ax,82,85,70,15,'附件2：R(t) 保形插值\n附录4：独立经验物性')
    edge(ax,[(62,92),(72,92),(72,76)])
    edge(ax,[(117,85),(117,76)])
    node(ax,19,61,133,15,'随固体坐标 η = r/R(t)\n相消坐标输运，保留扩散与边界收支',True)
    edge(ax,[(85,61),(85,51)])
    node(ax,19,39,133,12,'固定 η 网格求解 → 全域判停 → 域外掩膜与实际表面')
    edge(ax,[(85,39),(85,32)])
    label(ax,79,28,'控制变量对照：物性 × 几何',9)
    for x in (42,97,152): ax.plot([x,x],[1,23],color=GRAY,lw=.6)
    for y in (1,12,23): ax.plot([42,152],[y,y],color=GRAY,lw=.6)
    label(ax,69,18,'附录3 / 固定半径',8)
    label(ax,125,18,'附录3 / 收缩半径',8)
    label(ax,69,6,'附录4 / 固定半径',8)
    label(ax,125,6,'附录4 / 收缩半径',8)
    label(ax,20,12,'同物性比较\n分离几何效应',8)
    save(fig,'q4_flow')


if __name__=='__main__':
    FIG.mkdir(exist_ok=True)
    mechanisms(); overview(); q1(); q2(); q3(); q4()
    print(json.dumps({'figures':7,'cad_units':'mm','raster_dpi':450,
        'mechanism':'orthographic structural schematic, not measured pores'}))
