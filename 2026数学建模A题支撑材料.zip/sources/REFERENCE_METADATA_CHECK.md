# 参考文献扩充与核验记录

核验日期：2026-09-12。对象：本工程main.tex。原6条官方在线资料保留，新增6篇期刊论文，合计12条。本轮不编译、不生成PDF，不重算或改写数值。

## 核验方法与边界

新增6条均实际请求Crossref `/works/{DOI}`，逐项核对作者顺序、题名、期刊、出版年份、卷期和页码；另以出版方页面或NIST官方出版清单交叉核对。ScienceDirect和Nature部分直接打开返回错误时，以其检索返回的出版方正文片段与Crossref互证，不以第三方转引作为唯一依据。

内容依据为本轮可访问的出版方摘要、页面片段及官方软件说明，未声称取得并精读所有付费全文。真实存在不等于支持本题全部模型，更不验证本题数值。旧6条官方网页已于前一轮逐一打开，本轮保留其原文与适用范围，不冒称再次全部访问。

## 新增书目

| 引用键 | Crossref与出版方一致的书目信息 | DOI | 正文用途 |
|---|---|---|---|
| datta2007 | Datta A K. Porous media approaches to studying simultaneous heat and mass transfer in food processes. I: Problem formulations. Journal of Food Engineering, 2007, 80(1): 80-95 | 10.1016/j.jfoodeng.2006.05.013 | 问题分析：区分多相输运与有效扩散简化，说明未求解气相压力和内部相变 |
| mayor2004 | Mayor L, Sereno A M. Modelling shrinkage during convective drying of food materials: a review. Journal of Food Engineering, 2004, 61(3): 373-386 | 10.1016/S0260-8774(03)00144-4 | 第四问：说明收缩模型类别及给定半径历程的建模边界 |
| fritsch1984 | Fritsch F N, Butland J. A method for constructing local monotone piecewise cubic interpolants. SIAM Journal on Scientific and Statistical Computing, 1984, 5(2): 300-304 | 10.1137/0905021 | 输入插值：补充PCHIP原始方法出处，明确禁止外推为本题策略 |
| guyer2009 | Guyer J E, Wheeler D, Warren J A. FiPy: Partial differential equations with Python. Computing in Science & Engineering, 2009, 11(3): 6-15 | 10.1109/MCSE.2009.52 | 有限体积：方法背景，明确没有调用FiPy软件求解 |
| shampine1997 | Shampine L F, Reichelt M W. The MATLAB ODE suite. SIAM Journal on Scientific Computing, 1997, 18(1): 1-22 | 10.1137/S1064827594276424 | 第二问：SciPy文档引用的刚性ODE方法背景，不假称MATLAB独立复算 |
| scipy2020 | Virtanen P, Gommers R, Oliphant T E, et al. SciPy 1.0: fundamental algorithms for scientific computing in Python. Nature Methods, 2020, 17(3): 261-272 | 10.1038/s41592-019-0686-2 | 复现附录：软件总述，运行版本仍为原锁定版本 |

日期核对：Fritsch论文按1984年卷期引用，不误用2006年数字上线时间；Shampine论文为1997年，不误用2006年网页上线时间；Datta论文为2007年、Mayor论文为2004年、SciPy论文为2020年，不从DOI内的年份字段推断出版年。

## 官方交叉来源

- https://www.sciencedirect.com/science/article/pii/S0260877406003980
- https://www.sciencedirect.com/science/article/abs/pii/S0260877403001444
- https://epubs.siam.org/doi/10.1137/0905021
- https://pages.nist.gov/fipy/en/stable/PUBLICATIONS.html
- https://epubs.siam.org/doi/abs/10.1137/S1064827594276424
- https://www.nature.com/articles/s41592-019-0686-2
- Crossref API：https://api.crossref.org/works/ 后接表中URL编码的DOI。

## 源级验证

递归读取40个活动TeX文件，12条书目全部被引用；未引用条目0，未定义引用键0，重复书目键0。main.tex所有equation/align环境与修改前逐字一致，四处“由此本题的直接答案是”至FloatBarrier答案块逐字一致。thebibliography标签宽度从9改为99以适应两位编号。未新增拟合参数或修改模型。

main.tex SHA256：EADE3A05D89B991818C65B3C412C28DDE09B4AC5291855A718FDE19E7F650441。

本记录不是完整引用发布门或PDF验收，历史SYNC_CHECK不覆盖本轮修改后的主稿哈希。实际分页、引用换行和全页版式待用户编译后检查。

## Skill使用范围

本轮完整读取nature-ref-verifier的方法部分并执行多源元数据与引用用途核对；沿用已读cite-verify的DOI身份核查原则，通过PowerShell直接请求Crossref，未运行其Bash linter。四核心数模Skill入口此前已读，本轮仅按局部文献编辑范围保持结果锁、不越界宣称技术验证，并执行引用键静态检查；未重新执行四Skill完整建模、赛事规则审查或整稿评分。未调用nature-figure或nature-statistics。
