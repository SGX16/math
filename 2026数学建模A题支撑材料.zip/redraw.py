"""Assemble locked numerical evidence; never compile TeX or modify S2."""
from pathlib import Path
import hashlib
import json
import shutil
import sys
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap
from matplotlib.patches import FancyArrowPatch, Rectangle

HERE = Path(__file__).resolve().parent
PROJECT = HERE
TEX = HERE
DATA = TEX/'evidence'
FIG = TEX/'figures'
AUDIT = HERE/'redraw_audit'
for p in (TEX, DATA, FIG, TEX/'tables', TEX/'code', TEX/'data', AUDIT):
    p.mkdir(parents=True, exist_ok=True)

plt.rcParams.update({'font.family':'sans-serif', 'font.sans-serif':['Microsoft YaHei','Arial','DejaVu Sans'],
    'font.size':8.5, 'axes.labelsize':8.5, 'xtick.labelsize':8, 'ytick.labelsize':8,
    'axes.spines.top':False, 'axes.spines.right':False, 'axes.linewidth':.7,
    'legend.frameon':False, 'legend.fontsize':8, 'svg.fonttype':'none',
    'axes.unicode_minus':False, 'savefig.dpi':360})
BLUE, GREEN, RED, GOLD, GREY = '#2C4A7C','#3E7D5A','#C65353','#B9852D','#66717E'
CMAP = LinearSegmentedColormap.from_list('moisture', ['#fbfcfc','#b7d4cd','#408477','#214b5b'])
HEAT = LinearSegmentedColormap.from_list('heat', ['#f7fbfd','#a4c4da','#4b7c9f','#873b3b'])
identities = {}
figures = []
def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()
def copy(source, target):
    shutil.copy2(source,target)
    identities[str(source.relative_to(PROJECT)) if source.is_relative_to(PROJECT) else source.name] = sha(source)
def write_json(p, obj):
    p.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding='utf8')
def save(fig, name, source, role='main'):
    fig.savefig(FIG/f'{name}.svg')
    fig.savefig(FIG/f'{name}.png', dpi=360)
    fig.canvas.draw()
    figures.append(dict(id=name,source=source,role=role,width_mm=float(fig.get_figwidth()*25.4),
        height_mm=float(fig.get_figheight()*25.4),dpi=360,png_sha256=sha(FIG/f'{name}.png')))
    plt.close(fig)
def grid(ax):
    ax.grid(axis='y', color='#e4e7e9', lw=.5)
    ax.set_axisbelow(True)
def box(ax, x,y,w,h, label, color=BLUE):
    ax.add_patch(Rectangle((x,y),w,h,facecolor='#f5f8f9',edgecolor=color,lw=1))
    ax.text(x+w/2,y+h/2,label,ha='center',va='center',fontsize=8.5,linespacing=1.55)
def arrow(ax, a,b, label=None):
    ax.add_patch(FancyArrowPatch(a,b,arrowstyle='-|>',mutation_scale=11,lw=1,color=GREY))
    if label:
        ax.text((a[0]+b[0])/2,(a[1]+b[1])/2+.03,label,ha='center',fontsize=8,color=GREY)

answers = json.loads((DATA/'answers.json').read_text(encoding='utf8'))
summary = json.loads((DATA/'improvement.json').read_text(encoding='utf8'))
with np.load(DATA/'inputs.npz') as source:
    env, radius = source['environment'], source['radius']
write_json(DATA/'input_statistics.json',dict(environment_rows=len(env),radius_rows=len(radius),
    tail_mean=env[env[:,0]>=10800,1:].mean(axis=0).tolist(),missing=0,removed=0))

fields = {}
for a in answers:
    q=a['question']
    fields[q] = dict(np.load(DATA/f'q{q}_fields.npz'))
    # Q4 physical positions outside the current body remain empty, never zero.
    for kind in (['temperature_C','moisture'] if q<=2 else ['moisture']):
        cap = ('温度（$^\\circ$C）' if kind=='temperature_C' else '干基含水率（kg/kg）')
        rows=[r'\begin{coretable}[htbp]\centering\small',
            f'\\caption{{问题{q}指定时刻与径向位置的{cap}：无潜热基线}}\\label{{tab:q{q}-{kind}}}',
            r'\begin{tabular}{r'+'r'*(6 if q==4 else 5)+r'}\toprule',
            ('时间/s' if q==1 else '时间/h')+r' & 0 cm & 0.5 cm & 1 cm & 1.5 cm & 2 cm'+(r' & 实际表面' if q==4 else '')+r'\\\midrule']
        for r in a['table_rows']:
            vals=r[kind][:6 if q==4 else 5]
            t=r['time_s']/(1 if q==1 else 3600)
            rows.append(f'{t:.0f}' if q==1 else f'{t:.4f}')
            rows[-1] += ' & '+' & '.join(r'\textemdash' if x is None else f'{x:.4f}' for x in vals)+r'\\'
        rows.extend([r'\bottomrule\end{tabular}',r'\end{coretable}'])
        (TEX/'tables'/f'q{q}_{kind}.tex').write_text('\n'.join(rows),encoding='utf8')
    rows=[r'\begin{table}[htbp]\centering\small',
        f'\\caption{{问题{q}同为160区间的数值方法比较}}\\label{{tab:ablation{q}}}',
        r'\begin{tabular}{lrrrr}\toprule 方法 & $E_T$/K & $E_C$/(kg/kg) & $E_t$/s & 耗时/s\\\midrule']
    for i,v in enumerate(summary['comparisons'][str(q)]):
        event='不适用' if v['event_error_s'] is None else f"{v['event_error_s']:.4f}"
        rows.append(f"M{i} & {v['max_T_error_C']:.3e} & {v['max_C_error']:.3e} & {event} & {v['elapsed_s']:.2f}"+r'\\')
    rows += [r'\bottomrule\end{tabular}',r'\end{table}']
    (TEX/'tables'/f'q{q}_ablation.tex').write_text('\n'.join(rows),encoding='utf8')

sys.path.insert(0, str(HERE/'code'))
from answer_table_pairs import write_pairs
write_pairs(HERE, baseline_only=True)

fig,axs=plt.subplots(1,3,figsize=(155/25.4,65/25.4),layout='constrained')
for ax,y,label,col in [(axs[0],1,'烘房温度 / °C',RED),(axs[1],2,'有效环境水分 / (kg/kg)',GREEN)]:
    ax.plot(env[:,0]/3600,env[:,y],color=col,lw=1.3)
    ax.set(xlabel='时间 / h',ylabel=label,xlim=(0,4)); grid(ax)
axs[2].plot(radius[:,0]/3600,radius[:,1],color=BLUE,lw=1.3)
axs[2].set(xlabel='时间 / h',ylabel='药材半径 / cm'); grid(axs[2])
save(fig,'environment','inputs.npz; all original observations')

fig,ax=plt.subplots(figsize=(155/25.4,88/25.4))
ax.set(xlim=(0,1),ylim=(0,1));ax.axis('off')
box(ax,.02,.77,.96,.18,'附件1：温湿环境  ·  附件2：收缩半径  ·  附录2/3/4：分别给定物性')
for x,lab in [(.02,'问题一\n附录2，固定半径\n0–1800 s'),(.36,'问题二 / 三\n附录3，同一动力系统\n全过程 + 最大值判停'),(.70,'问题四\n附录4，物质坐标\n半径变化 + 最大值判停')]:
    box(ax,x,.42,.28,.23,lab)
    arrow(ax,(x+.14,.77),(x+.14,.65))
box(ax,.02,.06,.96,.22,'统一计算：守恒通量 + 稳定状态积分 + 表面加密 + BDF\n逐问检验：基线对照 / 全场网格 / 干基账本 / 严格阈值\n下游：有限情景停机回代；物性 × 几何归因；端面导热诊断',GREEN)
for x in (.16,.50,.84):arrow(ax,(x,.42),(x,.28))
fig.subplots_adjust(left=.01,right=.99,top=.98,bottom=.02)
save(fig,'overview','STAGE_AUTHORIZATION.md; frozen dependency graph')

flows={
1:['Step 1\n附录2初始化\n两场均匀初值','Step 2\n柱坐标控制体\nRobin边界','Step 3\n薄层加密\n刚性积分','Step 4\n逐秒导出\n显热/水量核对'],
2:['Step 1\n重新从t=0开始\n附录3变物性','Step 2\n温湿耦合\n状态积分通量','Step 3\n全程推进\n前3h截面','Step 4\n全程逐秒回读\n双网格比较'],
3:['Step 1\n继承Q2动力系统\n各处C<0.15','Step 2\n全空间最大值\n向下过零事件','Step 3\n加5s后向上舍入\n名义严格停机','Step 4\n8个联合角点\n统一停机回代'],
4:['Step 1\n附录4 + R(t)\n干基量定义','Step 2\n固相连续性\n物质坐标抵消','Step 3\n变域高精度求解\n实际表面采样','Step 4\n干基账本\n物性×几何消融']}
for q,labels in flows.items():
    fig,ax=plt.subplots(figsize=(155/25.4,38/25.4)); ax.axis('off');ax.set(xlim=(0,1),ylim=(0,1))
    for i,lab in enumerate(labels):
        x=.015+i*.252;box(ax,x,.18,.215,.64,lab,GREEN if i==3 else BLUE)
        if i<3:arrow(ax,(x+.215,.5),(x+.252,.5))
    fig.subplots_adjust(left=0,right=1,top=1,bottom=0)
    save(fig,f'q{q}_flow','frozen model and actual S2 steps')

for q in (1,2):
    d=fields[q];t=d['times_s']/(1 if q==1 else 3600)
    fig,axs=plt.subplots(1,2,figsize=(155/25.4,70/25.4),layout='constrained')
    for ax,key,cmap,lab in [(axs[0],'T_xi',HEAT,'温度 / °C'),(axs[1],'C_xi',CMAP,'含水率 / (kg/kg)')]:
        im=ax.pcolormesh(t,2*d['xi'],d[key].T,shading='auto',cmap=cmap,rasterized=True)
        cb=fig.colorbar(im,ax=ax,pad=.025);cb.set_label(lab)
        ax.set(xlabel='时间 / '+('s' if q==1 else 'h'),ylabel='半径 / cm')
    save(fig,f'q{q}_fields',f'q{q}_fields.npz; all stored time and xi nodes')

d=fields[3];t=d['times_s']/3600
fig,axs=plt.subplots(1,2,figsize=(155/25.4,72/25.4),layout='constrained')
for i,(col,ls) in enumerate(zip([BLUE,GREY,GOLD,GREEN,RED],['-','--','-.',':','-'])):
    j=i*25
    for ax in axs:ax.plot(t,d['C_xi'][:,j],color=col,ls=ls,lw=1.35 if i in (0,4) else .95,label=f'{i*.5:g} cm')
for ax in axs:
    ax.axhline(.15,color='#242a30',lw=.8,ls='--');ax.set(xlabel='时间 / h',ylabel='含水率 / (kg/kg)');grid(ax)
axs[0].set(xlim=(0,t[-1]),ylim=(0,2.6));axs[0].legend(ncol=2,loc='upper right')
axs[1].set(xlim=(30,t[-1]),ylim=(.045,.23))
axs[1].annotate('中心最后达标',xy=(t[-1],d['C_xi'][-1,0]),xytext=(39,.21),arrowprops=dict(arrowstyle='->',color=BLUE),color=BLUE)
save(fig,'q3_drying','q3_fields.npz; all time nodes; exact 0/.5/1/1.5/2 cm')

d=fields[4];t=d['times_s']/3600
fig,axs=plt.subplots(1,2,figsize=(155/25.4,75/25.4),layout='constrained')
axs[0].set_facecolor('#e4e7e9')
im=axs[0].pcolormesh(t,d['r_fixed_m']*100,np.ma.masked_invalid(d['C'][:,:21].T),shading='auto',cmap=CMAP,vmin=.05,vmax=2.55,rasterized=True)
axs[0].plot(t,d['radius_m']*100,color=RED,lw=1.2)
axs[0].fill_between(t,d['radius_m']*100,2,color='#e4e7e9',zorder=2)
axs[0].plot(t,d['radius_m']*100,color=RED,lw=1.2,zorder=3)
axs[0].text(25,1.80,'灰色：当前域外',ha='center',fontsize=8)
axs[0].set(xlabel='时间 / h',ylabel='绝对半径 / cm',ylim=(0,2))
fig.colorbar(im,ax=axs[0],pad=.02,label='含水率 / (kg/kg)')
for target,col,ls in zip([6,12,24,48],[BLUE,GOLD,GREEN,RED],['-','--','-.',':']):
    idx=np.argmin(abs(t-target));axs[1].plot(d['xi']*d['radius_m'][idx]*100,d['C_xi'][idx],color=col,ls=ls,label=f'{target} h')
axs[1].axhline(.15,color=GREY,lw=.7,ls='--');axs[1].set(xlabel='实际半径 / cm',ylabel='含水率 / (kg/kg)',xlim=(0,2),ylim=(0,2.55));axs[1].legend();grid(axs[1])
save(fig,'q4_domain','q4_fields.npz; NaN mask retained, selected exact times in right panel')

f=summary['factorial']['times_h']
fig,ax=plt.subplots(figsize=(155/25.4,60/25.4),layout='constrained')
for y,p,col in [(1,3,BLUE),(0,4,GREEN)]:
    fixed,moving=f[f'p{p}_moving0'],f[f'p{p}_moving1']
    ax.plot([moving,fixed],[y,y],color=col,lw=2)
    ax.scatter([fixed],[y],marker='s',s=45,color=GREY,label='固定半径' if y==1 else None)
    ax.scatter([moving],[y],marker='o',s=45,color=col,label='收缩半径' if y==1 else None)
    for val in (fixed,moving):ax.annotate(f'{val:.4f}',(val,y),xytext=(0,9),textcoords='offset points',ha='center')
ax.set(yticks=[0,1],yticklabels=['附录4物性','附录3物性'],ylim=(-.55,1.65),xlim=(0,145),xlabel='临界干燥时间 / h')
ax.legend(loc='upper right',ncol=2);grid(ax)
save(fig,'factorial','improvement.json factorial; N=320 all four cases')

fig,axs=plt.subplots(1,2,figsize=(155/25.4,75/25.4),layout='constrained')
for ax,q in zip(axs,(3,4)):
    sc=summary['scenarios'][str(q)];rows=sc['scenarios']
    for i,r in enumerate(rows):
        ax.plot([r['max_C_at_scenario_stop'],r['max_C_at_nominal_stop']],[i,i],color='#ccd2d8',lw=1)
    ax.scatter([r['max_C_at_nominal_stop'] for r in rows],range(8),marker='x',color=RED,s=28,label='名义停机回代')
    ax.scatter([r['max_C_at_scenario_stop'] for r in rows],range(8),marker='o',color=GREEN,s=21,label='统一情景停机回代')
    ax.axvline(.15,color=GREY,lw=.8,ls='--');ax.set(xlabel='停机时全空间最大含水率 / (kg/kg)',ylabel=f'问题{q}：情景编号',yticks=range(8),yticklabels=range(1,9));ax.legend(loc='lower left',fontsize=7.8)
save(fig,'scenarios','improvement.json scenarios; all 8 corners for each q')

# Identical display grid in 3D and 2D. Full-data 2D curve is retained in q3_drying.
d=fields[3];ids=np.unique(np.r_[np.arange(0,len(d['times_s']),30),len(d['times_s'])-1])
t=d['times_s'][ids]/3600;x=d['xi'];z=d['C_xi'][ids].T
tt,xx=np.meshgrid(t,x)
fig=plt.figure(figsize=(155/25.4,80/25.4),layout='constrained')
ax=fig.add_subplot(121,projection='3d');ax.plot_surface(tt,xx,z,cmap=CMAP,rstride=1,cstride=1,linewidth=0,rasterized=True)
ax.set(xlabel='时间 / h',ylabel='物质坐标');ax.view_init(28,225);ax.tick_params(labelsize=7)
ax.text2D(.02,.96,'纵轴：含水率 / (kg/kg)',transform=ax.transAxes,fontsize=8)
ax2=fig.add_subplot(122);im=ax2.contourf(tt,xx,z,levels=np.linspace(.05,2.55,21),cmap=CMAP)
ax2.contour(tt,xx,z,levels=[.15],colors=[RED],linewidths=1)
ax2.set(xlabel='时间 / h',ylabel='物质坐标');fig.colorbar(im,ax=ax2,label='含水率 / (kg/kg)')
save(fig,'q3_surface_candidate',f'q3_fields.npz; displayed {len(ids)} of {len(d["times_s"])} times, every 30 stored rows plus endpoint; both panels same grid','candidate')

write_json(AUDIT/'DRAWING_SCOPE.json',dict(
    image_generation_used=False, external_bitmap_required=False,
    mechanism_source='engineering_figures.py',
    flowcharts='Run engineering_figures.py after this data-plot baseline.',
    website_chart='website_figures.cjs; frozen export is included.'))
write_json(AUDIT/'FIGURES.json',figures)
write_json(AUDIT/'SOURCE_HASHES.json',identities)
print(json.dumps(dict(figures=len(figures),tables=len(list((TEX/'tables').glob('*.tex'))),tail=env[env[:,0]>=10800,1:].mean(axis=0).tolist()),ensure_ascii=False))
