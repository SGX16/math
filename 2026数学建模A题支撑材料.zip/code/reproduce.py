"""Portable numerical entry. No TeX compiler and no manuscript overwrites."""
from pathlib import Path
import argparse
import json
import platform
import time
import numpy as np
import scipy
from scipy.integrate import quad
from openpyxl import Workbook, load_workbook
from openpyxl.cell import WriteOnlyCell
from s2_solver import Settings, ROOT
from s2_stable_graded import StableModel, integral_difference

def workbook(model, path, step, temperature=False):
    book=Workbook(write_only=True)
    names=['温度','水分浓度'] if temperature else ['Sheet1']
    sheets=[book.create_sheet(name) for name in names]
    distances=np.arange(20 if model.moving else 21)/10
    for sheet in sheets:
        sheet.append(['时间\\到药材中心的距离']+distances.tolist()+(['药材表面'] if model.moving else []))
    times=np.unique(np.r_[np.arange(step,model.end,step),model.end])
    for start in range(0,len(times),256):
        ts=times[start:start+256]
        ys=model.state(ts)
        for j,t in enumerate(ts):
            xx=distances/100/model.radius(t)
            for sheet in sheets:
                values=ys[:model.size,j] if sheet.title=='温度' else ys[model.size:,j]
                row=np.interp(xx,model.x,values,right=np.nan)
                if model.moving:
                    row=np.r_[row,values[-1]]
                cells=[]
                for v in row:
                    cell=WriteOnlyCell(sheet, value=None if not np.isfinite(v) else round(float(v),4))
                    cell.number_format='0.0000'
                    cells.append(cell)
                sheet.append([float(t)]+cells)
    book.save(path)
    check=load_workbook(path,read_only=True,data_only=True)
    for ws in check:
        assert sum(1 for _ in ws.values)==len(times)+1
    check.close()
    return dict(rows=len(times),end_s=model.end,step_s=step)

def smoke(out):
    tests=[]
    for a in (.30,.45,.89):
        for c in (.05,.15,1.,2.55):
            right=c*(1+1e-8)
            v=integral_difference(np.array([c]),np.array([right]),a)[0]
            exact=quad(lambda x:np.exp(-a/x),c,right,epsabs=1e-24)[0]
            err=abs(v-exact)/abs(exact)
            assert err<1e-8
            tests.append(err)
    m=StableModel(Settings(question=1,n=40)).run()
    assert abs(m.meta['center_T']-33.57534471765)<.01
    assert abs(m.meta['surface_C']-1.5102350883)<.01
    n=StableModel(Settings(question=4,n=40,D_scale=0,hm_scale=0))
    y=np.r_[np.full(n.size,28.),.8-.3*n.x**2]
    assert np.max(abs(n.rhs(100,y)[n.size:]))==0
    ledger=workbook(m,out/'smoke.xlsx',60,True)
    return dict(positive_C=bool(m.meta['min_accepted_C']>0),
        flux_max_relative_error=max(tests),material_zero_flux_pass=True,
        q1_small_grid=m.meta,workbook=ledger,
        scope='Small-grid smoke only; not production rerun or physical validation')

def full(out):
    models={q:StableModel(Settings(question=q,n=2560 if q==4 else 1280)).run() for q in (1,2,3,4)}
    report={str(q):m.meta for q,m in models.items()}
    for q in (1,2,3,4):
        # Q2 and Q3 have identical governing systems; Q3 supplies the full trajectory.
        m=models[3] if q==2 else models[q]
        report[str(q)]['workbook']=workbook(m,out/f'result{q}.xlsx',1 if q<=2 else 60,q<=2)
    return report

if __name__=='__main__':
    ap=argparse.ArgumentParser()
    ap.add_argument('--mode',choices=['smoke','full'],default='smoke')
    ap.add_argument('--out',type=Path,default=ROOT/'reproduced')
    args=ap.parse_args();args.out.mkdir(parents=True,exist_ok=True)
    if (args.out/f'{args.mode}_report.json').exists():
        raise FileExistsError('Choose a new --out directory to preserve previous reports')
    start=time.perf_counter()
    report=(smoke if args.mode=='smoke' else full)(args.out)
    payload=dict(mode=args.mode,python=platform.python_version(),numpy=np.__version__,scipy=scipy.__version__,
        elapsed_s=time.perf_counter()-start,result=report,exit_code=0)
    (args.out/f'{args.mode}_report.json').write_text(json.dumps(payload,ensure_ascii=False,indent=2),encoding='utf8')
    print(json.dumps(payload,ensure_ascii=False))
