"""Targeted checklist audit; no manuscript or PDF is generated here."""
from pathlib import Path
import hashlib
import json
import platform
import time

import numpy as np
import scipy
from scipy.optimize import brentq
from s2_solver import ROOT, Settings, inputs
from s2_stable_graded import StableModel
from experiments import conservation, requested_table


def first_crossing(model, mode):
    def residual(t):
        c = model.state([t])[model.size:, 0]
        value = c[-1] if mode == 'surface' else 2 * model.w @ c
        return float(value - .15)
    ts = np.linspace(0, model.end, 1501)
    for left, right in zip(ts[:-1], ts[1:]):
        if residual(left) > 0 >= residual(right):
            root = brentq(residual, left, right, xtol=1e-7)
            c = model.state([root])[model.size:, 0]
            return dict(time_h=root / 3600, actual_max_C=float(c.max()),
                        actually_feasible=bool(c.max() < .15))
    raise AssertionError('No crossing found')


def main():
    out = ROOT / 'supplement/pitfall_audit'
    out.mkdir(parents=True, exist_ok=True)
    if (out / 'report.json').exists():
        raise FileExistsError('Preserve the completed report')
    started = time.perf_counter()
    env, rad = inputs()
    tail = env[env[:, 0] >= 10800, 1:].mean(axis=0)
    cases = [('q1_nominal', 1, {}), ('q2_nominal', 2, {})]
    for q in (3, 4):
        cases += [(f'q{q}_nominal', q, {}),
                  (f'q{q}_nominal_n320', q, dict(n=320)),
                  (f'q{q}_constant50', q, dict(tail_T_shift=50-tail[0], tail_C_shift=.05-tail[1])),
                  (f'q{q}_last', q, dict(boundary='last'))]
    cases += [('q4_linear', 4, dict(radius_kind='linear')),
              ('q4_linear_constant50', 4, dict(radius_kind='linear', tail_T_shift=50-tail[0], tail_C_shift=.05-tail[1])),
              ('q3_hm2', 3, dict(hm_scale=2))]
    records = []
    for name, q, changes in cases:
        settings = dict(question=q, n=640)
        settings.update(changes)
        model = StableModel(Settings(**settings)).run()
        record = dict(name=name, meta=model.meta, table=requested_table(model))
        if name in ('q3_nominal', 'q4_nominal'):
            record['conservation'] = conservation(model)
            record['wrong_stop'] = {mode:first_crossing(model, mode) for mode in ('surface', 'mean')}
            ts = np.unique(np.r_[np.arange(0, model.end, 60), model.end])
            states = model.state(ts)
            cs = states[model.size:]
            record['sampled_state_checks'] = dict(
                step_s=60, max_radial_C_increase=float(np.diff(cs, axis=0).max()),
                max_temporal_C_increase=float(np.diff(cs, axis=1).max()),
                max_temperature=float(states[:model.size].max()),
                note='Sampled diagnostics, not a continuous-domain monotonicity proof')
            if q == 4:
                c36 = model.state([36*3600])[model.size:, 0]
                record['at_36h'] = dict(mean_C=float(2*model.w@c36), max_C=float(c36.max()))
                record['radii_cm'] = {str(h):100*model.radius(h*3600) for h in (0, 1, 6, 36, 72)}
        (out / (name+'.json')).write_text(json.dumps(record, ensure_ascii=False, indent=2), encoding='utf8')
        records.append(record)
        print(name, json.dumps(model.meta, ensure_ascii=False), flush=True)
    report = dict(scope='Conditional recomputation; alternatives are not replacements for the locked fine-grid answers',
        python=platform.python_version(), numpy=np.__version__, scipy=scipy.__version__,
        inputs=dict(environment_rows=len(env), radius_rows=len(rad),
                    observed_max_T=float(env[:,1].max()), last_environment=env[-1,1:].tolist(),
                    mean_tail=tail.tolist(), observed_last_radius_cm=float(rad[-1,1])),
        celsius_error_ratio=float(np.exp(-3850/50 + 3850/(50+273.15))),
        cases=records, elapsed_s=time.perf_counter()-started, exit_code=0,
        hashes={str(p.relative_to(ROOT)):hashlib.sha256(p.read_bytes()).hexdigest()
                for p in [Path(__file__), ROOT/'code/s2_solver.py', ROOT/'code/s2_stable_graded.py',
                          ROOT/'data/input1.xlsx', ROOT/'data/input2.xlsx']})
    (out/'report.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf8')
    print('COMPLETE', report['elapsed_s'], flush=True)


if __name__ == '__main__':
    main()
