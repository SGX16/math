"""Conditional surface-evaporation extension; never fit to external answers.

Run: python -X utf8 code/latent_extension.py --n 320 640
Outputs are separate from the locked no-latent simulation files.
"""
import argparse
import hashlib
import json
import platform
from pathlib import Path

import numpy as np
import scipy
from numpy.polynomial.legendre import leggauss

from s2_solver import Settings
from s2_stable_graded import StableModel
from experiments import requested_table

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'supplement' / 'latent_extension'


class LatentModel(StableModel):
    def __init__(self, settings, latent_heat=2.45e6):
        super().__init__(settings)
        if latent_heat < 0:
            raise ValueError('Negative latent heat')
        self.latent_heat = float(latent_heat)
        rho = self.properties(np.array([28.]), np.array([2.55]))[0][0]
        self.rho_d0 = float(rho / 3.55)

    def dry_density(self, t):
        return self.rho_d0 * (.02 / self.radius(t)) ** 2

    def surface_terms(self, t, y):
        Ta, Ca = self.environment(t)
        j = self.dry_density(t) * 8e-7 * self.s.hm_scale * (y[-1] - Ca)
        q = 25 * self.s.h_scale * (Ta - y[self.size-1])
        return float(j), float(q)

    def rhs(self, t, y):
        dy = super().rhs(t, y)
        rho, cp, *_ = self.properties(y[:self.size], y[self.size:])
        j, _ = self.surface_terms(t, y)
        dy[self.size-1] -= self.latent_heat * j / (
            self.radius(t) * self.w[-1] * rho[-1] * cp[-1])
        return dy


def ledger(model):
    # Independent temporal quadrature of external fluxes, per kg dry solid.
    z, weights = leggauss(4)
    total = np.zeros(3)
    minimum_T, minimum_j = float('inf'), float('inf')
    rate_error = 0.
    for piece in model.pieces:
        lo, hi = piece.t[:-1], piece.t[1:]
        ts = ((hi+lo)[:, None]/2 + (hi-lo)[:, None]/2*z).ravel()
        ws = ((hi-lo)[:, None]/2*weights).ravel()
        ys = piece.sol(ts)
        minimum_T = min(minimum_T, float(ys[:model.size].min()))
        for idx, t in enumerate(ts):
            y = ys[:, idx]
            j, q = model.surface_terms(t, y)
            minimum_j = min(minimum_j, j)
            R, rd = model.radius(t), model.dry_density(t)
            total += ws[idx]*np.array([-2*j/(rd*R), 2*q/(rd*R),
                                       2*model.latent_heat*j/(rd*R)])
    for t in np.linspace(0, model.end, 41):
        y = model.state([t])[:, 0]
        rho, cp, *_ = model.properties(y[:model.size], y[model.size:])
        dy = model.rhs(t, y)
        j, q = model.surface_terms(t, y)
        lhs = 2*np.dot(model.w, rho*cp*dy[:model.size])/model.dry_density(t)
        rhs = 2*(q-model.latent_heat*j)/(model.radius(t)*model.dry_density(t))
        rate_error = max(rate_error, abs(lhs-rhs))
    final = model.state([model.end])[:, 0]
    mass_change = float(2*np.dot(model.w, final[model.size:]-2.55))
    result = dict(water_change_kg_per_kg=mass_change,
                  integrated_water_flux=total[0],
                  water_relative_residual=abs(mass_change-total[0])/abs(mass_change),
                  convective_heat_J_per_kg_dry=total[1],
                  latent_heat_J_per_kg_dry=total[2],
                  local_effective_heat_rate_residual_W_per_kg_dry=rate_error,
                  minimum_sampled_temperature_C=minimum_T,
                  minimum_sampled_evaporation_flux=minimum_j)
    if model.kind == 1:
        sensible = float(2*820*2600*np.dot(model.w, final[:model.size]-28)/model.rho_d0)
        result['sensible_energy_J_per_kg_dry'] = sensible
        result['energy_relative_residual'] = abs(sensible-total[1]+total[2])/max(abs(total[1]), abs(total[2]))
    return result


def run_one(q, n, lv=2.45e6, method='BDF', audit=True):
    name = f'q{q}_n{n}_L{lv:.0f}_{method}'
    dest = OUT / name
    if (dest/'run.json').exists():
        print('cached', name, flush=True)
        return
    model = LatentModel(Settings(question=q, n=n, method=method), lv).run()
    dest.mkdir(parents=True, exist_ok=True)
    times = np.unique(np.r_[np.arange(0, model.end, 60.), model.end])
    values = model.state(times)
    np.savez_compressed(dest/'fields.npz', time_s=times, xi=model.x,
                        T=values[:model.size].T, C=values[model.size:].T)
    meta = dict(model.meta, latent_heat_J_kg=lv, dry_density_initial=model.rho_d0,
                dry_density_end=model.dry_density(model.end),
                requested_rows=requested_table(model),
                energy_closure='surface_evaporation_with_effective_sensible_capacity',
                external_answer_used_for_fitting=False)
    if audit:
        meta['ledger'] = ledger(model)
    if q >= 3:
        ts = [model.critical-1, model.critical, model.end]
        meta['threshold_bracket'] = [dict(t_s=t, g=float(model.state([t])[model.size:, 0].max()-.15)) for t in ts]
    (dest/'run.json').write_text(json.dumps(meta, indent=2), encoding='utf-8')
    print(name, 'T=', meta['center_T'], meta['surface_T'],
          'critical_h=', meta['critical_h'], 'strict_h=', meta['end_h'], flush=True)


def tests():
    checks = []
    for q in (1, 2, 3, 4):
        s = Settings(question=q, n=40)
        base, ext = StableModel(s), LatentModel(s, 0.)
        y = np.r_[np.linspace(28, 35, 41), np.linspace(2.55, 1.8, 41)]
        checks.append(dict(name=f'zero_latent_rhs_q{q}', passed=np.array_equal(base.rhs(600, y), ext.rhs(600, y))))
        ext = LatentModel(s)
        y[-1] = ext.environment(600)[1]
        checks.append(dict(name=f'zero_evaporation_q{q}', passed=np.array_equal(base.rhs(600, y), ext.rhs(600, y))))
    a = StableModel(Settings(question=1, n=80)).run()
    b = LatentModel(Settings(question=1, n=80)).run()
    ts = np.linspace(0, 1800, 101)
    error = float(np.max(np.abs(a.state(ts)[a.size:]-b.state(ts)[b.size:])))
    checks.append(dict(name='q1_moisture_invariance', error=error, passed=error < 2e-7))
    OUT.mkdir(parents=True, exist_ok=True)
    (OUT/'tests.json').write_text(json.dumps(checks, indent=2), encoding='utf-8')
    if not all(c['passed'] for c in checks):
        raise AssertionError(checks)
    print('tests', len(checks), 'passed', flush=True)


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--n', type=int, nargs='+', default=[320, 640])
    p.add_argument('--q', type=int, nargs='+', default=[1, 2, 3, 4])
    p.add_argument('--lv', type=float, default=2.45e6)
    p.add_argument('--method', default='BDF')
    p.add_argument('--tests', action='store_true')
    p.add_argument('--extended', action='store_true')
    args = p.parse_args()
    OUT.mkdir(parents=True, exist_ok=True)
    if args.tests:
        tests()
    for n in args.n:
        for q in args.q:
            run_one(q, n, args.lv, args.method)
    if args.extended:
        for lv in (2.30e6, 2.50e6):
            for q in (3, 4):
                run_one(q, 320, lv)
        for q in (1, 3):
            run_one(q, 320, method='Radau')
    identity = {str(path.relative_to(ROOT)): hashlib.sha256(path.read_bytes()).hexdigest()
                for path in [Path(__file__), ROOT/'code/s2_solver.py', ROOT/'code/s2_stable_graded.py', ROOT/'data/input1.xlsx', ROOT/'data/input2.xlsx']}
    (OUT/'environment.json').write_text(json.dumps(dict(python=platform.python_version(),
        numpy=np.__version__, scipy=scipy.__version__, sha256=identity), indent=2), encoding='utf-8')


if __name__ == '__main__':
    main()
