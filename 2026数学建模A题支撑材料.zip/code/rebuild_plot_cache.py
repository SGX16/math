"""Rebuild baseline plotting arrays via the existing production export API."""
import argparse
import json
from pathlib import Path
import shutil
import uuid
import numpy as np
from s2_solver import ROOT, Settings, inputs
from s2_stable_graded import StableModel


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--out', required=True, type=Path)
    parser.add_argument('--smoke', action='store_true')
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=False)
    env, radius = inputs()
    np.savez_compressed(args.out/'inputs.npz', environment=env, radius=radius)
    records = {}
    for q in ((1,) if args.smoke else (1, 2, 3, 4)):
        n = 32 if args.smoke else (2560 if q == 4 else 1280)
        model = StableModel(Settings(question=q, n=n)).run()
        label = f'plot_cache_q{q}_{uuid.uuid4().hex[:12]}'
        model.export(label)
        folder = ROOT/'results/stage2'/label
        shutil.copy2(folder/'fields.npz', args.out/f'q{q}_fields.npz')
        records[str(q)] = model.meta
        print(f'EXPORTED Q{q} N{n}', flush=True)
    (args.out/'cache_rebuild.json').write_text(json.dumps(dict(
        ready=True, smoke=args.smoke, cases=records,
        scope='Existing solver/export; baseline plot arrays only, not all diagnostics'),
        ensure_ascii=False, indent=2), encoding='utf-8')


if __name__ == '__main__':
    main()
