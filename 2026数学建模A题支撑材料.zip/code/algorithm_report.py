"""Back-fill verified Radau results without changing locked BDF answers."""
import argparse
import json
from pathlib import Path

from latent_effect_tables import ROOT, digest


def load_comparison(root):
    folder = root / 'supplement/algorithm_crosscheck'
    report = json.loads((folder / 'report.json').read_text(encoding='utf-8'))
    if not report['ready'] or not report['production'] or report['exit_code'] != 0:
        raise ValueError('Not a completed production comparison')
    for group, parent in [('code', 'code'), ('inputs', 'data')]:
        for name, expected in report['identity'][group].items():
            if digest(root / parent / name) != expected:
                raise ValueError(f'Comparison source changed: {name}')
    cases = {}
    for family in ['baseline', 'latent']:
        for q in range(1, 5):
            name = f'{family}_q{q}'
            item = report['cases'][name]
            path = folder / item['file']
            if digest(path) != item['sha256']:
                raise ValueError(f'Comparison case changed: {name}')
            cases[name] = json.loads(path.read_text(encoding='utf-8'))
    return report, cases


def rows_for(case, q, field):
    positions = [0., .5, 1., 1.5, 2.] + (['surface'] if q == 4 else [])
    bdf = case['bdf']['requested_rows']
    radau = case['radau_at_bdf_rows']
    indexes = {method: {(r['time_s'], r['r_cm']): r for r in records}
               for method, records in [('BDF', bdf), ('Radau', radau)]}
    rows = []
    for t in sorted({r['time_s'] for r in bdf}):
        for method in ['BDF', 'Radau']:
            time = f'{t:.0f}' if q == 1 else f'{t/3600:.4f}'
            row = [time if method == 'BDF' else '', method]
            for position in positions:
                value = indexes[method][t, position][field]
                row.append('--' if value is None else f'{value:.4f}')
            rows.append(row)
    return rows


def sci(value):
    if value == 0:
        return '$0$'
    mantissa, exponent = f'{abs(value):.2e}'.split('e')
    return '$'+mantissa+r'\times10^{'+str(int(exponent))+'}$'


def write_comparison(root=ROOT, out=None, baseline_only=False):
    from answer_table_pairs import panel
    root, out = Path(root), Path(out) if out else Path(root)
    report, cases = load_comparison(root)
    target = out / 'tables'
    target.mkdir(parents=True, exist_ok=True)
    manifest = dict(report_sha256=digest(root / 'supplement/algorithm_crosscheck/report.json'), panels=[])
    modes = ['baseline'] if baseline_only else ['baseline', 'latent']
    for mode in modes:
        for q in range(1, 5):
            case = cases[f'{mode}_q{q}']
            fields = [('T_C', 'temperature_C', '温度（℃）'), ('C_kg_kg', 'moisture', '含水率（kg/kg）')]
            panels = []
            for field, kind, symbol in fields:
                rows = rows_for(case, q, field)
                label = f'tab:q{q}-{kind}' if mode == 'baseline' else f'tab:latent-q{q}-{field}'
                caption = ('无潜热' if mode == 'baseline' else '含潜热')+symbol
                if len(fields) == 2:
                    core = mode == 'baseline' and (q <= 2 or field == 'C_kg_kg')
                    panels.append(panel(rows, caption, label, core, methods=True))
                else:
                    count = len(rows[0])
                    cols = ['时间/h', '算法', '0 cm', '0.5 cm', '1 cm', '1.5 cm', '2 cm'] + (['实际表面'] if q == 4 else [])
                    panels.append('\n'.join([r'\caption{'+caption+r'}\label{'+label+'}',
                        r'\small\begin{tabular}{'+'r'*count+r'}\toprule',
                        ' & '.join(cols)+r'\\\midrule']+
                        [' & '.join(row)+r'\\' for row in rows]+[r'\bottomrule\end{tabular}']))
                manifest['panels'].append(dict(mode=mode, question=q, field=field, label=label, rows=rows))
            unit = 's' if q == 1 else 'h'
            note = f'每个时刻上行为BDF、下行为Radau；时间单位为{unit}，固定径向位置单位为cm。'
            if len(fields) == 2:
                note = '左表温度、右表干基含水率。'+note
            if q >= 3:
                note += '末组共用BDF严格达标时刻；两算法各自终点见本问交叉验证表。0.1500是舍入显示，严格性由未舍入全节点值判定。'
                note += '温度为补充输出。'
            if q == 4:
                note += '表面为瞬时移动表面；--表示该固定位置已在药材外。'
            env = 'coretable' if len(fields) == 1 else 'table'
            tex = '\n'.join([r'\begin{'+env+r'}[htbp]\centering',
                ('\\hfill%\n'.join(panels)),
                r'\par\smallskip\begin{minipage}{\linewidth}\footnotesize', note,
                r'\end{minipage}', r'\end{'+env+'}', ''])
            name = f'q{q}_baseline_pair.tex' if mode == 'baseline' and q <= 2 else (
                f'q{q}_moisture.tex' if mode == 'baseline' else f'latent_q{q}_results.tex')
            (target / name).write_text(tex, encoding='utf-8')
    if not baseline_only:
        md = ['# BDF与Radau逐问答案核对', '',
              'BDF使用经源码和输入哈希核对的既有冷启动生产结果；已保存的交叉核验从初态实际重算了8条Radau轨道。运行本表格脚本只重建表格，不重新积分生产轨道。',
              '两算法共用空间离散、物性、边界、网格、容差和采样位置；比较检验时间积分实现，不构成独立物理模型验证。', '',
              '|问题|模型|N|最大温差/℃|最大含水率差/(kg/kg)|临界时差/s|严格时间BDF/Radau/h|',
              '|---|---|---:|---:|---:|---:|---|']
        for q in range(1, 5):
            lines = [r'\begin{table}[htbp]\centering\small',
                     r'\caption{问题'+str(q)+r'的BDF与Radau同网格核对}\label{tab:algorithm-q'+str(q)+'}',
                     r'\begin{tabular}{lrrr}\toprule',
                     r'模型 & 最大温差/℃ & 最大含水率差/(kg/kg) & 临界时差/s\\\midrule']
            for mode, title in [('baseline', '无潜热'), ('latent', '含潜热')]:
                c = cases[f'{mode}_q{q}']
                m, b, r = c['metrics'], c['bdf']['meta'], c['radau_meta']
                dt = m['critical_difference_s']
                errors = m['max_absolute_difference']
                lines.append(title+' & '+sci(errors['T_C'])+' & '+sci(errors['C_kg_kg'])+' & '+('--' if dt is None else sci(dt))+r'\\')
                end = '--' if q <= 2 else f"{b['end_s']/3600:.4f}/{r['end_s']/3600:.4f}"
                md.append(f"|{q}|{title}|{b['settings']['n']}|{errors['T_C']:.8e}|{errors['C_kg_kg']:.8e}|{dt if dt is not None else '--'}|{end}|")
            lines += [r'\bottomrule\end{tabular}', r'\par\smallskip\begin{minipage}{\linewidth}\footnotesize',
                      '差值取绝对值；场差仅覆盖题目指定时刻、径向位置及实际表面，不是连续全场上界。']
            if q >= 3:
                for mode, title in [('baseline', '无潜热'), ('latent', '含潜热')]:
                    c = cases[f'{mode}_q{q}']
                    b, r = c['bdf']['meta'], c['radau_meta']
                    lines.append(f"{title}的临界时间（BDF/Radau）为{b['critical_s']/3600:.8f}/{r['critical_s']/3600:.8f} h，严格时间为{b['end_s']/3600:.4f}/{r['end_s']/3600:.4f} h。")
            lines += [r'\end{minipage}', r'\end{table}', '']
            (target / f'algorithm_q{q}.tex').write_text('\n'.join(lines), encoding='utf-8')
        md += ['', '主答案保留BDF口径。答案表按同一时刻逐行并列，不取两算法平均；机器报告保存未舍入值、四位小数不一致个数和各自终点。',
               '复算入口：`python -X utf8 code/algorithm_crosscheck.py --out supplement/algorithm_crosscheck`（输出目录须不存在）。',
               '表格入口：`python -X utf8 code/answer_table_pairs.py`。报告缺失时保留单算法版；已有报告但哈希失配时拒绝回填。',
               '当前仅核对指定截面及判停，不额外导出Radau全过程逐秒Excel，也不替代原工作簿、空间网格收敛或气固闭合审计。', '']
        (out / '答案更新_双算法核对.md').write_text('\n'.join(md), encoding='utf-8')
        max_t = max(c['metrics']['max_absolute_difference']['T_C'] for c in cases.values())
        max_c = max(c['metrics']['max_absolute_difference']['C_kg_kg'] for c in cases.values())
        max_time = max(abs(c['metrics']['critical_difference_s'] or 0.) for c in cases.values())
        mismatches = sum(sum(c['metrics']['four_decimal_mismatches'].values()) for c in cases.values())
        note = ('\n\n## 双算法复核补充\n\n'
                f'已保存的生产核验重算四问两种热边界下的8条Radau轨道，并与同网格BDF冷启动记录核对。'
                f'指定截面最大温差{max_t:.8e} ℃、最大含水率差{max_c:.8e} kg/kg、'
                f'最大临界时差{max_time:.8e} s；四位小数不一致计数为{mismatches}。主答案保留BDF。'
                '六张核心表、两张无潜热温度补充表和八张潜热表并列两算法。详见工程根目录的答案更新_双算法核对.md及'
                'supplement/algorithm_crosscheck/report.json。该比较是时间积分交叉核验，'
                '不是独立物理模型验证。本脚本只回填冻结记录；PDF编译与交付验收另有记录。\n')
        for name in ['答案更新_潜热对照.md', 'audit/ANSWER_MATRIX.md']:
            path = out / name
            if path.exists():
                existing = path.read_text(encoding='utf-8').split('\n## 双算法复核补充')[0]
                existing = existing.split('\n## 2026-09-12双算法补充')[0]
                path.write_text(existing.rstrip()+note, encoding='utf-8')
    return manifest


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, default=ROOT)
    args = parser.parse_args()
    result = write_comparison(out=args.out)
    print(f'Generated {len(result["panels"])} dual-algorithm answer panels; no PDF.')
