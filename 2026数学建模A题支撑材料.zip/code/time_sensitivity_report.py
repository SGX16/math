"""Validate saved OAT runs, then generate the paper table from JSON (no PDF)."""
import csv
import argparse
import json
from pathlib import Path
from time_sensitivity import CASES, ROOT, sha

DATA = ROOT/'supplement/time_sensitivity'
LABELS = {
    'base': ('基准', '附录3物性，固定半径'),
    'ea_scale_0.95': (r'$E_a$降低5\%', '温度因子增大，扩散加快'),
    'ea_scale_1.05': (r'$E_a$增加5\%', '温度因子减小，扩散变慢'),
    'D_scale_0.9': (r'$A_0$降低10\%', '全程有效扩散系数缩小'),
    'D_scale_1.1': (r'$A_0$增加10\%', '全程有效扩散系数增大'),
    'initial_scale_0.9': (r'$C_0$降低10\%', '初始水量及初始物性同时响应'),
    'initial_scale_1.1': (r'$C_0$增加10\%', '初始水量及初始物性同时响应'),
    'h_scale_0.9': (r'$h$降低10\%', '主要改变早期升温过程'),
    'h_scale_1.1': (r'$h$增加10\%', '主要改变早期升温过程'),
    'hm_scale_0.1': (r'$h_m$缩至0.1倍', '外部传质阻力大幅增大'),
    'hm_scale_10': (r'$h_m$放大10倍', '外部阻力降低，仍受内部扩散限制'),
}


def main():
    global DATA
    parser = argparse.ArgumentParser()
    parser.add_argument('--data', type=Path, default=DATA)
    args = parser.parse_args()
    DATA = args.data.resolve()
    checks, rows = [], []
    def check(name, condition, **detail):
        checks.append(dict(name=name, passed=bool(condition), **detail))

    def read(name, n, suffix=''):
        path = DATA/f'{name}_n{n}{suffix}.json'
        item = json.loads(path.read_text(encoding='utf8'))
        check(path.name+'_identity', all(sha(ROOT/k) == v for k, v in item['identity'].items()))
        check(path.name+'_threshold', item['threshold_g'][1] > 0
              and abs(item['threshold_g'][2]) < 1e-10 and item['threshold_g'][3] < 0)
        check(path.name+'_bounds', item['minimum_accepted_C'] > 0
              and item['maximum_accepted_C'] <= item['initial_C']+1e-8)
        check(path.name+'_initial', abs(item['initial_C']-2.55*item['case']['initial_scale']) < 1e-12)
        return item

    base = read('base', 640)['meta']['critical_h']
    for case in CASES:
        low, high = read(case.name, 320), read(case.name, 640)
        diff = abs(high['meta']['critical_s']-low['meta']['critical_s'])
        check(case.name+'_mesh', diff < 1, difference_s=diff)
        varied = sum(v != 1 for k, v in high['case'].items() if k != 'name')
        check(case.name+'_OAT', varied == (0 if case.name == 'base' else 1))
        rows.append(dict(case=case.name, critical_h=high['meta']['critical_h'],
                         strict_h=high['meta']['end_h'],
                         relative_percent=100*(high['meta']['critical_h']/base-1),
                         grid_difference_s=diff,
                         max_C_at_strict=high['meta']['max_C_at_end']))
    cross = []
    for name in ('base', 'ea_scale_1.05', 'hm_scale_0.1'):
        bdf, radau = read(name, 320), read(name, 320, '_radau')
        diff = abs(bdf['meta']['critical_s']-radau['meta']['critical_s'])
        check(name+'_independent_numerics', diff < 1, difference_s=diff)
        cross.append(dict(case=name, difference_s=diff))
    check('baseline_locked_regression', abs(base-57.47400138312419)*3600 < 1)
    report = dict(ready=all(c['passed'] for c in checks), checks=checks,
                  baseline_critical_h=base, rows=rows, crosschecks=cross,
                  maximum_grid_difference_s=max(r['grid_difference_s'] for r in rows),
                  maximum_crosscheck_difference_s=max(r['difference_s'] for r in cross),
                  scope='Designed OAT, not confidence intervals or global sensitivity; shared physical closures')
    (DATA/'VALIDATION.json').write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding='utf8')
    if not report['ready']:
        raise RuntimeError('Validation failed; no paper table generated')
    with (DATA/'time_sensitivity.csv').open('w', encoding='utf-8-sig', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)
    lines = [r'\begin{table}[htbp]\centering\small',
             r'\caption{问题三单参数扰动对总烘干时长的影响}\label{tab:q3-time-sensitivity}',
             r'\begingroup\setlength{\tabcolsep}{3pt}\renewcommand{\arraystretch}{1.12}',
             r'\begin{tabularx}{\linewidth}{@{}lrrr>{\raggedright\arraybackslash}X@{}}\toprule',
             r'扰动 & 临界/h & 严格/h & 变化/\% & 机理解释\\\midrule']
    for r in rows:
        label, note = LABELS[r['case']]
        lines.append(f'{label} & {r["critical_h"]:.4f} & {r["strict_h"]:.4f} & '
                     f'{r["relative_percent"]:+.3f} & {note}' + r'\\')
    lines += [r'\bottomrule\end{tabularx}\endgroup',
              r'\par\smallskip\begin{minipage}{\linewidth}\footnotesize',
              '均采用640区间表面加密网格；变化率相对本表未舍入的基准临界时间计算。严格时间为临界后继续5 s并向上对齐0.0001 h，且回代确认全网格最大含水率低于0.15 kg/kg。',
              f'全部11组的320/640网格时间差最大{report["maximum_grid_difference_s"]:.3f} s；三组Radau及独立通量组装核验的最大差{report["maximum_crosscheck_difference_s"]:.6f} s。',
              r'\end{minipage}\end{table}']
    (ROOT/'tables/q3_time_sensitivity.tex').write_text('\n'.join(lines)+'\n', encoding='utf8')
    print(json.dumps({k: report[k] for k in ('ready', 'baseline_critical_h',
                     'maximum_grid_difference_s', 'maximum_crosscheck_difference_s', 'rows')},
                     ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
