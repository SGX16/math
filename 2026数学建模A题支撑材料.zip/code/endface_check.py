"""Isolated Q1 end-face audit; never changes production model or result lock."""
from pathlib import Path
import hashlib
import json
import platform
import shutil
import time

import numpy as np
import scipy
from scipy.linalg import eigh_tridiagonal
from scipy.integrate import solve_ivp
from PIL import Image
from s2_solver import inputs

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'reproduced/endface'
ALPHA = .36 / (820 * 2600)


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def spectrum(n, length, radial, h):
    x = np.linspace(0, length, n + 1)
    faces = np.r_[0, (x[:-1] + x[1:]) / 2, length]
    w = np.diff(faces**2) / 2 if radial else np.diff(faces)
    conductance = ALPHA / np.diff(x)
    if radial:
        conductance *= faces[1:-1]
    diag = -np.r_[conductance, 0] - np.r_[0, conductance]
    diag[-1] -= h / (820 * 2600) * (length if radial else 1)
    d = diag / w
    off = conductance / np.sqrt(w[:-1] * w[1:])
    lam, q = eigh_tridiagonal(d, off)
    assert lam.max() < 1e-10
    beta = q.T @ np.sqrt(w)
    return x, w, lam, q, beta, d, off


def ramp_weights(lam, env, stop):
    total = np.zeros_like(lam)
    for a, b in zip(env[:-1], env[1:]):
        left, right = a[0], min(b[0], stop)
        if left >= stop:
            break
        slope = (b[1] - a[1]) / (b[0] - a[0])
        dt = right - left
        # Stable integral exp(lambda * age) over this linear forcing segment.
        term = np.full_like(lam, dt)
        mask = np.abs(lam) > 1e-14
        term[mask] = np.expm1(lam[mask] * dt) / lam[mask]
        total += slope * np.exp(lam * (stop - right)) * term
    return total


def calculation(nr, nz, h_end):
    env, _ = inputs()
    assert env[0, 0] == 0 and env[0, 1] == 28
    r, wr, lr, qr, br, _, _ = spectrum(nr, .02, True, 25)
    z, wz, lz, qz, bz, _, _ = spectrum(nz, .125, False, h_end)
    ta = float(np.interp(1800, env[:, 0], env[:, 1]))
    deficit_r = qr @ (br * ramp_weights(lr, env, 1800)) / np.sqrt(wr)
    deficit = (qr @ (br[:, None] * bz[None, :] *
               ramp_weights(lr[:, None] + lz[None, :], env, 1800)) @ qz.T)
    deficit /= np.sqrt(wr[:, None] * wz[None, :])
    T = ta - deficit
    radial = ta - deficit_r
    delta = T - radial[:, None]
    assert T.min() >= 28 - 1e-8 and T.max() <= ta + 1e-8
    assert delta.min() > -1e-7
    return dict(nr=nr, nz=nz, h_end=h_end, ambient_C=ta,
                radial_center_C=float(radial[0]), radial_surface_C=float(radial[-1]),
                cylinder_center_C=float(T[0, 0]), end_axis_C=float(T[0, -1]),
                end_rim_C=float(T[-1, -1]),
                midplane_max_delta_C=float(delta[:, 0].max()),
                full_domain_max_delta_C=float(delta.max()),
                mean_delta_C=float(wr @ delta @ wz / (wr.sum() * wz.sum())),
                radial_mean_C=float(wr @ radial / wr.sum()),
                temperature_min_C=float(T.min()), temperature_max_C=float(T.max()))


def independent_time_test():
    env, _ = inputs()
    x, w, lam, q, beta, d, off = spectrum(20, .02, True, 25)
    sqrtw = np.sqrt(w)
    def rhs(t, v):
        ta = np.interp(t, env[:, 0], env[:, 1])
        u = sqrtw * (v - ta)
        out = d * u
        out[1:] += off * u[:-1]
        out[:-1] += off * u[1:]
        return out / sqrtw
    sol = solve_ivp(rhs, (0, 1800), np.full(len(x), 28.), method='DOP853',
                    rtol=1e-10, atol=1e-11, max_step=1)
    assert sol.success
    exact = np.interp(1800, env[:, 0], env[:, 1]) - q @ (
        beta * ramp_weights(lam, env, 1800)) / sqrtw
    err = float(np.max(np.abs(exact - sol.y[:, -1])))
    assert err < 1e-6
    return dict(method='DOP853 independent time integration, same coarse spatial operator', max_error_C=err)


def main():
    start = time.perf_counter()
    OUT.mkdir(parents=True, exist_ok=True)
    protected = [ROOT/'evidence/RESULTS_LOCK.md', ROOT/'evidence/answers.json', ROOT/'code/s2_solver.py',
                 ROOT/'code/s2_stable_graded.py']
    before = {str(p): sha(p) for p in protected}
    runs = [calculation(64, 200, 25), calculation(128, 400, 25), calculation(64, 200, 0)]
    assert runs[-1]['full_domain_max_delta_C'] < 1e-7
    tests = independent_time_test()
    ratios = []
    for qnum, a, prefactor in [(1, .89, 7e-9), (3, .45, 2.4e-3*np.exp(-3850/323.15)),
                              (4, .30, 4.2e-4*np.exp(-3850/323.15))]:
        for c in [2.55, .15]:
            wrong = prefactor*np.exp(-c if qnum == 1 else -a*c)
            correct = prefactor*np.exp(-a/c)
            ratios.append(dict(question=qnum, C=c, correct_D=correct, candidate_D=wrong,
                               wrong_over_correct=wrong/correct,
                               fixed_temperature_C=None if qnum == 1 else 50))
    # Scenario only: effective dry-basis exchange is NOT an observed evaporation flux.
    rho_d = 820/(1+2.55)
    ca = float(np.interp(1800, inputs()[0][:, 0], inputs()[0][:, 2]))
    j = rho_d*8e-7*(1.51023509-ca)
    sensible_flux = 25*(runs[1]['ambient_C']-36.78556033)
    result = dict(scope='Q1 constant properties, 1800 s, no moisture or latent coupling; diagnostic only',
                  geometry=dict(L_m=.25,R_m=.02, end_over_side=.02/.25,
                                end_fraction_total=.02/(.25+.02),alpha_m2_s=ALPHA,
                                diffusion_length_1800_m=float(np.sqrt(ALPHA*1800))),
                  endface_runs=runs, time_integration_check=tests, diffusivity_comparison=ratios,
                  latent_scenario=dict(status='hypothetical conversion, not physical validation or production prediction',
                      assumed_Lv_J_kg=2.4e6, assumed_dry_density=rho_d, implied_evap_flux_kg_m2_s=j,
                      implied_latent_W_m2=2.4e6*j, baseline_convective_W_m2=sensible_flux,
                      ratio=2.4e6*j/sensible_flux),
                  production_sha256=before, production_unchanged=before=={str(p):sha(p) for p in protected},
                  runtime=dict(python=platform.python_version(), numpy=np.__version__,scipy=scipy.__version__,
                               elapsed_s=time.perf_counter()-start),
                  source_inventory='official inputs only; no candidate image dependency')
    assert result['production_unchanged']
    (OUT/'DIAGNOSTICS.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps({k:v for k,v in result.items() if k!='source_inventory'},ensure_ascii=False,indent=2))


if __name__ == '__main__':
    main()
