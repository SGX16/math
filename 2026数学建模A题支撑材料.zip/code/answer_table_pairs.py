"""Generate adjacent answer tables from the locked baseline and latent records."""
import argparse
import json
from pathlib import Path

from latent_effect_tables import ROOT, digest, read_records


def panel(rows, caption, label, core=False, methods=False):
    count = len(rows[0])
    columns = (['算法'] if methods else []) + ['0', '0.5', '1', '1.5', '2'] + (['表面'] if count - int(methods) == 7 else [])
    lines = [r'\begin{minipage}[t]{.485\linewidth}\vspace{0pt}\centering',
             r'\captionsetup{font=footnotesize,skip=4pt}']
    if core:
        lines.append(r'\coreanswercaption{'+caption+'}{'+label+'}')
    else:
        lines.append(r'\caption{'+caption+r'}\label{'+label+'}')
    lines += [r'\linespread{1}\fontsize{8.5pt}{11pt}\selectfont\setlength{\tabcolsep}{1pt}',
              r'\begin{tabular*}{\linewidth}{@{\extracolsep{\fill}}'+'r'*count+r'@{}}\toprule',
              r'时间 & '+' & '.join(columns)+r'\\\midrule']
    for row in rows:
        lines.append(' & '.join(row)+r'\\')
    lines += [r'\bottomrule\end{tabular*}', r'\end{minipage}']
    return '\n'.join(lines)


def write_pairs(root=ROOT, output_root=None, baseline_only=False):
    root = Path(root)
    out = Path(output_root) if output_root else root
    if (root / 'supplement/algorithm_crosscheck/report.json').exists():
        from algorithm_report import load_comparison
        load_comparison(root)
    (out / 'tables').mkdir(parents=True, exist_ok=True)
    pairs, hashes = ({}, {'evidence/answers.json': digest(root / 'evidence/answers.json')}) if baseline_only else read_records(root)
    answers = {a['question']: a for a in json.loads((root / 'evidence/answers.json').read_text(encoding='utf-8'))}
    manifest = dict(source_sha256=hashes, panels=[])
    modes = [('baseline', (1, 2))] if baseline_only else [('baseline', (1, 2)), ('latent', (1, 2, 3, 4))]
    for mode, questions in modes:
        for q in questions:
            panels = []
            for kind, field, symbol in [('temperature_C', 'T_C', '温度（℃）'), ('moisture', 'C_kg_kg', '含水率（kg/kg）')]:
                rows = []
                if mode == 'baseline':
                    for record in answers[q]['table_rows']:
                        time = record['time_s'] / (1 if q == 1 else 3600)
                        rows.append([f'{time:.0f}' if q == 1 else f'{time:.4f}'] +
                                    [f'{v:.4f}' for v in record[kind][:5]])
                    label = f'tab:q{q}-{kind}'
                else:
                    records = pairs[q][1]['requested_rows']
                    positions = [0., .5, 1., 1.5, 2.] + (['surface'] if q == 4 else [])
                    for time_s in sorted({r['time_s'] for r in records}):
                        time = time_s / (1 if q == 1 else 3600)
                        row = [f'{time:.0f}' if q == 1 else f'{time:.4f}']
                        for position in positions:
                            matches = [r for r in records if r['time_s'] == time_s and r['r_cm'] == position]
                            if len(matches) != 1:
                                raise ValueError(f'Nonunique Q{q} time/position record')
                            value = matches[0][field]
                            row.append('--' if value is None else f'{value:.4f}')
                        rows.append(row)
                    label = f'tab:latent-q{q}-{field}'
                prefix = '无潜热' if mode == 'baseline' else '含潜热'
                panels.append(panel(rows, prefix+symbol, label, core=mode == 'baseline'))
                manifest['panels'].append(dict(mode=mode, question=q, field=field, label=label, rows=rows))
            timeunit = 's' if q == 1 else 'h'
            note = f'左表为温度，右表为干基含水率；时间单位为{timeunit}，固定径向位置单位为cm。'
            if q >= 3:
                note += '含水率表回答题目要求，温度表为补充结果；末行为严格达标时刻。'
            if q == 4:
                note += '“表面”为瞬时移动表面；--表示该固定位置已在药材外，不以零代替。'
            tex = '\n'.join([r'\begin{table}[htbp]\centering', panels[0]+r'\hfill%', panels[1],
                              r'\par\smallskip\begin{minipage}{\linewidth}\footnotesize',
                              note, r'\end{minipage}', r'\end{table}', ''])
            name = f'q{q}_baseline_pair.tex' if mode == 'baseline' else f'latent_q{q}_results.tex'
            (out / 'tables' / name).write_text(tex, encoding='utf-8')
    if (root / 'supplement/algorithm_crosscheck/report.json').exists():
        from algorithm_report import write_comparison
        manifest['algorithm_comparison'] = write_comparison(root, out, baseline_only)
    target = out / 'supplement/answer_table_pairs'
    target.mkdir(parents=True, exist_ok=True)
    (target / ('report_baseline.json' if baseline_only else 'report.json')).write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8')
    return manifest


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, default=ROOT)
    args = parser.parse_args()
    result = write_pairs(output_root=args.out)
    actual = result.get('algorithm_comparison', result)['panels']
    print(f'Generated {len(actual)} answer panels in adjacent temperature/moisture pairs; no PDF.')
