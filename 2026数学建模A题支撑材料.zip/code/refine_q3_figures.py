"""Restyle two question-three plots from locked fields without recomputation."""
from pathlib import Path
import hashlib
import json

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "evidence/q3_fields.npz"
OUT = ROOT / "figures"
plt.rcParams.update({
    "font.family": ["Times New Roman", "SimSun"],
    "font.size": 9, "axes.labelsize": 9, "xtick.labelsize": 8,
    "ytick.labelsize": 8, "legend.fontsize": 8,
    "mathtext.fontset": "stix", "axes.unicode_minus": False,
    "axes.spines.top": False, "axes.spines.right": False,
    "axes.linewidth": .6, "legend.frameon": False,
    "pdf.fonttype": 42, "svg.fonttype": "none",
    "savefig.facecolor": "white",
})
CMAP = LinearSegmentedColormap.from_list(
    "moisture", ["#fbfcfc", "#b7d4cd", "#408477", "#214b5b"])
COLORS = ["#2C4A7C", "#66717E", "#B9852D", "#3E7D5A", "#C65353"]
LINES = ["-", "--", "-.", ":", "-"]
with np.load(SOURCE) as source:
    d = {k: source[k] for k in source.files}
t = d["times_s"] / 3600
xi, c = d["xi"], d["C_xi"]
indices = [int(np.argmin(abs(xi - i / 4))) for i in range(5)]
assert np.allclose(xi[indices], np.arange(5) / 4)
assert indices == [0, 25, 50, 75, 100]

def save(fig, name):
    for ext in ("pdf", "svg", "png"):
        fig.savefig(OUT / f"{name}.{ext}", dpi=360)
    plt.close(fig)

fig, axes = plt.subplots(1, 2, figsize=(140/25.4, 51/25.4))
fig.subplots_adjust(left=.09, right=.99, bottom=.22, top=.81, wspace=.32)
for i, j in enumerate(indices):
    for ax in axes:
        ax.plot(t, c[:, j], color=COLORS[i], ls=LINES[i],
                lw=1.25 if i in (0, 4) else .95, label=f"{i*.5:g} cm")
for ax in axes:
    ax.axhline(.15, color="#454545", lw=.7, ls=(0, (3, 2)))
    ax.set(xlabel="时间 / h", ylabel="含水率 / (kg/kg)")
    ax.grid(axis="y", color="#e7ebed", lw=.45)
    ax.set_axisbelow(True)
axes[0].set(xlim=(0, t[-1]), ylim=(0, 2.6), xticks=[0, 10, 20, 30, 40, 50])
axes[1].set(xlim=(30, t[-1]), ylim=(.045, .23), xticks=[30, 40, 50])
axes[1].annotate("中心最后达标", xy=(t[-1], c[-1, 0]),
                 xytext=(34, .211), fontsize=8, color=COLORS[0],
                 arrowprops={"arrowstyle": "->", "color": COLORS[0], "lw": .65})
fig.legend(*axes[0].get_legend_handles_labels(), ncol=5, loc="upper center",
           bbox_to_anchor=(.52, 1.01), handlelength=2.1, columnspacing=1.35)
save(fig, "q3_drying_refined")

ids = np.unique(np.r_[np.arange(0, len(t), 30), len(t)-1])
tt, xx = np.meshgrid(t[ids], xi)
z = c[ids].T
fig = plt.figure(figsize=(145/25.4, 69/25.4))
ax = fig.add_axes([.005, .12, .47, .77], projection="3d")
ax.plot_surface(tt, xx, z, cmap=CMAP, rstride=1, cstride=1,
                linewidth=0, antialiased=True, rasterized=True,
                vmin=.05, vmax=2.55)
ax.set(xlabel="时间 / h", ylabel="物质坐标", xticks=[0, 20, 40, 60],
       yticks=[0, .5, 1], zticks=[.5, 1.5, 2.5])
ax.view_init(26, 225)
ax.set_box_aspect((1.25, 1, .82))
ax.tick_params(labelsize=7, pad=0)
ax.xaxis.labelpad = 0
ax.yaxis.labelpad = 0
ax.text2D(.03, 1.0, "含水率 / (kg/kg)", transform=ax.transAxes, fontsize=8)
for axis in (ax.xaxis, ax.yaxis, ax.zaxis):
    axis.pane.fill = False
    axis._axinfo["grid"].update(color="#dce2e4", linewidth=.4)
ax2 = fig.add_axes([.58, .20, .31, .69])
im = ax2.contourf(tt, xx, z, levels=np.linspace(.05, 2.55, 21), cmap=CMAP)
ax2.contour(tt, xx, z, levels=[.15], colors=[COLORS[-1]], linewidths=.9)
ax2.set(xlabel="时间 / h", ylabel="物质坐标", xticks=[0, 20, 40],
        yticks=[0, .25, .5, .75, 1])
ax2.text(.02, 1.045, "红线：0.15 kg/kg", transform=ax2.transAxes,
         fontsize=8, color=COLORS[-1])
cax = fig.add_axes([.91, .20, .018, .69])
cb = fig.colorbar(im, cax=cax, ticks=[.05, .55, 1.05, 1.55, 2.05, 2.55])
cb.ax.tick_params(labelsize=7, length=2, pad=2)
cb.outline.set_linewidth(.4)
save(fig, "q3_surface_refined")

report = {
    "source_sha256": hashlib.sha256(SOURCE.read_bytes()).hexdigest(),
    "full_curve_shape": list(c[:, indices].shape),
    "radial_indices": indices,
    "curve_sha256": hashlib.sha256(c[:, indices].tobytes()).hexdigest(),
    "surface_display_rows": ids.tolist(),
    "surface_sha256": hashlib.sha256(z.tobytes()).hexdigest(),
    "surface_and_projection_same_array": True,
    "model_recomputed": False,
}
(OUT / "q3_refined_identity.json").write_text(
    json.dumps(report, ensure_ascii=False, indent=2), encoding="utf8")
print(json.dumps({k: v for k, v in report.items() if k != "surface_display_rows"}))
