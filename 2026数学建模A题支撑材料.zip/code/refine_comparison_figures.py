"""Typography and compact layout for existing controlled comparisons."""
from pathlib import Path
import hashlib
import json
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "figures"
plt.rcParams.update({
    "font.family": ["Times New Roman", "SimSun"], "font.size": 9,
    "mathtext.fontset": "stix", "axes.unicode_minus": False,
    "axes.spines.top": False, "axes.spines.right": False,
    "axes.linewidth": .6, "legend.frameon": False,
    "pdf.fonttype": 42, "svg.fonttype": "none",
    "xtick.labelsize": 8, "ytick.labelsize": 8,
})

def save(fig, name):
    for ext in ("pdf", "svg", "png"):
        fig.savefig(OUT / f"{name}.{ext}", dpi=360, facecolor="white")
    plt.close(fig)

paths = [ROOT / "supplement/q1_base.json",
         ROOT / "supplement/q1_lumped.json", ROOT / "evidence/improvement.json"]
base, lump, summary = [json.loads(p.read_text(encoding="utf8")) for p in paths]
fig, ax = plt.subplots(figsize=(155/25.4, 59/25.4), layout="constrained")
for key, label, color, ls in [
        ("Tc", "径向模型：中心", "#247F78", "-"),
        ("Ts", "径向模型：表面", "#B45249", "-"),
        ("Tmean", "径向模型：体积均温", "#677582", "--")]:
    ax.plot(base["time_s"], base[key], label=label, color=color, ls=ls, lw=1.1)
ax.plot(lump["time_s"], lump["T"], label="集中参数：均温", color="#996F32", ls=":", lw=1.1)
ax.set(xlabel="时间 / s", ylabel="温度 / ℃", xlim=(0, 1800))
ax.legend(fontsize=8.5, ncol=2)
save(fig, "q1_physical_compare_refined")

times = summary["factorial"]["times_h"]
fig, ax = plt.subplots(figsize=(155/25.4, 78.91/25.4))
fig.subplots_adjust(left=.17, right=.95, bottom=.20, top=.78)
for y, prop in [(0, 4), (1, 3)]:
    fixed, moving = times[f"p{prop}_moving0"], times[f"p{prop}_moving1"]
    ax.plot([moving, fixed], [y, y], color="#a4afb5", lw=1.1)
    ax.scatter(fixed, y, s=27, facecolor="white", edgecolor="#56636b",
               label="固定半径" if y == 0 else None, zorder=3)
    ax.scatter(moving, y, marker="D", s=27, color="#286378",
               label="收缩半径" if y == 0 else None, zorder=3)
    for val, offset in [(fixed, 9), (moving, -17)]:
        ax.annotate(f"{val:.4f}", (val, y), xytext=(0, offset),
                    textcoords="offset points", ha="center", fontsize=8.5)
ax.set(xlim=(0, 140), ylim=(-.6, 1.6), yticks=[0, 1],
       yticklabels=["附录4物性", "附录3物性"], xlabel="临界干燥时间 / h")
ax.grid(axis="x", color="#e4e8eb", linestyle="--", lw=.45)
ax.spines["left"].set_visible(False)
ax.tick_params(axis="y", length=0)
ax.legend(loc="upper center", bbox_to_anchor=(.5, 1.27), ncol=2, fontsize=9)
save(fig, "factorial_refined")

fig, axes = plt.subplots(1, 2, figsize=(140/25.4, 51/25.4))
fig.subplots_adjust(left=.085, right=.99, bottom=.25, top=.78, wspace=.35)
for ax, q in zip(axes, [3, 4]):
    rows = summary["scenarios"][str(q)]["scenarios"]
    assert len(rows) == 8
    for i, row in enumerate(rows):
        ax.plot([row["max_C_at_scenario_stop"], row["max_C_at_nominal_stop"]],
                [i+1, i+1], color="#cbd2d7", lw=.7)
    ax.scatter([r["max_C_at_nominal_stop"] for r in rows], range(1, 9),
               marker="x", color="#C65353", s=17, label="名义停机")
    ax.scatter([r["max_C_at_scenario_stop"] for r in rows], range(1, 9),
               marker="o", color="#3E7D5A", s=15, label="统一停机")
    ax.axvline(.15, color="#66717e", ls="--", lw=.7)
    ax.set(ylabel=f"问题{q}：情景编号", yticks=[1, 3, 5, 7, 8],
           xlabel="停机时全域最大含水率 / (kg/kg)", ylim=(.5, 8.5))
fig.legend(*axes[0].get_legend_handles_labels(), ncol=2, loc="upper center",
           bbox_to_anchor=(.52, 1.02), fontsize=8.5)
save(fig, "scenarios_refined")
(OUT / "comparison_refined_identity.json").write_text(json.dumps(
    {"inputs": {str(p.relative_to(ROOT)): hashlib.sha256(p.read_bytes()).hexdigest()
                for p in paths}, "model_recomputed": False,
     "factorial_times": times, "scenario_counts": [8, 8]},
    ensure_ascii=False, indent=2), encoding="utf8")
print("Three comparison figures exported from unchanged numerical records.")
