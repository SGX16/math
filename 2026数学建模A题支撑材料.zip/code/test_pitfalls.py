"""Formula, export and independent cylindrical step-heating checks."""
import json
from types import SimpleNamespace
import unittest
import numpy as np
from openpyxl import load_workbook
from scipy.integrate import solve_ivp
from scipy.optimize import brentq
from scipy.special import j0, j1
from scipy.sparse import diags
from reproduce import workbook
from s2_solver import ROOT, Settings
from s2_stable_graded import StableModel


class PitfallTests(unittest.TestCase):
    def test_template_export_all_questions(self):
        out=ROOT/'supplement/pitfall_audit/schema_tests'
        out.mkdir(parents=True,exist_ok=True)
        for q in (1,2,3,4):
            moving=q==4
            x=np.linspace(0,1,21)
            model=SimpleNamespace(moving=moving, end=120.36, size=21, x=x,
                radius=lambda t: .012 if moving else .02,
                state=lambda ts:np.repeat(np.r_[28+x,2.55-x][:,None],len(ts),axis=1))
            step=1 if q<=2 else 60
            path=out/f'result{q}.xlsx'
            ledger=workbook(model,path,step,q<=2)
            book=load_workbook(path,read_only=True)
            self.assertEqual(book.sheetnames,['温度','水分浓度'] if q<=2 else ['Sheet1'])
            for sheet in book:
                rows=list(sheet.rows)
                self.assertEqual(rows[0][0].value,'时间\\到药材中心的距离')
                self.assertEqual(rows[1][0].value,step)
                self.assertEqual(rows[-1][0].value,120.36)
                self.assertEqual(len(rows)-1,ledger['rows'])
                self.assertEqual(len(rows[0]),22)
                for row in rows[1:]:
                    for cell in row[1:]:
                        if cell.value is not None: self.assertEqual(cell.number_format,'0.0000')
                if moving:
                    self.assertEqual(rows[0][-1].value,'药材表面')
                    self.assertTrue(all(c.value is None for c in rows[-1][14:21]))
                    self.assertEqual(rows[-1][13].value,rows[-1][-1].value)
            book.close()

    def test_formula_units_and_direction(self):
        for q,A,a in ((1,7e-9,.89),(2,2.4e-3,.45),(4,4.2e-4,.30)):
            m=StableModel(Settings(question=q,n=4))
            T=np.full(m.size,50.); C=np.full(m.size,.15)
            rho,cp,k,coef,beta=m.properties(T,C)
            expected=A if q==1 else A*np.exp(-3850/323.15)
            np.testing.assert_allclose(coef,expected,rtol=1e-14)
            self.assertEqual(beta,a)
            self.assertLess(np.exp(-a/.15),np.exp(-a/2.55))
        self.assertLess(np.exp(-3850/50),np.exp(-3850/323.15))

    def test_constant_step_heat_bessel(self):
        R=.02; alpha=.36/(820*2600); bi=25*R/.36
        f=lambda z:z*j1(z)-bi*j0(z)
        samples=np.linspace(1e-8,65*np.pi,10000)
        roots=np.array([brentq(f,a,b) for a,b in zip(samples[:-1],samples[1:]) if f(a)*f(b)<0])[:60]
        coeff=2*j1(roots)/(roots*(j0(roots)**2+j1(roots)**2))
        times=np.array([100.,600.,1800.]); positions=np.array([0.,.5,1.])
        exact=50-22*np.array([np.sum(coeff[:,None]*j0(roots[:,None]*positions)*
                            np.exp(-roots[:,None]**2*alpha*t/R**2),axis=0) for t in times])
        results=[]
        for n in (160,320):
            m=StableModel(Settings(question=1,n=n))
            m.environment=lambda t:(50.,.05)
            def rhs(t,T):
                return m.rhs(t,np.r_[T,np.full(m.size,2.55)])[:m.size]
            band=diags([np.ones(n),np.ones(n+1),np.ones(n)],[-1,0,1],format='csc')
            sol=solve_ivp(rhs,(0,1800),np.full(m.size,28.),method='BDF',t_eval=times,
                          rtol=1e-11,atol=1e-10,max_step=5,jac_sparsity=band)
            self.assertTrue(sol.success)
            got=np.array([np.interp(positions,m.x,sol.y[:,i]) for i in range(3)])
            error=float(np.max(abs(got-exact)))
            self.assertLess(error,.01)
            results.append(dict(n=n,computed=got.tolist(),max_error_C=error))
        self.assertLess(results[1]['max_error_C'],results[0]['max_error_C'])
        report=dict(times_s=times.tolist(),radius_fractions=positions.tolist(),
                    analytic_T=exact.tolist(),roots=roots.tolist(),results=results,
                    scope='Constant-property step-heating test only, not the observed-boundary answer',pass_=True)
        out=ROOT/'supplement/pitfall_audit'
        out.mkdir(parents=True,exist_ok=True)
        (out/'bessel_check.json').write_text(json.dumps(report,indent=2),encoding='utf8')


if __name__=='__main__':
    unittest.main(verbosity=2)
