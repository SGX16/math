"""Build paired latent/no-latent tables from frozen, unrounded records."""
import argparse
import hashlib
import json
import math
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
FIELDS = [('center_T', '中心温度', '℃'), ('surface_T', '表面温度', '℃'),
          ('center_C', '中心含水率', 'kg/kg'), ('surface_C', '表面含水率', 'kg/kg')]


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def read_records(root):
    sources = [root / 'evidence/answers.json']
    baseline = {a['question']: a['meta'] for a in json.loads(sources[0].read_text(encoding='utf-8'))}
    pairs = {}
    for q in range(1, 5):
        path = root / f'supplement/latent_extension/q{q}_n1280_L2450000_BDF/run.json'
        sources.append(path)
        latent = json.loads(path.read_text(encoding='utf-8'))
        b = baseline[q]
        if latent['latent_heat_J_kg'] != 2450000 or latent['external_answer_used_for_fitting']:
            raise ValueError(f'Q{q}: unexpected latent configuration')
        if {k: v for k, v in b['settings'].items() if k != 'n'} != {
                k: v for k, v in latent['settings'].items() if k != 'n'}:
            raise ValueError(f'Q{q}: settings differ beyond the declared mesh')
        if (b['settings']['n'], latent['settings']['n']) != ((2560, 1280) if q == 4 else (1280, 1280)):
            raise ValueError(f'Q{q}: unexpected production meshes')
        for name, record in [('baseline', b), ('latent', latent)]:
            cold_path = root / f'runs/cold_dual_20260912/output/{name}/q{q}.json'
            sources.append(cold_path)
            cold = json.loads(cold_path.read_text(encoding='utf-8'))['meta']
            for key in ['center_T', 'surface_T', 'center_C', 'surface_C', 'end_h', 'end_radius_cm'] + (
                    ['critical_h'] if q >= 3 else []):
                if not math.isclose(record[key], cold[key], rel_tol=0, abs_tol=1e-7):
                    raise ValueError(f'Q{q}/{name}/{key}: cold-run mismatch')
            if q >= 3 and not record['max_C_at_end'] < .15:
                raise ValueError(f'Q{q}/{name}: strict endpoint invalid')
        if q <= 2 and b['end_s'] != latent['end_s']:
            raise ValueError(f'Q{q}: unequal comparison times')
        pairs[q] = (b, latent)
    return pairs, {str(p.relative_to(root)): digest(p) for p in sources}


def signed(value):
    return '0.0000' if abs(value) < .00005 else f'{value:+.4f}'


def write_effect_tables(root=ROOT, output_root=None):
    root = Path(root)
    out = Path(output_root) if output_root else root
    pairs, sources = read_records(root)
    (out / 'tables').mkdir(parents=True, exist_ok=True)
    (out / 'supplement/latent_effect_tables').mkdir(parents=True, exist_ok=True)
    report = dict(source_sha256=sources, latent_heat_J_kg=2450000,
                  difference='latent minus baseline, before rounding', questions=[])
    markdown = ['# 蒸发潜热：四问并列结果', '',
                '本表整理已锁定的两套模型输出，并以独立冷启动记录核对；本轮未重新求解生产PDE。', '',
                '修正方式：`q_in = h*(T_a-T_s) - chi*L_v*j_v`，其中`chi=0/1`分别对应不计/计入潜热；',
                '`j_v=rho_d*h_m*(C_s-C_a)`，`L_v=2.45e6 J/kg`。内部不重复添加相变热源，不重新拟合题给物性参数。',
                'Q1–3干物质参考密度固定；Q4按`rho_d=rho_d0*(R0/R)^2`更新。', '',
                '这些是侧表面相变及有效热容量假设下的条件结果，不是实验验证的唯一答案。', '']
    for q, (b, latent) in pairs.items():
        fields = FIELDS if q <= 2 else [('critical_h', '临界时间', 'h'), ('end_h', '严格输出时间', 'h')]
        if q == 4:
            fields = fields + [('end_radius_cm', '终点半径', 'cm')]
        rows = [dict(key=key, label=label, unit=unit, baseline=b[key], latent=latent[key],
                     difference=latent[key]-b[key]) for key, label, unit in fields]
        time = '1800 s' if q == 1 else '3 h' if q == 2 else '全域达标'
        caption = f'问题{q}：不计与计入表面蒸发潜热的结果对照（{time}）'
        note = f'差值为含潜热减无潜热，先用未舍入值相减再保留四位小数。'
        if q <= 3:
            note += '两组均为1280区间、BDF积分。'
        else:
            note += '无潜热为2560区间，含潜热为1280区间；本表比较生产答案，不作为严格同网格消融。'
        if q == 1:
            note += '含水率差显示为零不代表舍入前逐位相等；理论上水分方程不受本问温度影响。'
        if q >= 3:
            percent = 100 * (latent['critical_h'] - b['critical_h']) / b['critical_h']
            note += f'临界时间延长{percent:.2f}%；严格输出均按临界后至少5 s、向上舍入并全节点回代确定。'
            if q == 4:
                note += '终点半径分别在各自严格终点读取。'
        tex = [r'\begin{table}[htbp]\centering\small',
               r'\caption{'+caption+r'}\label{tab:latent-effect-q'+str(q)+'}',
               r'\begin{tabular}{lrrr}\toprule',
               r'指标 & 不计潜热 & 计入潜热 & 差值\\\midrule']
        markdown += [f'## 问题{q}（{time}）', '',
                     '| 指标 | 不计潜热 | 计入潜热 | 差值 |', '|---|---:|---:|---:|']
        for row in rows:
            label = f'{row["label"]}/({row["unit"]})'
            values = [f'{row["baseline"]:.4f}', f'{row["latent"]:.4f}', signed(row['difference'])]
            tex.append(label+' & '+' & '.join(values)+r'\\')
            markdown.append('| '+label+' | '+' | '.join(values)+' |')
        tex += [r'\bottomrule\end{tabular}',
                r'\par\smallskip\begin{minipage}{.95\linewidth}\footnotesize',
                note.replace('%', r'\%'), r'\end{minipage}', r'\end{table}']
        (out / f'tables/latent_q{q}_comparison.tex').write_text('\n'.join(tex)+'\n', encoding='utf-8')
        markdown += ['', note, '']
        report['questions'].append(dict(question=q, baseline_n=b['settings']['n'],
                                        latent_n=latent['settings']['n'], rows=rows))
    markdown += ['## 使用边界', '',
                 '第一、二问比较同一物理时刻的状态；第三、四问比较同一个全域阈值的临界时间及同一执行规则的严格输出。',
                 '第四问两套模型的几何、物性经验式、环境外推均一致，但生产网格不同，不能将全部未舍入差异归因于单一效应。',
                 '表面冷却不等于模型已经完成气固平衡、内部相变与密度/焓的实验闭合。',
                 '参考依据：[FAO潜热参数说明](https://www.fao.org/4/X0490E/x0490e0k.htm)只支持所取潜热量级。', '',
                 '复现表格：`python -X utf8 code/latent_effect_tables.py`。来源哈希与未舍入差值见`supplement/latent_effect_tables/report.json`。']
    (out / '潜热影响逐问比较.md').write_text('\n'.join(markdown)+'\n', encoding='utf-8')
    (out / 'supplement/latent_effect_tables/report.json').write_text(
        json.dumps(report, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
    return report


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', type=Path, default=ROOT)
    args = parser.parse_args()
    result = write_effect_tables(output_root=args.out)
    print(f'Generated {len(result["questions"])} paired tables; no PDE solve or PDF compilation.')
