"""Q3 OAT time diagnostics. No changes to the production solver or answers."""
from pathlib import Path
from dataclasses import dataclass
import argparse
import hashlib
import json
import platform
import sys
import numpy as np
import scipy
from scipy.integrate import solve_ivp
from s2_solver import Settings
from s2_stable_graded import StableModel

ROOT = Path(__file__).resolve().parents[1]


@dataclass
class Perturbation:
    name: str = 'base'
    ea_scale: float = 1.0
    initial_scale: float = 1.0
    D_scale: float = 1.0
    h_scale: float = 1.0
    hm_scale: float = 1.0


CASES = [Perturbation()]
for key, values in [('ea_scale', (.95, 1.05)), ('D_scale', (.9, 1.1)),
                    ('initial_scale', (.9, 1.1)), ('h_scale', (.9, 1.1)),
                    ('hm_scale', (.1, 10.))]:
    for value in values:
        CASES.append(Perturbation(name=f'{key}_{value:g}', **{key: value}))


class PerturbedModel(StableModel):
    def __init__(self, case, n, method='BDF'):
        if min(case.ea_scale, case.initial_scale, case.D_scale,
               case.h_scale, case.hm_scale) <= 0:
            raise ValueError('All perturbation multipliers must be positive')
        self.case = case
        super().__init__(Settings(question=3, n=n, max_hours=240,
                         D_scale=case.D_scale, h_scale=case.h_scale,
                         hm_scale=case.hm_scale, method=method))

    def properties(self, T, C):
        rho, cp, k, A, beta = super().properties(T, C)
        return rho, cp, k, A*np.exp(-3850*(self.case.ea_scale-1)/(T+273.15)), beta

    def _solve(self, left, right, y, event=None):
        # Intercept only the original initial condition, not later restarts.
        if left == 0:
            y = y.copy()
            y[self.size:] = 2.55*self.case.initial_scale
        return super()._solve(left, right, y, event)


class QuadratureCheck(PerturbedModel):
    """Separate flux assembly and Radau integration, shared physical assumptions."""
    def rhs(self, t, y):
        T, C = y[:self.size], y[self.size:]
        if np.min(C) <= 0:
            raise ValueError('Nonpositive moisture')
        rho, cp, k = 650+128*C, 1450+2736*C/(1+C), .21+.38*C/(1+C)
        A = 2.4e-3*np.exp(-3850*self.case.ea_scale/(T+273.15))
        z, w = np.polynomial.legendre.leggauss(12)
        mid, half = (C[:-1]+C[1:])/2, np.diff(C)/2
        integral = half*np.sum(w[:, None]*np.exp(-.45/(mid+z[:, None]*half)), axis=0)
        radius = .02
        Ta, Ca = self.environment(t)
        heat, water = np.zeros(self.size+1), np.zeros(self.size+1)
        heat[1:-1] = self.faces[1:-1]*(k[:-1]+k[1:])/2*np.diff(T)/self.dx
        water[1:-1] = self.faces[1:-1]*(A[:-1]+A[1:])/2*integral/self.dx*self.case.D_scale
        heat[-1] = radius*25*self.case.h_scale*(Ta-T[-1])
        water[-1] = radius*8e-7*self.case.hm_scale*(Ca-C[-1])
        return np.r_[np.diff(heat)/(radius**2*self.w*rho*cp),
                     np.diff(water)/(radius**2*self.w)]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def formula_tests():
    errors = []
    for case in CASES:
        model = PerturbedModel(case, 8)
        T = np.array([28., 40., 50.])
        C = np.array([.05, .15, 2.55])
        *_, A, beta = model.properties(T, C)
        actual = A*np.exp(-beta/C)*case.D_scale
        expected = 2.4e-3*case.D_scale*np.exp(-3850*case.ea_scale/(T+273.15)-.45/C)
        errors.append(float(np.max(np.abs(actual/expected-1))))
    model = PerturbedModel(Perturbation(initial_scale=1.1), 8)
    sol = model._solve(0, .01, np.r_[np.full(9, 28.), np.full(9, 2.55)])
    assert np.all(sol.y[9:, 0] == 2.55*1.1)
    rejected = False
    try:
        PerturbedModel(Perturbation(initial_scale=0), 8)
    except ValueError:
        rejected = True
    assert rejected and max(errors) < 1e-13
    return dict(cases=len(errors), max_relative_error=max(errors),
                actual_initial_state_checked=True, nonpositive_rejected=rejected)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--out', required=True)
    parser.add_argument('--grid', nargs='+', type=int, default=[320, 640])
    parser.add_argument('--check', action='store_true')
    args = parser.parse_args()
    out = Path(args.out).resolve()
    out.mkdir(parents=True, exist_ok=True)
    identity = {str(p.relative_to(ROOT)): sha(p) for p in
                [Path(__file__), ROOT/'code/s2_solver.py', ROOT/'code/s2_stable_graded.py',
                 ROOT/'data/input1.xlsx', ROOT/'data/input2.xlsx']}
    contract = dict(identity=identity, python=sys.version, scipy=scipy.__version__,
                    numpy=np.__version__, platform=platform.platform(),
                    command=sys.argv, test=formula_tests())
    (out/'environment.json').write_text(json.dumps(contract, indent=2), encoding='utf8')
    runs = [(case, n, False) for n in args.grid for case in CASES]
    if args.check:
        runs += [(case, 320, True) for case in CASES
                 if case.name in ('base', 'ea_scale_1.05', 'hm_scale_0.1')]
    for case, n, independent in runs:
        name = f'{case.name}_n{n}' + ('_radau' if independent else '')
        path = out/f'{name}.json'
        if path.exists():
            saved = json.loads(path.read_text(encoding='utf8'))
            if saved['identity'] != identity:
                raise RuntimeError('Refusing stale cache: '+name)
            continue
        print('START '+name, flush=True)
        model = (QuadratureCheck(case, n, 'Radau') if independent else PerturbedModel(case, n)).run()
        times = np.array([0., model.critical-1, model.critical, model.end])
        states = model.state(times)
        g = states[model.size:].max(axis=0)-.15
        assert g[1] > 0 and abs(g[2]) < 1e-10 and g[3] < 0
        accepted = np.concatenate([p.y[model.size:] for p in model.pieces], axis=1)
        payload = dict(identity=identity, case=vars(case), meta=model.meta,
                       verification_method='Radau + 12-point Gauss flux' if independent else 'BDF + stable integral flux',
                       initial_C=float(states[model.size, 0]), threshold_times_s=times.tolist(),
                       threshold_g=g.tolist(), minimum_accepted_C=float(accepted.min()),
                       maximum_accepted_C=float(accepted.max()),
                       max_outward_increase=float(np.diff(accepted, axis=0).max()), exit_code=0)
        path.write_text(json.dumps(payload, indent=2), encoding='utf8')
        print(f'DONE {name}: {model.critical/3600:.8f} h; {model.meta["elapsed_s"]:.1f} s', flush=True)


if __name__ == '__main__':
    main()
