"""S2 model ablations, material moisture ledger and finite-scenario stopping audit."""
import csv
import hashlib
import itertools
import json
import platform
import sys
import time
import traceback
from pathlib import Path

import numpy as np
import scipy
from numpy.polynomial.legendre import leggauss
from scipy.integrate import quad

from s2_solver import Model, Settings, ROOT, SOURCE
from s2_stable_graded import StableModel, integral_difference

OUT = ROOT/'reproduced/experiments'
AUDIT = ROOT/'reproduced/experiment_audit'
LOG = AUDIT/'runs.jsonl'


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, ensure_ascii=False, allow_nan=False), encoding='utf-8')


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def calculate(label, settings, family='graded'):
    model = (Model(settings) if family == 'arithmetic' else
             StableModel(settings, graded=family != 'uniform'))
    model.run()
    record = dict(label=label, family=family, **model.meta)
    save(OUT/'runs'/f'{label}.json', record)
    with LOG.open('a', encoding='utf-8') as stream:
        stream.write(json.dumps(dict(label=label, exit_code=0, elapsed_s=model.meta['elapsed_s']))+'\n')
    print(label, 'hours=', model.meta['critical_h'], 'seconds=', round(model.meta['elapsed_s'], 2), flush=True)
    return model


def requested_table(model):
    q = model.s.question
    ts = ([100, 300, 600, 900, 1200, 1500, 1800] if q == 1 else
          list(np.arange(1800, 10801, 1800)) if q == 2 else
          list(np.arange(21600, model.end, 21600))+[model.end])
    states = model.state(ts)
    rows = []
    for j, t in enumerate(ts):
        for r in (0., .005, .01, .015, .02, None):
            radius = model.radius(t)
            inside = r is None or r <= radius+1e-12
            x = 1. if r is None else r/radius
            rows.append(dict(time_s=float(t), time_h=float(t/3600),
                             r_cm='surface' if r is None else r*100,
                             radius_cm=radius*100, inside=bool(inside),
                             T_C=float(np.interp(x, model.x, states[:model.size, j])) if inside else None,
                             C_kg_kg=float(np.interp(x, model.x, states[model.size:, j])) if inside else None))
    return rows


def profile_errors(model, reference):
    end = min(model.end, reference.end)
    times = np.unique(np.r_[np.linspace(0, end, 501), np.minimum([100, 300, 600, 1800, 10800], end)])
    xi = np.linspace(0, 1, 201)
    errors = np.zeros(2)
    for start in range(0, len(times), 64):
        batch = times[start:start+64]
        left, right = model.state(batch), reference.state(batch)
        for j in range(len(batch)):
            for k in (0, 1):
                a = np.interp(xi, model.x, left[k*model.size:(k+1)*model.size, j])
                b = np.interp(xi, reference.x, right[k*reference.size:(k+1)*reference.size, j])
                errors[k] = max(errors[k], np.max(abs(a-b)))
    return dict(sample_time_count=len(times), material_locations=len(xi),
                max_T_error_C=float(errors[0]), max_C_error=float(errors[1]),
                event_error_s=None if model.critical is None else abs(model.critical-reference.critical),
                elapsed_s=model.meta['elapsed_s'])


def integrate_boundary(model, order):
    nodes, weights = leggauss(order)
    water, heat = 0., 0.
    for piece in model.pieces:
        left, right = piece.t[:-1], piece.t[1:]
        centers, half = (left+right)/2, (right-left)/2
        times = (centers[:, None]+half[:, None]*nodes).ravel()
        ws = (half[:, None]*weights).ravel()
        for first in range(0, len(times), 128):
            t = times[first:first+128]
            y = piece.sol(t)
            env = np.array([model.environment(v) for v in t])
            radii = np.array([model.radius(v) for v in t])
            water += np.dot(ws[first:first+128], 2*8e-7*model.s.hm_scale/radii*(env[:, 1]-y[-1]))
            heat += np.dot(ws[first:first+128], 2*25*model.s.h_scale/radii*(env[:, 0]-y[model.size-1]))
    return float(water), float(heat)


def conservation(model):
    final = model.state([model.end])[:, 0]
    change = float(2*np.dot(model.w, final[model.size:])-2.55)
    water7, heat7 = integrate_boundary(model, 7)
    water3, heat3 = integrate_boundary(model, 3)
    relative = abs(change-water7)/max(abs(change), 1e-15)
    local = []
    for t in np.linspace(0, model.end, 31):
        y = model.state([t])[:, 0]
        rate = model.rhs(t, y)[model.size:]
        expected = 2*8e-7*model.s.hm_scale/model.radius(t)*(model.environment(t)[1]-y[-1])
        local.append(abs(2*np.dot(model.w, rate)-expected))
    record = dict(mean_C_change=change, integrated_surface_exchange=water7,
                  relative_residual=relative, quadrature_3_vs_7_abs=abs(water3-water7),
                  max_instantaneous_balance_residual=max(local), passed=relative < 1e-5,
                  measure='normalized dry-solid mass, 2*sum(w*C); not unweighted current-volume water mass')
    if model.s.question == 1:
        energy = float(820*2600*(2*np.dot(model.w, final[:model.size])-28))
        heat_error = abs(energy-heat7)/abs(energy)
        record['constant_capacity_heat'] = dict(change_J_m3=energy, exchange_J_m3=heat7,
                                               relative_residual=heat_error, passed=heat_error < 1e-5)
    return record


def extend(model, until):
    if until <= model.end:
        return
    y = model.state([model.end])[:, 0]
    piece = model._solve(model.end, until, y)
    model.pieces.append(piece)
    model.end = float(until)


def unit_tests():
    tests = []
    for a, lo, hi in itertools.product((.89, .45, .3), (.05, .15, 2.55), (1e-8, .02)):
        right = lo*(1+hi)
        val = float(integral_difference(np.array([lo]), np.array([right]), a)[0])
        ref = quad(lambda c: np.exp(-a/c), lo, right, epsabs=1e-22)[0]
        tests.append(dict(name=f'flux_{a}_{lo}_{hi}', error=abs(val-ref)/abs(ref), passed=abs(val-ref)/abs(ref) < 1e-8))
    for q in (1, 2, 3, 4):
        m = StableModel(Settings(question=q, n=16, hm_scale=0, h_scale=0))
        y = np.r_[np.full(m.size, 28.), np.full(m.size, 2.55)]
        error = max(float(np.max(abs(m.rhs(t, y)))) for t in (0., 1800., 100000.))
        tests.append(dict(name=f'no_exchange_uniform_material_q{q}', error=error, passed=error < 1e-12))
    for label, settings in [('negative_D', Settings(D_scale=-1)), ('small_grid', Settings(n=3))]:
        rejected = False
        try:
            StableModel(settings)
        except ValueError:
            rejected = True
        tests.append(dict(name=label, passed=rejected))
    return tests


def scenario_audit(question, nominal_end):
    models, records = [], []
    for ds, dt, dc in itertools.product((.9, 1.1), (-.5, .5), (-.002, .002)):
        label = f'q{question}_scenario_{len(models)}'
        model = calculate(label, Settings(question=question, n=320, D_scale=ds, tail_T_shift=dt, tail_C_shift=dc))
        models.append(model)
        records.append(dict(label=label, D_scale=ds, tail_T_shift=dt, tail_C_shift=dc,
                            critical_h=model.critical/3600))
    worst = int(np.argmax([m.critical for m in models]))
    source = models[worst].s
    fine = calculate(f'q{question}_worst_n640', Settings(question=question, n=640, D_scale=source.D_scale,
                                                       tail_T_shift=source.tail_T_shift, tail_C_shift=source.tail_C_shift))
    robust_end = float(np.ceil((max(fine.critical, max(m.critical for m in models))+60)/60)*60)
    for model, row in zip(models, records):
        extend(model, max(robust_end, nominal_end))
        row['max_C_at_nominal_stop'] = float(model.state([nominal_end])[model.size:].max())
        row['max_C_at_scenario_stop'] = float(model.state([robust_end])[model.size:].max())
        row['nominal_stop_passed'] = row['max_C_at_nominal_stop'] < .15
        row['scenario_stop_passed'] = row['max_C_at_scenario_stop'] < .15
        sample = np.linspace(0, model.end, 601)
        y = model.state(sample)
        np.savez_compressed(OUT/'runs'/f"{row['label']}_trajectory.npz", times_s=sample,
                            xi=model.x, T=y[:model.size], C=y[model.size:])
    extend(fine, robust_end)
    grid_error = abs(fine.critical-models[worst].critical)
    output = dict(question=question, grid_n=320, scenarios=records, worst_index=worst,
                  fine_worst_critical_h=fine.critical/3600, worst_grid_event_difference_s=grid_error,
                  worst_grid_passed=grid_error < 1,
                  nominal_stop_h=nominal_end/3600, scenario_stop_h=robust_end/3600,
                  fine_worst_max_C_at_stop=float(fine.state([robust_end])[fine.size:].max()),
                  nominal_failures=sum(not r['nominal_stop_passed'] for r in records),
                  all_tested_scenarios_passed=all(r['scenario_stop_passed'] for r in records),
                  interpretation='8 finite stress scenarios only; not a confidence interval or continuous-box guarantee')
    save(OUT/f'q{question}_scenarios.json', output)
    return output


def main():
    started = time.perf_counter()
    OUT.mkdir(parents=True, exist_ok=True)
    AUDIT.mkdir(parents=True, exist_ok=True)
    if (OUT/'SUMMARY.json').exists() or LOG.exists():
        raise RuntimeError('Existing experiment evidence must not be overwritten')
    protected = [ROOT/'evidence/RESULTS_LOCK.md', ROOT/'evidence/answers.json', ROOT/'code/s2_solver.py', ROOT/'code/s2_stable_graded.py']
    save(AUDIT/'BASELINE_IDENTITY.json', {str(p): digest(p) for p in protected})
    tests = unit_tests()
    save(AUDIT/'UNIT_TESTS.json', tests)
    assert all(t['passed'] for t in tests)
    summary = dict(stage='S2_PENDING_USER_G2', nominal={}, comparisons={}, ledgers={}, scenarios={})
    for q in (1, 2, 3, 4):
        n = 2560 if q == 4 else 1280
        fine = calculate(f'q{q}_nominal_n{n}', Settings(question=q, n=n))
        summary['nominal'][str(q)] = fine.meta
        rows = requested_table(fine)
        save(OUT/f'q{q}_requested_table.json', rows)
        with (OUT/f'q{q}_requested_table.csv').open('w', newline='', encoding='utf-8-sig') as f:
            writer = csv.DictWriter(f, fieldnames=rows[0].keys())
            writer.writeheader()
            writer.writerows(rows)
        historical = json.loads((ROOT/'evidence/improvement.json').read_text(encoding='utf-8'))['nominal'][str(q)]
        regression = {key: abs(fine.meta[key]-historical[key]) for key in ('center_T', 'surface_T', 'center_C', 'surface_C')}
        regression['event_s'] = 0. if fine.critical is None else abs(fine.critical-historical['critical_s'])
        regression['passed'] = (max(regression['center_T'], regression['surface_T']) < 2e-5 and
                                max(regression['center_C'], regression['surface_C']) < 2e-7 and regression['event_s'] < .05)
        summary['nominal'][str(q)]['historical_regression'] = regression
        summary['ledgers'][str(q)] = conservation(fine)
        comparisons = []
        for family in ('arithmetic', 'uniform', 'graded'):
            s = Settings(question=q, n=160, flux='arithmetic' if family == 'arithmetic' else 'kirchhoff')
            model = calculate(f'q{q}_{family}_n160', s, family)
            comparisons.append(dict(family=family, n=160, **profile_errors(model, fine)))
        summary['comparisons'][str(q)] = comparisons
        save(OUT/'PARTIAL.json', summary)
        del fine, model
    for q in (3, 4):
        summary['scenarios'][str(q)] = scenario_audit(q, summary['nominal'][str(q)]['end_s'])
    factorial = {}
    for props, moving in itertools.product((3, 4), (False, True)):
        model = calculate(f'factor_p{props}_moving{int(moving)}_n320',
                          Settings(question=3, n=320, property_set=props, moving=moving, max_hours=72 if moving else 168))
        factorial[f'p{props}_moving{int(moving)}'] = model.critical/3600
    a, b, c, d = [factorial[key] for key in ('p3_moving0', 'p4_moving0', 'p3_moving1', 'p4_moving1')]
    summary['factorial'] = dict(times_h=factorial, property_effect_at_fixed_h=b-a,
                                geometry_effect_at_p3_h=c-a, interaction_h=d-b-c+a,
                                geometry_effect_at_p4_h=d-b, net_q4_minus_q3_h=d-a,
                                geometry_reduction_p4_percent=100*(b-d)/b)
    summary['elapsed_s'] = time.perf_counter()-started
    summary['protected_unchanged'] = all(digest(Path(p)) == h for p, h in json.loads((AUDIT/'BASELINE_IDENTITY.json').read_text(encoding='utf-8')).items())
    save(OUT/'SUMMARY.json', summary)
    passed = all(v['historical_regression']['passed'] for v in summary['nominal'].values())
    passed &= all(v['passed'] for v in summary['ledgers'].values())
    passed &= summary['ledgers']['1']['constant_capacity_heat']['passed']
    passed &= all(v['worst_grid_passed'] and v['all_tested_scenarios_passed'] and v['fine_worst_max_C_at_stop'] < .15 for v in summary['scenarios'].values())
    passed &= summary['protected_unchanged']
    save(AUDIT/'CHECKS.json', dict(computational_checks_passed=bool(passed), G2_approved=False,
                                   real_world_validation=False, test_count=len(tests)))
    if not passed:
        raise AssertionError('One or more frozen experiment gates failed; inspect saved evidence')


if __name__ == '__main__':
    code = 0
    try:
        main()
    except Exception:
        code = 1
        traceback.print_exc()
    save(AUDIT/'EXECUTION.json', dict(command='python code/experiments.py', exit_code=code,
                                     python=sys.version, executable=sys.executable, platform=platform.platform(),
                                     numpy=np.__version__, scipy=scipy.__version__, stochastic=False))
    sys.exit(code)
