"""Check a fresh production run against frozen answers and all workbook rows."""
from pathlib import Path
import argparse
import hashlib
import json
import math
from openpyxl import load_workbook
from s2_solver import ROOT, Model, Settings


def verify(out):
    old=json.loads((ROOT/'evidence/answers.json').read_text(encoding='utf8'))
    fresh=json.loads((out/'full_report.json').read_text(encoding='utf8'))
    checks=[]; books=[]
    for answer in old:
        q=answer['question']; ref=answer['meta']; got=fresh['result'][str(q)]
        for key,tol in [('center_T',5e-6),('surface_T',5e-6),('center_C',5e-8),
                        ('surface_C',5e-8),('critical_s',.02),('end_s',1e-7)]:
            if ref.get(key) is None: continue
            delta=abs(got[key]-ref[key])
            checks.append(dict(question=q,metric=key,delta=delta,tolerance=tol,pass_=delta<=tol))
        checks.append(dict(question=q,metric='unclipped_positive_state',
            pass_=got['min_accepted_C']>0 and not got['clipping_used']))
        if q>=3: checks.append(dict(question=q,metric='strict_unrounded_stop',pass_=got['max_C_at_end']<.15))
        path=out/f'result{q}.xlsx'; book=load_workbook(path,read_only=True,data_only=True)
        assert book.sheetnames==(['温度','水分浓度'] if q<=2 else ['Sheet1'])
        targets={round(row['time_s'],7):row for row in answer['table_rows']}
        model=Model(Settings(question=q,n=4)); sheet_reports=[]
        for sheet in book:
            thermal=sheet.title=='温度'; field='temperature_C' if thermal else 'moisture'
            rows=iter(sheet.rows); header=[c.value for c in next(rows)]; prev=0.; count=0; matched=0; max_error=0.
            assert header==['时间\\到药材中心的距离']+[i/10 for i in range(20 if q==4 else 21)]+(['药材表面'] if q==4 else [])
            for cells in rows:
                row=[c.value for c in cells]
                count+=1; t=float(row[0]); assert t>prev; prev=t
                if count==1: assert t==(1 if q<=2 else 60)
                if t<got['workbook']['end_s']-1e-7: assert t==count*(1 if q<=2 else 60)
                radius=100*model.radius(t)
                for i in range(20 if q==4 else 21):
                    v=row[i+1]
                    if q==4 and i/10>radius+1e-10: assert v is None
                    else:
                        assert v is not None and math.isfinite(v) and v>0
                        assert cells[i+1].number_format=='0.0000'
                target=targets.get(round(t,7))
                if target:
                    matched+=1
                    for j,column in enumerate((1,6,11,16,21)):
                        expected=target[field][j]
                        if q==4 and j==4:
                            assert expected is None
                            continue
                        if expected is None: assert row[column] is None
                        else:
                            err=abs(row[column]-expected);max_error=max(max_error,err)
                            assert err<=.0000501,(q,t,field,j,err)
                if q==4:
                    assert row[21] is not None and row[21]>0
                    if target: assert abs(row[21]-target[field][-1])<=.0000501
            assert count==got['workbook']['rows']
            assert abs(prev-got['workbook']['end_s'])<1e-7
            assert matched==len(targets)
            sheet_reports.append(dict(sheet=sheet.title,rows=count,table_times=matched,max_rounding_error=max_error))
        book.close()
        books.append(dict(question=q,sha256=hashlib.sha256(path.read_bytes()).hexdigest(),sheets=sheet_reports))
    report=dict(ready=all(x['pass_'] for x in checks),checks=checks,workbooks=books,
        scope=('Frozen-field re-export integrity; not a PDE rerun.' if fresh.get('mode')=='frozen_field_reexport'
               else 'Fresh rerun and rounded export integrity; not independent physical validation.'))
    (out/'verification.json').write_text(json.dumps(report,indent=2),encoding='utf8')
    if not report['ready']: raise AssertionError('Production regression mismatch')
    return report


if __name__=='__main__':
    parser=argparse.ArgumentParser();parser.add_argument('--out',type=Path,required=True)
    args=parser.parse_args();print(json.dumps(verify(args.out),ensure_ascii=False))
