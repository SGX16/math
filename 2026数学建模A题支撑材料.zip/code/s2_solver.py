"""Approved effective radial model; outputs are conditional, pending team review."""
from dataclasses import dataclass, asdict
from pathlib import Path
from functools import lru_cache
import hashlib
import json
import time

import numpy as np
import openpyxl
from scipy.integrate import solve_ivp
from scipy.interpolate import PchipInterpolator
from scipy.sparse import diags, bmat
from scipy.special import expi

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT/'data'


@lru_cache(None)
def inputs():
    arrays = []
    for name in ('input1.xlsx', 'input2.xlsx'):
        book = openpyxl.load_workbook(SOURCE/name, read_only=True, data_only=True)
        arr = np.asarray(list(book.active.values)[1:], dtype=float)
        book.close()
        if not np.isfinite(arr).all() or not np.all(np.diff(arr[:, 0]) > 0):
            raise ValueError('Nonfinite input or invalid time ordering')
        arrays.append(arr)
    return arrays


@dataclass
class Settings:
    question: int = 3
    n: int = 160
    property_set: int = 0
    moving: bool | None = None
    frozen: bool = False
    flux: str = 'kirchhoff'
    method: str = 'BDF'
    boundary: str = 'mean'
    tail_start_h: float = 3.0
    radius_kind: str = 'pchip'
    D_scale: float = 1.0
    h_scale: float = 1.0
    hm_scale: float = 1.0
    tail_T_shift: float = 0.0
    tail_C_shift: float = 0.0
    rtol: float = 2e-9
    atol_T: float = 1e-8
    atol_C: float = 1e-10
    max_hours: float = 72.0
    safe_margin_s: float = 5.0


class Model:
    def __init__(self, settings):
        self.s = settings
        if settings.n < 4 or settings.question not in (1, 2, 3, 4):
            raise ValueError('Invalid grid or question')
        if min(settings.D_scale, settings.h_scale, settings.hm_scale) < 0:
            raise ValueError('Negative transport coefficient')
        self.env, self.rad = inputs()
        self.kind = settings.property_set or (1 if settings.question == 1 else 4 if settings.question == 4 else 3)
        self.moving = settings.question == 4 if settings.moving is None else settings.moving
        self.x = np.linspace(0, 1, settings.n+1)
        self.faces = np.r_[0, (self.x[1:]+self.x[:-1])/2, 1]
        self.w = np.diff(self.faces**2)/2
        self.dx = np.diff(self.x)
        self.size = len(self.x)
        self.tail = self.env[self.env[:, 0] >= settings.tail_start_h*3600, 1:].mean(axis=0)
        self.Rfit = PchipInterpolator(self.rad[:, 0], self.rad[:, 1]/100, extrapolate=False)
        band = diags([np.ones(self.size-1), np.ones(self.size), np.ones(self.size-1)], [-1, 0, 1])
        self.sparse = bmat([[band, band], [band, band]], format='csc')
        self.atol = np.r_[np.full(self.size, settings.atol_T), np.full(self.size, settings.atol_C)]
        self.min_trial_C = 2.55

    def environment(self, t):
        if t <= 14400:
            return np.interp(t, self.env[:, 0], self.env[:, 1]), np.interp(t, self.env[:, 0], self.env[:, 2])
        val = self.env[-1, 1:] if self.s.boundary == 'last' else self.tail
        return val[0]+self.s.tail_T_shift, val[1]+self.s.tail_C_shift

    def radius(self, t):
        if not self.moving:
            return 0.02
        if t < 0 or t > self.rad[-1, 0]+1e-8:
            raise ValueError('Outside measured radius time domain')
        return float(np.interp(t, self.rad[:, 0], self.rad[:, 1])/100 if self.s.radius_kind == 'linear' else self.Rfit(t))

    def properties(self, T, C):
        if np.min(C) <= 0 or np.min(T+273.15) <= 0:
            raise ValueError('Nonpositive C or absolute temperature; no clipping permitted')
        c = np.full_like(C, 2.55) if self.s.frozen else C
        temp = np.full_like(T, 28.0) if self.s.frozen else T
        if self.kind == 1:
            return np.full_like(c, 820), np.full_like(c, 2600), np.full_like(c, .36), np.full_like(c, 7e-9), .89
        if self.kind == 3:
            return 650+128*c, 1450+2736*c/(1+c), .21+.38*c/(1+c), 2.4e-3*np.exp(-3850/(temp+273.15)), .45
        return 760+90*c, 1850+2150*c/(1+c), .12+.20*c/(1+c), 4.2e-4*np.exp(-3850/(temp+273.15)), .30

    @staticmethod
    def primitive(c, a):
        if np.any(c <= 0):
            raise ValueError('Primitive requires positive dry-basis moisture')
        return c*np.exp(-a/c)+a*expi(-a/c)

    def rhs(self, t, y):
        T, C = y[:self.size], y[self.size:]
        self.min_trial_C = min(self.min_trial_C, float(C.min()))
        rho, cp, k, A, a = self.properties(T, C)
        R = self.radius(t)
        Ta, Ca = self.environment(t)
        heat, water = np.zeros(self.size+1), np.zeros(self.size+1)
        heat[1:-1] = self.faces[1:-1]*(k[1:]+k[:-1])/2*np.diff(T)/self.dx
        heat[-1] = R*25*self.s.h_scale*(Ta-T[-1])
        if self.s.frozen:
            water[1:-1] = self.faces[1:-1]*(A[1:]+A[:-1])/2*np.exp(-a/2.55)*np.diff(C)/self.dx
        elif self.s.flux == 'kirchhoff':
            water[1:-1] = self.faces[1:-1]*(A[1:]+A[:-1])/2*np.diff(self.primitive(C, a))/self.dx
        else:
            D = A*np.exp(-a/C)
            water[1:-1] = self.faces[1:-1]*(D[1:]+D[:-1])/2*np.diff(C)/self.dx
        water[1:-1] *= self.s.D_scale
        water[-1] = R*8e-7*self.s.hm_scale*(Ca-C[-1])
        return np.r_[np.diff(heat)/(R*R*self.w*rho*cp), np.diff(water)/(R*R*self.w)]

    def _solve(self, left, right, y, event=None):
        out = solve_ivp(self.rhs, (left, right), y, method=self.s.method,
                        rtol=self.s.rtol, atol=self.atol, jac_sparsity=self.sparse,
                        max_step=30 if left < 14400 else 300, events=event, dense_output=True)
        if not out.success or not np.isfinite(out.y).all() or out.y[self.size:].min() <= 0:
            raise RuntimeError('Solver or physical state guard failed: '+out.message)
        return out

    def run(self):
        start = time.perf_counter()
        y = np.r_[np.full(self.size, 28.), np.full(self.size, 2.55)]
        stop = 1800 if self.s.question == 1 else 10800 if self.s.question == 2 else self.s.max_hours*3600
        def event(t, y):
            return np.max(y[self.size:])-.15
        event.terminal, event.direction = True, -1
        self.pieces, self.critical = [], None
        for left, right in zip([0, min(stop, 14400)], [min(stop, 14400), stop]):
            if right <= left:
                continue
            sol = self._solve(left, right, y, event if self.s.question >= 3 else None)
            self.pieces.append(sol)
            y = sol.y[:, -1]
            if self.s.question >= 3 and len(sol.t_events[0]):
                self.critical = float(sol.t_events[0][0])
                safe = float(np.ceil((self.critical+self.s.safe_margin_s)/.36)*.36)
                if safe > stop:
                    raise RuntimeError('No radius-supported strict feasible endpoint')
                sol = self._solve(self.critical, safe, y)
                self.pieces.append(sol)
                y = sol.y[:, -1]
                if np.max(y[self.size:]) >= .15:
                    raise RuntimeError('Strict threshold guard failed')
                break
        self.end = float(self.pieces[-1].t[-1])
        if self.s.question >= 3 and self.critical is None:
            raise RuntimeError('Threshold not reached within authorized time domain')
        self.meta = dict(settings=asdict(self.s), critical_s=self.critical,
                         critical_h=None if self.critical is None else self.critical/3600,
                         end_s=self.end, end_h=self.end/3600, elapsed_s=time.perf_counter()-start,
                         min_trial_C=self.min_trial_C, min_accepted_C=min(float(p.y[self.size:].min()) for p in self.pieces),
                         max_C_at_end=float(y[self.size:].max()), end_radius_cm=100*self.radius(self.end),
                         center_T=float(y[0]), surface_T=float(y[self.size-1]),
                         center_C=float(y[self.size]), surface_C=float(y[-1]),
                         nfev=sum(p.nfev for p in self.pieces), nlu=sum(p.nlu for p in self.pieces),
                         status='computed_conditional_pending_team_review', clipping_used=False)
        return self

    def state(self, times):
        times = np.asarray(times)
        if np.any(times < 0) or np.any(times > self.end+1e-7):
            raise ValueError('Sampling outside solved interval')
        states = np.empty((2*self.size, len(times)))
        for p in self.pieces:
            mask = (times >= p.t[0]-1e-8) & (times <= p.t[-1]+1e-8)
            if mask.any():
                states[:, mask] = p.sol(times[mask])
        if not np.isfinite(states).all() or np.min(states[self.size:]) <= 0:
            raise RuntimeError('Dense-output physical state guard failed')
        return states

    def export(self, name):
        dest = ROOT/'results/stage2'/name
        dest.mkdir(parents=True, exist_ok=False)
        step = 1 if self.s.question <= 2 else 60
        times = np.unique(np.r_[np.arange(0, self.end, step), self.end])
        r_fixed = np.linspace(0, .02, 21)
        xi = np.linspace(0, 1, 101)
        T, C, U, Tc, Rs = [], [], [], [], []
        for first in range(0, len(times), 256):
            batch = times[first:first+256]
            states = self.state(batch)
            for i, t in enumerate(batch):
                R = self.radius(t)
                coords = r_fixed/R
                tv = np.interp(coords, self.x, states[:self.size, i], right=np.nan)
                cv = np.interp(coords, self.x, states[self.size:, i], right=np.nan)
                T.append(np.r_[tv, states[self.size-1, i]])
                C.append(np.r_[cv, states[-1, i]])
                U.append(np.interp(xi, self.x, states[self.size:, i]))
                Tc.append(np.interp(xi, self.x, states[:self.size, i]))
                Rs.append(R)
        np.savez_compressed(dest/'fields.npz', times_s=times, radius_m=Rs, r_fixed_m=r_fixed,
                            T=T, C=C, xi=xi, C_xi=U, T_xi=Tc)
        if self.critical is not None:
            near = np.array([self.critical-1, self.critical, self.end])
            near_state = self.state(near)[self.size:]
            self.meta['threshold_bracket'] = [dict(t_s=float(t), g=float(near_state[:, i].max()-.15)) for i, t in enumerate(near)]
        (dest/'run.json').write_text(json.dumps(self.meta, indent=2), encoding='utf-8')
        return self.meta
