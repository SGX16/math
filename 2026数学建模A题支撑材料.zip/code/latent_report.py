"""Backfill tables and answers from computed latent-extension records only."""
import json
from pathlib import Path
import numpy as np
from latent_effect_tables import write_effect_tables
from answer_table_pairs import write_pairs

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT/'supplement/latent_extension'


def read(q, n=1280, lv=2450000, method='BDF'):
    return json.loads((OUT/f'q{q}_n{n}_L{lv}_{method}/run.json').read_text(encoding='utf-8'))


def write(name, value):
    (ROOT/name).write_text(value+'\n', encoding='utf-8')


def table(rows, field, positions, q, caption):
    times = sorted(set(row['time_s'] for row in rows))
    time_label = '时间/s' if q == 1 else '时间/h'
    lines = [r'\begin{table}[htbp]\centering\small',
             r'\caption{'+caption+r'}\label{tab:latent-q'+str(q)+'-'+field+'}',
             r'\begin{tabular}{r'+'r'*len(positions)+r'}\toprule',
             time_label+' & '+' & '.join('实际表面' if p == 'surface' else f'{p:g} cm' for p in positions)+r'\\\midrule']
    md = ['| '+time_label+' | '+' | '.join('实际表面' if p == 'surface' else f'{p:g} cm' for p in positions)+' |',
          '|---|'+'---:|'*len(positions)]
    for t in times:
        values = []
        for p in positions:
            row = next(r for r in rows if r['time_s'] == t and r['r_cm'] == p)
            value = row[field]
            values.append('--' if value is None else f'{value:.4f}')
        time_value = f'{t:.0f}' if q == 1 else f'{t/3600:.4f}'
        lines.append(time_value+' & '+' & '.join(values)+r'\\')
        md.append('| '+time_value+' | '+' | '.join(values)+' |')
    lines += [r'\bottomrule\end{tabular}', r'\end{table}']
    return '\n'.join(lines), '\n'.join(md)


def field_difference(q):
    a = np.load(OUT/f'q{q}_n640_L2450000_BDF/fields.npz')
    b = np.load(OUT/f'q{q}_n1280_L2450000_BDF/fields.npz')
    common = np.intersect1d(a['time_s'], b['time_s'])
    ia, ib = np.searchsorted(a['time_s'], common), np.searchsorted(b['time_s'], common)
    x = np.linspace(0, 1, 201)
    errors = {}
    for field in ('T', 'C'):
        ax, bx, av, bv = a['xi'], b['xi'], a[field], b[field]
        errors[field] = max(float(np.max(np.abs(np.interp(x, ax, av[i])-np.interp(x, bx, bv[j])))) for i, j in zip(ia, ib))
    a.close()
    b.close()
    return dict(sample_times=len(common), sample_positions=201, **errors)


def main():
    base = {r['question']: r['meta'] for r in json.loads((ROOT/'evidence/answers.json').read_text(encoding='utf-8'))}
    runs = {q: read(q) for q in range(1, 5)}
    md = ['# 四问答案更新：无潜热基线与表面蒸发扩展', '',
          '本文件数值来自独立运行的程序输出。无潜热结果仍为原 RESULTS_LOCK 口径；含潜热结果以侧表面蒸发、干物质质量换算和有效显热容量为条件，不是已由实验确认的唯一答案。未生成或编译PDF。', '',
          '## 假设与公式', '',
          '逐问并列差值与网格说明见[潜热影响逐问比较](潜热影响逐问比较.md)。该补表从未舍入机器记录生成，不替换本文件的两套锁定答案。', '',
          '- 初态仍为28 ℃、2.55 kg/kg；第二问全程附录3，第四问附录4及原PCHIP半径。',
          '- 蒸发限定在侧表面；端面仍绝热且无传质，不重复添加内部潜热项。',
          '- `rho_d0 = rho(C0)/(1+C0)`；定半径时不变，收缩时 `rho_d = rho_d0*(R0/R)^2`。',
          '- `j_v = rho_d*h_m*(C_s-C_a)`，单位kg/(m²·s)。`-k*T_r = h*(T_s-T_a)+L_v*j_v`。',
          '- `L_v=2.45e6 J/kg`，取值依据[FAO物理参数附录](https://www.fao.org/4/X0490E/x0490e0k.htm)，未根据参考答案拟合。',
          '- 经验湿密度用于热容量，与收缩干密度仅在初态作质量换算，不能据此声称完整多相热力学已闭合。', '',
          '## 直接答案', '', '| 问题与指标 | 不含潜热 | 含潜热条件扩展 |', '|---|---:|---:|']
    comparisons = []
    for q, m in runs.items():
        b = base[q]
        if q <= 2:
            for key, label in [('center_T', '中心温度/℃'), ('surface_T', '表面温度/℃'), ('center_C', '中心含水率/(kg/kg)'), ('surface_C', '表面含水率/(kg/kg)')]:
                md.append(f'| 问题{q}，{label} | {b[key]:.4f} | **{m[key]:.4f}** |')
            answer = f'当考虑上述表面蒸发潜热时，\\textbf{{'+('1800 s' if q == 1 else '3 h')+f'中心/表面温度为{m["center_T"]:.4f}/{m["surface_T"]:.4f} ℃，含水率为{m["center_C"]:.4f}/{m["surface_C"]:.4f} kg/kg}}。两种答案对应不同热边界，不能混用数据文件。'
        else:
            for key, label in [('critical_h', '临界时间/h'), ('end_h', '严格输出时间/h')]:
                md.append(f'| 问题{q}，{label} | {b[key]:.4f} | **{m[key]:.4f}** |')
            answer = f'当考虑上述表面蒸发潜热时，\\textbf{{临界时间为{m["critical_h"]:.4f} h，严格输出时间为{m["end_h"]:.4f} h}}，未舍入最大含水率为{m["max_C_at_end"]:.10f} kg/kg。'
            if q == 4:
                answer += f'结束半径为\\textbf{{{m["end_radius_cm"]:.4f} cm}}。'
            answer += '该结果仅对应名义参数，不能视为原八角点方案的含潜热复验。'
        write(f'tables/latent_q{q}_answer.tex', answer)
        coarse = read(q, 640)
        comparison = dict(question=q,
            center_T_difference=abs(m['center_T']-coarse['center_T']),
            surface_T_difference=abs(m['surface_T']-coarse['surface_T']),
            critical_difference_s=None if q < 3 else abs(m['critical_s']-coarse['critical_s']),
            common_snapshot_difference=field_difference(q))
        comparisons.append(comparison)
    md += ['', '严格输出在临界根后至少延时5 s，再向上舍入到0.0001 h，并用未舍入状态检查所有节点。四位小数是报告格式，不是对真实过程的精度承诺。', '', '## 逐问计算结果', '']
    rd4 = (760+90*2.55)/3.55*(2/runs[4]['end_radius_cm'])**2
    empirical4 = 760+90*runs[4]['center_C']
    mass4 = rd4*(1+runs[4]['center_C'])
    md += [f'密度闭合反查：Q4含潜热严格终点的干密度为{rd4:.4f} kg/m³，中心经验密度为{empirical4:.4f} kg/m³，而按(1+C)rho_d得到{mass4:.4f} kg/m³。两种总体密度解释不相容；当前rho*cp仅作为题给有效容量，不能称为完整多相热力学。', '']
    for q, m in runs.items():
        b = base[q]
        if q <= 2:
            text = f'1280区间计算得到中心/表面温度{m["center_T"]:.4f}/{m["surface_T"]:.4f} ℃；相对无潜热基线分别降低{b["center_T"]-m["center_T"]:.4f}/{b["surface_T"]-m["surface_T"]:.4f} ℃。中心/表面含水率为{m["center_C"]:.4f}/{m["surface_C"]:.4f} kg/kg。'
        else:
            delta = m['critical_h']-b['critical_h']
            text = f'1280区间计算得到临界时间{m["critical_h"]:.8f} h，严格输出时间{m["end_h"]:.4f} h，最大含水率为{m["max_C_at_end"]:.10f} kg/kg。相对无潜热临界时间延长{delta:.4f} h（{100*delta/b["critical_h"]:.2f}\\%）。'
        check = comparisons[q-1]
        text += f'640/1280区间的终点中心、表面温度差为{check["center_T_difference"]:.2e}、{check["surface_T_difference"]:.2e} ℃'
        if q >= 3:
            text += f'，临界时间差为{check["critical_difference_s"]:.5f} s'
        text += '。这属于数值复核，不是物理模型的实测误差。'
        if q == 1:
            l = m['ledger']
            text += f'独立时间求积得到对流供热{l["convective_heat_J_per_kg_dry"]/1000:.3f} kJ/kg干物质、蒸发耗热{l["latent_heat_J_per_kg_dry"]/1000:.3f} kJ/kg干物质，显热变化{l["sensible_energy_J_per_kg_dry"]/1000:.3f} kJ/kg干物质，能量相对残差为{l["energy_relative_residual"]:.2e}。因此本条件下的冷却有能量账本支持，但尚不能据此判定真实药材表面一定达到该温度。'
        md += [f'### 问题{q}', '', text.replace(r'\%', '%'), '']
        summary_text = text[text.index('640/1280区间'):]
        write(f'tables/latent_q{q}_summary.tex', summary_text + f'完整截面列于本问答案表\\ref{{tab:latent-q{q}-' + ('T_C' if q <= 2 else 'C_kg_kg') + '}。')
        tex = []
        fields = ['T_C'] if q == 1 else ['T_C', 'C_kg_kg'] if q == 2 else ['C_kg_kg']
        positions = [0., .5, 1., 1.5, 2.] if q != 4 else [0., .5, 1., 1.5, 2., 'surface']
        for field in fields:
            caption = f'问题{q}表面蒸发扩展的'+('温度（℃）' if field == 'T_C' else '干基含水率（kg/kg）')
            t, markdown = table(m['requested_rows'], field, positions, q, caption)
            tex.append(t)
            md += [caption, '', markdown, '']
        write(f'tables/latent_q{q}_results.tex', '\n\n'.join(tex))
    validation = [r'\begin{table}[htbp]\centering\small',
        r'\caption{含潜热条件扩展的网格与干基收支检查}\label{tab:latent-validation}',
        r'\begin{tabular}{crrr}\toprule',
        r'问题 & 终点最大温差/℃ & 临界时间差/s & 水量相对残差\\\midrule']
    for c in comparisons:
        q = c['question']
        event = '--' if q < 3 else f'{c["critical_difference_s"]:.5f}'
        validation.append(f'{q} & {max(c["center_T_difference"], c["surface_T_difference"]):.2e} & {event} & {runs[q]["ledger"]["water_relative_residual"]:.2e}'+r'\\')
    validation += [r'\bottomrule\end{tabular}\end{table}',
        '温差列取中心与表面两点的较大值；网格为640/1280区间。完整机器报告另列共同60 s快照与201物质位置的场差，不能把终点双点误差称作全场上界。变物性情形核对有效显热率，不声称完整湿物料总能量闭合。']
    sensitivity = []
    for lv in (2300000, 2450000, 2500000):
        sensitivity.append(dict(latent_heat=lv, q3_h=read(3, 320, lv)['critical_h'], q4_h=read(4, 320, lv)['critical_h']))
    validation += [r'\begin{table}[htbp]\centering\small',
        r'\caption{潜热取值情景与临界时长（同为320区间）}\label{tab:latent-sensitivity}',
        r'\begin{tabular}{rrr}\toprule', r'$L_v$/（MJ/kg） & 问题三/h & 问题四/h\\\midrule']
    md += ['## 潜热取值情景', '', '| Lv/(MJ/kg) | 第三问临界/h | 第四问临界/h |', '|---:|---:|---:|']
    for s in sensitivity:
        validation.append(f'{s["latent_heat"]/1e6:.2f} & {s["q3_h"]:.4f} & {s["q4_h"]:.4f}'+r'\\')
        md.append(f'| {s["latent_heat"]/1e6:.2f} | {s["q3_h"]:.4f} | {s["q4_h"]:.4f} |')
    validation += [r'\bottomrule\end{tabular}\end{table}']
    independent = []
    for q in (1, 3):
        a, b = read(q, 320), read(q, 320, method='Radau')
        independent.append(dict(question=q, endpoint_temperature_difference=max(abs(a['center_T']-b['center_T']), abs(a['surface_T']-b['surface_T'])),
            event_difference_s=None if q == 1 else abs(a['critical_s']-b['critical_s'])))
    validation.append(f'同为320区间时，以Radau替代BDF复算第一、三问，第一问终点双点最大温差为{independent[0]["endpoint_temperature_difference"]:.2e} ℃，第三问临界时间差为{independent[1]["event_difference_s"]:.3e} s。两者共享空间离散与物理假设，属于替代时间积分核验，不是独立物理模型验证。另有四问零潜热退化、零蒸发边界及第一问水分不变性共9项测试。')
    write('tables/latent_validation.tex', '\n'.join(validation))
    external = [dict(q=1, metric='center_T', reference=11.1867), dict(q=1, metric='surface_T', reference=12.5943),
        dict(q=2, metric='center_T', reference=30.9795), dict(q=2, metric='surface_T', reference=31.6111),
        dict(q=3, metric='critical_h', reference=60.46750514), dict(q=4, metric='end_h', reference=56.4362)]
    md += ['', '## 与用户提供截图的比较', '', '截图只有数字，没有方程、潜热取值、质量换算或源码；来源未核实，不能称为官方标准答案。下面严格区分第三问临界根与第四问严格时间。', '',
           '| 指标 | 本次计算 | 截图参考 | 本次减参考 |', '|---|---:|---:|---:|']
    for e in external:
        value = runs[e['q']][e['metric']]
        e.update(computed=value, difference=value-e['reference'])
        md.append(f'| Q{e["q"]} {e["metric"]} | {value:.8f} | {e["reference"]:.8f} | {value-e["reference"]:+.8f} |')
    md += ['', '差异明显大于本轮网格误差，不能归为显示舍入。潜热数值、干物质密度、潜热位置、长期环境外推和收缩质量换算都可能造成模型差异；没有对方公式时不能确定是哪一项，也未反向调参逼近截图。', '',
        '## 验证与复现', '', f'- 9项结构测试，详见 `supplement/latent_extension/tests.json`。',
        '- 主解320/640/1280三层网格，另有四个潜热情景和两次Radau复算，共18次主/对照求解；测试中另运行第一问两次。',
        '- 保存JSON截面、每60 s原生网格NPZ快照、环境版本与源码/输入哈希；双模型工作簿冷启动状态与入口见下节。',
        '- 第三问与第二问采用同一动力系统，第三问NPZ轨道同时给出第二问含潜热长期演化。',
        '- 不重新渲染PDF，故本轮没有排版/页数/逐页视觉验收。', '', '```powershell',
        'python -X utf8 code/latent_extension.py --tests --n 320 640 1280 --extended',
        'python -X utf8 code/latent_report.py', '```', '',
        '机器检查只支持实现、收支和离散一致性；气固平衡、真实相变位置、经验密度兼容性及端面潜热效应仍未经实验验证。']
    cold_path = ROOT/'runs/cold_dual_20260912/output/report.json'
    md += ['', '## 双模型从零复现', '',
           '`python -X utf8 code/reproduce_dual.py --out dual_output --workbooks`', '',
           '输出目录必须不存在。两套结果分入baseline/latent，各生成result1--4.xlsx；Q2为全过程逐秒温湿数据，Q3/4为60 s水分数据并追加严格终点。源码不读取锁定答案来计算。']
    if cold_path.exists():
        cold = json.loads(cold_path.read_text(encoding='utf-8'))
        if cold['ready']:
            md += ['', '本轮已经在仅有代码和两份输入的新目录完成八条生产网格轨道复算、八份工作簿导出和回读。实际文件：`runs/cold_dual_20260912/output/`。', '',
                   '| 模型 | Q2结束/h | Q2每张表行数 | 六张工作表数据行合计 |', '|---|---:|---:|---:|']
            receipt = []
            for name, family in cold['cases'].items():
                rows = sum(c['workbook']['rows']*len(c['workbook']['verification']['sheets']) for c in family.values())
                md.append(f'| {name} | {family["3"]["meta"]["end_h"]:.4f} | {family["2"]["workbook"]["rows"]} | {rows} |')
                receipt.append(('无潜热' if name == 'baseline' else '含潜热')+f'六张工作表共{rows}条数据行')
            text = '冷启动记录见工程中的\\texttt{runs/cold\\_dual\\_20260912/output/report.json}。'+ '；'.join(receipt)+'。八份工作簿均重新导出并回读，八条轨道均从统一初态独立推进；完整截面及关键终值另与原锁定记录比较。该复现不是对物理假设的实验验证，正式支撑包仍需检查大小与AI详情材料。'
            write('tables/cold_dual_receipt.tex', text)
    else:
        md += ['', '本轮冷启动尚未形成完成报告，不能据此声称双套工作簿已通过。']
    write('答案更新_潜热对照.md', '\n'.join(md))
    matrix = ['# 本轮逐问答案与证据矩阵', '',
              '无潜热为原题有效模型主口径；含潜热为侧表面蒸发条件扩展，不能混用工作簿。', '',
              '| 问题 | 模型与任务 | 无潜热直接答案 | 含潜热直接答案 | 输出及验证 |', '|---|---|---|---|---|']
    tasks = {1:'附录2，恒热物性、非线性水分扩散；七时刻五位置',
             2:'初态起统一附录3；六个半小时时刻、全过程逐秒输出',
             3:'附录3同一动力系统、全域最大值临界与严格判停',
             4:'附录4、PCHIP半径、干基物质坐标与当前表面'}
    evidence = {1:'result1两表；网格、Bessel导热特例、端面导热、能量账本和水分不变量',
                2:'result2两表至各自严格终点；联立反馈、冻结物性、网格与字段回读',
                3:'result3每60 s与严格末行；全节点回代、网格、单因素、潜热情景',
                4:'result4固定列加实际表面、域外留空；质量测度、零输运、四格、潜热网格'}
    for q in range(1,5):
        b,m = base[q],runs[q]
        if q <= 2:
            values = [f'Tc/Ts={r["center_T"]:.4f}/{r["surface_T"]:.4f} ℃；Cc/Cs={r["center_C"]:.4f}/{r["surface_C"]:.4f} kg/kg' for r in (b,m)]
        else:
            values = [f'临界{r["critical_h"]:.4f} h；严格{r["end_h"]:.4f} h' for r in (b,m)]
        matrix.append(f'| {q} | {tasks[q]} | {values[0]} | {values[1]} | {evidence[q]} |')
    matrix += ['', '证据源：evidence/answers.json、supplement/latent_extension/comparison.json；最新冷启动身份与未舍入对照见audit/SYNC_CHECK.json。',
               '不含潜热八角点方案不适用于未经回代的含潜热情景；数值复现不等于物理实验、完整密度闭合或PDF验收。']
    write('audit/ANSWER_MATRIX.md','\n'.join(matrix))
    result = dict(runs=runs, grid_comparison=comparisons, sensitivity=sensitivity,
                  alternative_integrator=independent, external_unverified_comparison=external,
                  baseline_source='evidence/answers.json', status='conditional_extension_not_experimentally_validated')
    (OUT/'comparison.json').write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
    write_effect_tables(ROOT)
    write_pairs(ROOT)
    print('Generated four question tables, answers, verification tables and Markdown; no PDF.')


if __name__ == '__main__':
    main()
