"""Redraw locked evidence and add a numerical error/runtime comparison."""
from pathlib import Path
import csv
import hashlib
import json

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import LinearSegmentedColormap
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "figures"
plt.rcParams.update({
    "font.family": ["Times New Roman", "SimSun"],
    "font.size": 9, "mathtext.fontset": "stix",
    "axes.unicode_minus": False, "axes.linewidth": .65,
    "axes.spines.top": False, "axes.spines.right": False,
    "xtick.labelsize": 8, "ytick.labelsize": 8,
    "legend.frameon": False, "pdf.fonttype": 42, "svg.fonttype": "none",
})
BLUE, TEAL, GOLD, RED = "#426882", "#207C77", "#AC7C32", "#BA514C"


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(fig, name):
    fig.savefig(OUT / (name + ".pdf"), facecolor="white", dpi=600)
    fig.savefig(OUT / (name + ".svg"), facecolor="white", dpi=600)
    fig.savefig(OUT / (name + ".png"), facecolor="white", dpi=600)
    plt.close(fig)


summary_path = ROOT / "evidence/improvement.json"
summary = json.loads(summary_path.read_text(encoding="utf8"))
fig, axes = plt.subplots(1, 2, figsize=(155 / 25.4, 58 / 25.4), sharey=True)
fig.subplots_adjust(left=.10, right=.985, bottom=.24, top=.85, wspace=.19)
points = []
for ax, q in zip(axes, [3, 4]):
    rows = summary["comparisons"][str(q)]
    assert [r["family"] for r in rows] == ["arithmetic", "uniform", "graded"]
    assert all(r["n"] == 160 for r in rows)
    for m, row, color, marker in zip(range(3), rows, [BLUE, GOLD, TEAL], ["o", "s", "D"]):
        x, y = row["elapsed_s"], row["event_error_s"]
        ax.scatter(x, y, color=color, marker=marker, s=32, zorder=3)
        dx = -7 if (q == 3 and m == 2) or (q == 4 and m in [0, 1]) else 7
        ax.annotate(f"M{m}: {y:.4f} s", (x, y), xytext=(dx, 7),
                    textcoords="offset points", ha="right" if dx < 0 else "left",
                    color=color, fontsize=8.5)
        points.append({"question": q, "method": f"M{m}",
                       "elapsed_s": x, "event_error_s": y})
    ax.set(yscale="log", ylim=(.4, 850), xlabel="单次运行耗时 / s")
    ax.set_title(f"问题{q}", loc="left", fontsize=9.5, pad=6)
    ax.grid(axis="y", which="major", color="#E0E5E8", lw=.5)
axes[0].set(xlim=(15, 49), xticks=[20, 30, 40], ylabel="绝对事件时间误差 / s")
axes[1].set(xlim=(22, 65), xticks=[30, 40, 50, 60])
save(fig, "event_runtime_comparison")
with (OUT / "event_runtime_comparison.csv").open("w", newline="", encoding="utf8") as f:
    writer = csv.DictWriter(f, fieldnames=list(points[0]))
    writer.writeheader()
    writer.writerows(points)

field_path = ROOT / "evidence/q4_fields.npz"
d = np.load(field_path)
t = d["times_s"] / 3600
r = d["radius_m"] * 100
fixed = d["r_fixed_m"] * 100
C = d["C"][:, :21]
assert len(t) == 3067 and C.shape == (3067, 21)
assert np.all(np.diff(t) > 0) and np.all(np.diff(r) <= 1e-12)
cmap = LinearSegmentedColormap.from_list("water", ["#F5F9F8", "#B9D6CF", "#629F96", "#204E57"])
cmap.set_bad("#E4E7E9")
fig = plt.figure(figsize=(120 / 25.4, 58 / 25.4))
ax = fig.add_axes([.12, .22, .29, .62])
cbax = fig.add_axes([.425, .22, .018, .62])
right = fig.add_axes([.655, .22, .33, .62])
im = ax.pcolormesh(t, fixed, np.ma.masked_invalid(C.T), shading="auto",
                  cmap=cmap, vmin=.05, vmax=2.55, rasterized=True)
ax.fill_between(t, r, 2, color="#E4E7E9", zorder=2)
ax.plot(t, r, color=RED, lw=1.0, zorder=3)
ax.text(30, 1.8, "当前域外", ha="center", fontsize=8, color="#50585E")
ax.set(xlim=(0, t[-1]), ylim=(0, 2), xlabel="时间 / h", ylabel="实际半径 / cm",
       xticks=[0, 20, 40], yticks=[0, .5, 1, 1.5, 2])
cb = fig.colorbar(im, cax=cbax, ticks=[.05, 1.3, 2.55])
cb.ax.tick_params(labelsize=7.5, length=2)
cb.outline.set_visible(False)
fig.text(.095, .925, "含水率 / (kg/kg)", fontsize=8.5)
selected = []
for target, color, style in zip([6, 12, 24, 48],
                               [BLUE, GOLD, TEAL, RED], ["-", "--", "-.", ":"]):
    idx = int(np.argmin(abs(t - target)))
    assert abs(t[idx] - target) < 1e-10
    x, y = d["xi"] * r[idx], d["C_xi"][idx]
    right.plot(x, y, color=color, ls=style, lw=1.05, label=f"{target} h")
    selected.append({"time_h": float(t[idx]), "points": len(y),
                     "x_y_sha256": hashlib.sha256(np.c_[x, y].tobytes()).hexdigest()})
right.axhline(.15, color="#808A90", lw=.65, ls="--")
right.set(xlim=(0, 2), ylim=(0, 2.55), xlabel="实际半径 / cm",
          ylabel="含水率 / (kg/kg)", xticks=[0, 1, 2], yticks=[0, 1, 2])
right.grid(axis="y", color="#E2E7E9", lw=.45)
right.legend(fontsize=7.5, loc="upper right", handlelength=2.0, labelspacing=.15)
save(fig, "q4_domain_refined")
identity = {
    "inputs": {str(p.relative_to(ROOT)): digest(p) for p in [summary_path, field_path]},
    "model_recomputed": False, "comparison_points": points,
    "q4_times": len(t), "q4_fixed_locations": len(fixed), "q4_sections": selected,
    "q4_nan_mask_sha256": hashlib.sha256(np.isnan(C).tobytes()).hexdigest(),
    "q4_field_sha256": hashlib.sha256(C.tobytes()).hexdigest(),
    "outputs": {str(p.name): digest(p) for name in ["q4_domain_refined", "event_runtime_comparison"]
                for p in [OUT / (name + "." + ext) for ext in ["pdf", "svg", "png"]]},
}
(OUT / "final_figures_identity.json").write_text(
    json.dumps(identity, ensure_ascii=False, indent=2), encoding="utf8")
print("Exported two figures; source data and equations unchanged.")
