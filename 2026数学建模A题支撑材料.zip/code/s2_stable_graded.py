"""Stable close-state Kirchhoff differences, avoiding cancellation on graded grids."""
import json
import numpy as np
from scipy.integrate import quad
from s2_solver import Model, Settings, ROOT


def integral_difference(left, right, a):
    delta = right-left
    midpoint = (left+right)/2
    close = abs(delta) < .01*midpoint
    out = np.empty_like(left)
    far = ~close
    if far.any():
        out[far] = Model.primitive(right[far], a)-Model.primitive(left[far], a)
    # Three-point Gaussian quadrature has no subtraction of nearly equal primitives.
    mid, half = midpoint[close], delta[close]/2
    offset = np.sqrt(3/5)*half
    out[close] = half*(5/9*np.exp(-a/(mid-offset))+8/9*np.exp(-a/mid)+5/9*np.exp(-a/(mid+offset)))
    return out


class StableModel(Model):
    def __init__(self, settings, graded=True):
        super().__init__(settings)
        self.graded = graded
        if graded:
            s = np.linspace(0, 1, self.s.n+1)
            self.x = 1-(1-s)**1.5
            self.faces = np.r_[0, (self.x[1:]+self.x[:-1])/2, 1]
            self.w = np.diff(self.faces**2)/2
            self.dx = np.diff(self.x)

    def rhs(self, t, y):
        T, C = y[:self.size], y[self.size:]
        self.min_trial_C = min(self.min_trial_C, float(C.min()))
        rho, cp, k, A, a = self.properties(T, C)
        R = self.radius(t)
        Ta, Ca = self.environment(t)
        heat, water = np.zeros(self.size+1), np.zeros(self.size+1)
        heat[1:-1] = self.faces[1:-1]*(k[1:]+k[:-1])/2*np.diff(T)/self.dx
        heat[-1] = R*25*self.s.h_scale*(Ta-T[-1])
        water[1:-1] = self.faces[1:-1]*(A[1:]+A[:-1])/2*integral_difference(C[:-1], C[1:], a)/self.dx*self.s.D_scale
        water[-1] = R*8e-7*self.s.hm_scale*(Ca-C[-1])
        return np.r_[np.diff(heat)/(R*R*self.w*rho*cp), np.diff(water)/(R*R*self.w)]

    def run(self):
        super().run()
        self.meta['mesh'] = dict(kind='surface_graded' if self.graded else 'uniform',
                                 mapping='xi=1-(1-s)^1.5' if self.graded else 'xi=s',
                                 stable_close_state_flux=True,
                                 min_dxi=float(self.dx.min()), max_dxi=float(self.dx.max()))
        return self


def main():
    tests = []
    for a in (.89, .45, .30):
        for c in (.05, .15, 1., 2.55):
            for fraction in (1e-8, .001, .009, .02):
                right = c*(1+fraction)
                value = float(integral_difference(np.array([c]), np.array([right]), a)[0])
                exact, _ = quad(lambda x: np.exp(-a/x), c, right, epsabs=1e-20)
                error = abs(value-exact)/max(abs(exact), 1e-30)
                tests.append(dict(a=a, c=c, fraction=fraction, relative_error=error, passed=error < 1e-8))
    testpath = ROOT/'audit/stage2/STABLE_FLUX_TESTS.json'
    testpath.write_text(json.dumps(tests, indent=2), encoding='utf-8')
    if not all(t['passed'] for t in tests):
        raise AssertionError('Stable flux quadrature check failed')
    for q in (1, 2, 3, 4):
        for n in (320, 640, 1280):
            name = f'q{q}_stable_graded_n{n}'
            if (ROOT/'results/stage2'/name/'run.json').exists():
                continue
            meta = StableModel(Settings(question=q, n=n)).run().export(name)
            with (ROOT/'logs/stage2/stable_graded.jsonl').open('a', encoding='utf-8') as f:
                f.write(json.dumps(dict(name=name, exit_code=0, **meta))+'\n')
            print(name, meta['critical_h'], round(meta['elapsed_s'], 2), flush=True)


if __name__ == '__main__':
    main()
