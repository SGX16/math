"""Additional diagnostics, not replacement primary answers. Run from any cwd."""
from pathlib import Path
import json
import numpy as np
from scipy.integrate import solve_ivp
from s2_solver import Model, Settings
from s2_stable_graded import StableModel

BASE = Path(__file__).resolve().parents[1]
OUT = BASE / 'supplement'
OUT.mkdir(exist_ok=True)


def simulate(q, name, **kwargs):
    path = OUT / f'q{q}_{name}.json'
    if path.exists():
        return json.loads(path.read_text(encoding='utf8'))
    s = Settings(question=q, n=160, **kwargs)
    model = Model(s) if s.frozen else StableModel(s, graded=True)
    model.run()
    ts = np.linspace(0, 1800 if q == 1 else 10800, 181)
    field = model.state(ts)
    C, T = field[model.size:], field[:model.size]
    result = {'meta': model.meta, 'time_s': ts.tolist(),
              'Tc': T[0].tolist(), 'Ts': T[-1].tolist(),
              'Cc': C[0].tolist(), 'Cs': C[-1].tolist(),
              'Cmean': (2*model.w @ C).tolist(),
              'Tmean': (2*model.w @ T).tolist()}
    path.write_text(json.dumps(result, indent=2), encoding='utf8')
    print(f'completed q{q} {name}', flush=True)
    return result


def main():
    runs = {}
    for q in (1, 2):
        runs[f'q{q}_base'] = simulate(q, 'base')
        for par in ('D_scale', 'h_scale', 'hm_scale'):
            for scale, label in ((.9, 'minus'), (1.1, 'plus')):
                key = f'q{q}_{par}_{label}'
                runs[key] = simulate(q, f'{par}_{label}', **{par: scale})
    frozen = simulate(2, 'frozen', frozen=True)
    envmodel = Model(Settings(question=1, n=160))
    ts = np.asarray(runs['q1_base']['time_s'])
    sol = solve_ivp(lambda t, y: 2*25/(820*2600*.02)*(envmodel.environment(t)[0]-y),
                    (0, 1800), [28.], t_eval=ts, rtol=1e-10, atol=1e-11, max_step=2.)
    assert sol.success
    lumped = {'time_s': ts.tolist(), 'T': sol.y[0].tolist()}
    (OUT/'q1_lumped.json').write_text(json.dumps(lumped, indent=2), encoding='utf8')
    sensitivities = []
    for q in (1, 2):
        base = runs[f'q{q}_base']
        for par in ('D_scale', 'h_scale', 'hm_scale'):
            low, high = (runs[f'q{q}_{par}_{v}'] for v in ('minus', 'plus'))
            row = {'question': q, 'parameter': par}
            for metric in ('Tc', 'Ts', 'Cc', 'Cs', 'Cmean'):
                b, lo, hi = (v[metric][-1] for v in (base, low, high))
                row[metric] = {'base': b, 'minus': lo, 'plus': hi,
                               'central_difference_per_scale': (hi-lo)/.2}
            sensitivities.append(row)
    # A uniform frozen model is compared to a uniform variable model as well.
    uniform = Model(Settings(question=2, n=160))
    uniform.run()
    y = uniform.state(np.array([10800.]))[:, 0]
    comparison = {'q1_lumped_T1800': float(sol.y[0, -1]),
                  'q1_radial_Tc': runs['q1_base']['Tc'][-1],
                  'q1_radial_Ts': runs['q1_base']['Ts'][-1],
                  'q2_frozen': {k: frozen[k][-1] for k in ('Tc','Ts','Cc','Cs')},
                  'q2_variable_uniform': dict(zip(('Tc','Ts','Cc','Cs'),
                     map(float, (y[0], y[uniform.size-1], y[uniform.size], y[-1]))))}
    summary = {'scope': '160 intervals, diagnostics only, +/-10% is a designed perturbation, not a confidence interval',
               'comparison': comparison, 'sensitivity': sensitivities}
    (OUT/'SUMMARY.json').write_text(json.dumps(summary, indent=2), encoding='utf8')
    print(json.dumps(comparison, indent=2), flush=True)


if __name__ == '__main__':
    main()
