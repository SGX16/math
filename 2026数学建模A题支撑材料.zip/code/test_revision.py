"""Focused regression tests for the revised manuscript diagnostics."""
import json
from pathlib import Path
import unittest
import numpy as np
from scipy.integrate import quad
from s2_solver import Model, Settings
from s2_stable_graded import StableModel, integral_difference

ROOT = Path(__file__).resolve().parents[1]


class RevisionTests(unittest.TestCase):
    def test_integral_against_independent_quadrature(self):
        for a in (.30,.45,.89):
            for c in (.05,.15,1.,2.55):
                for d in (0.,1e-8,.009,.02):
                    right=c*(1+d)
                    got=integral_difference(np.array([c]),np.array([right]),a)[0]
                    ref=quad(lambda x:np.exp(-a/x),c,right,epsabs=1e-24)[0]
                    self.assertAlmostEqual(got/max(abs(ref),1e-30),ref/max(abs(ref),1e-30),places=8)
                    rev=integral_difference(np.array([right]),np.array([c]),a)[0]
                    self.assertAlmostEqual(got+rev,0.,places=17)

    def test_annular_weights(self):
        for n in (20,160):
            m=StableModel(Settings(question=1,n=n))
            self.assertAlmostEqual(float(2*m.w.sum()),1.)
            self.assertTrue(np.all(m.dx>0))
            self.assertTrue(np.all(m.w>0))

    def test_dry_mass_material_manufactured_state(self):
        m=StableModel(Settings(question=4,n=20,D_scale=0,hm_scale=0))
        y=np.r_[np.full(m.size,28.),2.55-.1*m.x**2]
        for t in (0,3600,10800):
            np.testing.assert_array_equal(m.rhs(t,y)[m.size:],np.zeros(m.size))

    def test_boundary_ledger_rhs(self):
        for q in (1,2,3,4):
            m=StableModel(Settings(question=q,n=20))
            y=np.r_[28+3*m.x**2,2.55-.2*m.x**2]
            t=1800.
            got=float(2*m.w @ m.rhs(t,y)[m.size:])
            ref=2*8e-7/m.radius(t)*(m.environment(t)[1]-y[-1])
            self.assertAlmostEqual(got,ref,places=14)

    def test_supplementary_outputs_and_decoupling(self):
        s=json.loads((ROOT/'supplement/SUMMARY.json').read_text())
        self.assertEqual(len(s['sensitivity']),6)
        for row in s['sensitivity']:
            for field in ('Tc','Ts','Cc','Cs','Cmean'):
                self.assertTrue(np.isfinite(list(row[field].values())).all())
            if row['question']==1 and row['parameter']=='h_scale':
                self.assertLess(abs(row['Cmean']['plus']-row['Cmean']['minus']),1e-8)
        c=s['comparison']
        self.assertGreater(c['q2_frozen']['Cc'],c['q2_variable_uniform']['Cc'])
        self.assertLess(c['q2_frozen']['Cs'],c['q2_variable_uniform']['Cs'])

    def test_frozen_property_identity(self):
        m=Model(Settings(question=2,n=20,frozen=True))
        a=m.properties(np.full(m.size,28.),np.full(m.size,2.55))
        b=m.properties(np.full(m.size,50.),np.full(m.size,.15))
        for x,y in zip(a,b): np.testing.assert_array_equal(x,y)


if __name__=='__main__':
    unittest.main(verbosity=2)
