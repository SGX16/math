"""Re-export frozen fine-grid fields without solving or altering their numbers."""
from pathlib import Path
import copy
import argparse
import hashlib
import json
import numpy as np
from openpyxl import Workbook
from openpyxl.cell import WriteOnlyCell
from s2_solver import ROOT
from verify_reproduction import verify


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--q2-fields', type=Path, required=True,
                        help='Frozen full-process Q2 NPZ, not the short 3 h field')
    parser.add_argument('--out', type=Path, required=True)
    args=parser.parse_args()
    if not args.q2_fields.is_file():
        raise FileNotFoundError(args.q2_fields)
    out=args.out
    out.mkdir(parents=True, exist_ok=False)
    answers=json.loads((ROOT/'evidence/answers.json').read_text(encoding='utf8'))
    result={}
    sources=[]
    for answer in answers:
        q=answer['question']
        path=args.q2_fields if q==2 else ROOT/f'evidence/q{q}_fields.npz'
        with np.load(path) as data:
            times=data['times_s']
            step=1 if q<=2 else 60
            selected=np.flatnonzero(times>=step)
            names=['温度','水分浓度'] if q<=2 else ['Sheet1']
            book=Workbook(write_only=True)
            for name in names:
                sheet=book.create_sheet(name)
                sheet.append(['时间\\到药材中心的距离']+[i/10 for i in range(20 if q==4 else 21)]+(['药材表面'] if q==4 else []))
                field=data['T' if name=='温度' else 'C']
                for idx in selected:
                    vals=field[idx,:21] if q!=4 else np.r_[field[idx,:20],field[idx,-1]]
                    cells=[]
                    for value in vals:
                        cell=WriteOnlyCell(sheet, value=None if not np.isfinite(value) else round(float(value),4))
                        cell.number_format='0.0000'
                        cells.append(cell)
                    sheet.append([float(times[idx])]+cells)
            book.save(out/f'result{q}.xlsx')
            meta=copy.deepcopy(answer['meta'])
            meta['workbook']=dict(rows=len(selected), end_s=float(times[-1]), step_s=step)
            result[str(q)]=meta
        sources.append(dict(question=q, path=str(path), sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
        print('EXPORTED',q,len(selected),flush=True)
    report=dict(mode='frozen_field_reexport', result=result, sources=sources,
                scope='No PDE rerun in this exporter; frozen fine-grid values are reused without interpolation')
    (out/'full_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf8')
    check=verify(out)
    assert check['ready']
    print('VERIFIED',len(check['checks']),flush=True)


if __name__=='__main__':
    main()
