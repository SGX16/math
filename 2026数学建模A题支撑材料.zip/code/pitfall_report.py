"""Generate TeX diagnostic tables and the answer update from machine evidence."""
import json
from s2_solver import ROOT


def main():
    report=json.loads((ROOT/'supplement/pitfall_audit/report.json').read_text(encoding='utf8'))
    cases={c['name']:c for c in report['cases']}
    locked=json.loads((ROOT/'evidence/answers.json').read_text(encoding='utf8'))
    lines=[r'\begin{table}[htbp]\centering\small',
           r'\caption{错误判停准则的同轨迹回代（640区间）}\label{tab:pitfall_stop}',
           r'\begin{tabular}{llll}\toprule',
           r'问题与错误准则 & 判停时间/h & 最大含水率/(kg/kg) & 满足全域要求\\\midrule']
    for q in (3,4):
        for mode,title in [('surface','表面'),('mean','均值')]:
            d=cases[f'q{q}_nominal']['wrong_stop'][mode]
            lines.append(f'{q}：{title} & {d["time_h"]:.4f} & {d["actual_max_C"]:.4f} & 否'+r'\\')
    lines += [r'\bottomrule\end{tabular}',r'\end{table}']
    (ROOT/'tables/pitfall_wrong_stop.tex').write_text('\n'.join(lines)+'\n',encoding='utf8')
    combos=[('末段均值','PCHIP','q3_nominal','q4_nominal'),
            ('50 ℃ / 0.05','PCHIP','q3_constant50','q4_constant50'),
            ('末观测值','PCHIP','q3_last','q4_last'),
            ('末段均值','线性','q3_nominal','q4_linear'),
            ('50 ℃ / 0.05','线性','q3_constant50','q4_linear_constant50')]
    lines=[r'\begin{table}[htbp]\centering\small',
           r'\caption{长期环境与半径插值对临界时间的影响（640区间）}\label{tab:pitfall_closure}',
           r'\begin{tabular}{llll}\toprule',
           r'4 h后环境 & 第四问半径插值 & 第三问/h & 第四问/h\\\midrule']
    for environment,kind,c3,c4 in combos:
        lines.append(f'{environment} & {kind} & {cases[c3]["meta"]["critical_h"]:.4f} & {cases[c4]["meta"]["critical_h"]:.4f}'+r'\\')
    lines += [r'\bottomrule\end{tabular}',r'\end{table}']
    (ROOT/'tables/pitfall_closures.tex').write_text('\n'.join(lines)+'\n',encoding='utf8')
    q3=cases['q3_nominal'];q4=cases['q4_nominal']
    linear=(cases['q4_linear']['meta']['critical_h']-q4['meta']['critical_h'])*3600
    hm=cases['q3_hm2']['meta']['critical_h']
    summary=(f'第三问取末点而非末段均值时，临界时间缩短{q3["meta"]["critical_h"]-cases["q3_last"]["meta"]["critical_h"]:.4f} h；'
             f'第四问仅改线性半径插值时，临界时间增加{linear:.2f} s。'
             f'第三问将$h_m$加倍后，临界时间为{hm:.4f} h，较同网格名义值缩短{q3["meta"]["critical_h"]-hm:.4f} h。'
             f'第四问36 h虽已达到半径1.2000 cm，但最大含水率仍为{q4["at_36h"]["max_C"]:.4f} kg/kg，尚未达标。'
             f'附件1观测温度最大值为{report["inputs"]["observed_max_T"]:.4f} ℃，不能把50.2 ℃硬编码为风温上限。'
             '\n本组名义320/640区间临界时间差不足0.19 s；正文最终答案仍采用既有更细网格。'
             '粗细网格的微小差异可能跨过严格停机时间的0.0001 h上取整边界，不能把诊断表的粗网格严格时刻直接覆盖主答案。\n')
    (ROOT/'tables/pitfall_summary.tex').write_text(summary,encoding='utf8')
    md=['# 四问答案更新与避坑复核', '',
        '更新时间：2026-09-12。本轮不生成或编译PDF。', '',
        '## 结论', '',
        '**未发现需要推翻当前主模型及细网格主答案的数值证据。保留主答案，补充闭合假设、13条新复算轨迹、错误判停反证和独立解析特例；修正工作簿模板接口。**',
        '这不是“所有坑都不存在”：端面全程二维效应、潜热、气固平衡及密度闭合仍是已披露的物理限制。', '',
        '| 问题 | 模型与口径 | 当前主答案 | 本轮处理 |', '|---|---|---|---|',
        '| 一 | 端面绝热的一维径向；附录2，D仍随C变化 | 1800 s中心/表面T：33.5753/36.7856 ℃；C：2.5500/1.5102 | 640区间重新核对，保留1280区间锁定表 |',
        '| 二 | 全程统一附录3；从原初态联立求解 | 3 h中心/表面T：49.8495/49.9664 ℃；C：1.7662/1.0081 | 640区间重新核对；保留全过程逐秒两场输出 |',
        '| 三 | 同第二问；全域最大含水率事件 | 临界57.4740 h；严格停机57.4754 h | 名义320/640复算；增加外推/判据对照 |',
        '| 四 | 附录4；实测半径PCHIP；均匀收缩物质坐标 | 临界51.0885 h；严格停机51.0899 h；半径1.2000 cm | 名义320/640复算；增加线性插值/外推对照 |', '',
        '严格终点原始含水率分别为0.1499985335和0.1499974179 kg/kg；显示0.1500是四舍五入，不是将等号当成严格小于。临界时刻是可行集合的下确界，执行时刻另含5 s余量和向上舍入。', '',
        '## 新增同口径对照', '',
        '下表为本轮640区间实际计算的**临界时间**，并非主细网格答案或实验真值。', '',
        '| 4 h后环境 | 第四问半径插值 | 第三问/h | 第四问/h |', '|---|---|---:|---:|']
    for env,kind,c3,c4 in combos:
        md.append(f'| {env} | {kind} | {cases[c3]["meta"]["critical_h"]:.4f} | {cases[c4]["meta"]["critical_h"]:.4f} |')
    md += ['',f'- 第三问h_m加倍：{hm:.4f} h，缩短{q3["meta"]["critical_h"]-hm:.4f} h。',
           f'- 第四问仅由PCHIP改线性插值，临界时间增加{linear:.2f} s，不能将插值选择写成唯一标准。',
           '- “50/0.05”和“末点保持”都只是4 h之后的闭合，不是题目指定的长期观测。', '',
           '| 错误停止标准 | 第三问时刻/h | 当时全域max C | 第四问时刻/h | 当时全域max C |',
           '|---|---:|---:|---:|---:|']
    for mode,title in [('surface','只看表面'),('mean','只看干物质加权均值')]:
        a=q3['wrong_stop'][mode];b=q4['wrong_stop'][mode]
        md.append(f'| {title} | {a["time_h"]:.4f} | {a["actual_max_C"]:.4f} | {b["time_h"]:.4f} | {b["actual_max_C"]:.4f} |')
    md += ['', '**上表四种提前停止均不满足全域要求。**', '',
           '## 各问完整指定截面', '', '数表直接读取既有细网格机器答案；单位为℃或kg/kg，不由本轮640区间诊断值替换。域外位置用“域外”表示。']
    for answer in locked:
        q=answer['question']
        fields=[('temperature_C','温度'),('moisture','含水率')] if q<=2 else [('moisture','含水率')]
        for field,title in fields:
            md += ['',f'### 问题{q}：{title}', '',
                   '| 时间/'+('s' if q==1 else 'h')+' | 0 cm | 0.5 cm | 1 cm | 1.5 cm | '+('表面 | 半径/cm |' if q==4 else '2 cm |'),
                   '|---|---:|---:|---:|---:|---:|'+('---:|' if q==4 else '')]
            for row in answer['table_rows']:
                vals=row[field][:5] if q!=4 else row[field][:4]+[row[field][-1]]
                t=row['time_s'] if q==1 else row['time_s']/3600
                md.append('| '+f'{t:.4f}'+' | '+' | '.join('域外' if v is None else f'{v:.4f}' for v in vals)+' |'+(f' {row["radius_cm"]:.4f} |' if q==4 else ''))
    md += ['', '## 清单需要纠正的说法', '',
           f'1. 用℃误代Arrhenius指数会使D大幅变小。在50 ℃处，错误/正确比值为{report["celsius_error_ratio"]:.5e}，不是增大。',
           f'2. 附件1实际最大风温为{report["inputs"]["observed_max_T"]:.4f} ℃，不是50.2 ℃。',
           '3. 不能凭“约17 h”排他地诊断一种代码错误；必须查原式、边界、坐标及判据。',
           '4. result2仍保留完整过程的温度和水分逐秒数据，不能用只有含水率的result3替代。',
           '5. “未给潜热”不能证明潜热可忽略，未经闭合的655/118 W/m²比较也不能证明与题意矛盾。',
           '6. 隐式稳定、每秒输出、严格阈值与四位小数精度是不同概念；不能互相替代。', '',
           '## 验证与文件', '',
           f'- 本轮13条轨迹总脚本耗时{report["elapsed_s"]:.2f} s；全部返回成功。',
           f'- 新Q3/Q4名义干基收支相对残差：{q3["conservation"]["relative_residual"]:.3e}、{q4["conservation"]["relative_residual"]:.3e}。',
           '- Bessel阶跃导热九点对照：160/320区间最大误差0.0001296364/0.0000348449 ℃。这是常物性特例，不是实验验证。',
           '- 主稿：`main.tex`，新增论证：`pitfall_validation.tex`，新数表：`tables/pitfall_*.tex`。编译主稿时需保留整个源工程。',
           '- 修正版工作簿：`supplement/pitfall_audit/workbooks/result1.xlsx`至`result4.xlsx`。从已锁定细网格场直接重导出，未改PDE值；格式及所有指定截面回读见同目录`verification.json`。',
           '- 逐项审计：`audit/PITFALL_REVIEW.md`；新运行记录：`supplement/pitfall_audit/report.json`；完整锁定依据仍为项目`RESULTS_LOCK.md`。',
           '- 旧PDF、历史压缩包和submission没有更新。本轮未进行页面视觉验收；历史PDF报告不代表新TeX通过版面审查。', '']
    (ROOT/'答案更新_避坑复核.md').write_text('\n'.join(md),encoding='utf8')
    print('Generated three TeX tables and the answer Markdown from machine records')


if __name__=='__main__':
    main()
