"""Cold production reproduction of both closures, without result-cache reads."""
import argparse
import gc
import hashlib
import json
import platform
import time
from pathlib import Path

import numpy as np
import scipy
import openpyxl

from s2_solver import Settings, ROOT
from s2_stable_graded import StableModel
from latent_extension import LatentModel
from experiments import requested_table
from reproduce import workbook


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def verify_book(model, path, step, temperature):
    """Read every output row; independently compare sampled values to the solution."""
    book = openpyxl.load_workbook(path, read_only=True, data_only=True)
    expected_names = ['温度', '水分浓度'] if temperature else ['Sheet1']
    assert book.sheetnames == expected_names
    times = np.unique(np.r_[np.arange(step, model.end, step), model.end])
    distances = np.arange(20 if model.moving else 21)/10
    header = ['时间\\到药材中心的距离'] + distances.tolist()
    if model.moving:
        header += ['药材表面']
    sampled = 0
    for sheet in book:
        rows = iter(sheet.values)
        assert list(next(rows)) == header
        count = 0
        for count, row in enumerate(rows, 1):
            assert count <= len(times)
            t = times[count-1]
            assert abs(row[0]-t) < 1e-7
            assert len(row) == len(header)
            inside = distances/100 <= model.radius(t)
            if model.moving:
                inside = np.r_[inside, True]
            values = row[1:]
            assert all((v is not None) == bool(ok) for v, ok in zip(values, inside))
            assert all(np.isfinite(v) for v in values if v is not None)
            if sheet.title != '温度':
                assert all(v >= 0 for v in values if v is not None)
            if count == 1 or count == len(times) or count % 1800 == 0:
                y = model.state([t])[:, 0]
                field = y[:model.size] if sheet.title == '温度' else y[model.size:]
                expected = np.interp(distances/100/model.radius(t), model.x, field, right=np.nan)
                if model.moving:
                    expected = np.r_[expected, field[-1]]
                for value, target in zip(values, expected):
                    if np.isfinite(target):
                        assert abs(value-target) <= 5.00001e-5
                        sampled += 1
        assert count == len(times)
    book.close()
    return dict(ready=True, rows_per_sheet=len(times), sheets=expected_names,
                sampled_cells=sampled, sha256=digest(path),
                scope='Every row: time/domain/finite; sampled cells: unrounded trajectory')


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--workbooks', action='store_true')
    args = parser.parse_args()
    args.out.mkdir(parents=True, exist_ok=False)
    start = time.perf_counter()
    report = dict(ready=False, cache_read=False, workbooks_requested=args.workbooks,
                  python=platform.python_version(), numpy=np.__version__,
                  scipy=scipy.__version__, openpyxl=openpyxl.__version__,
                  inputs={p.name:digest(p) for p in sorted((ROOT/'data').glob('input*.xlsx'))},
                  code={p.name:digest(p) for p in sorted((ROOT/'code').glob('*.py'))}, cases={})
    for family, cls in [('baseline', StableModel), ('latent', LatentModel)]:
        folder = args.out/family
        folder.mkdir()
        cases = report['cases'][family] = {}
        for q in range(1, 5):
            n = 2560 if family == 'baseline' and q == 4 else 1280
            print(f'SOLVE {family} Q{q} N{n}', flush=True)
            model = cls(Settings(question=q, n=n)).run()
            row = dict(meta=model.meta, requested_rows=requested_table(model),
                       latent_heat=0 if family == 'baseline' else model.latent_heat)
            if q >= 3:
                row['max_C_at_end'] = float(model.state([model.end])[model.size:, 0].max())
                assert row['max_C_at_end'] < .15
            cases[str(q)] = row
            (folder/f'q{q}.json').write_text(json.dumps(row, ensure_ascii=False, indent=2), encoding='utf-8')
            print(f'SOLVED {family} Q{q}: {model.meta}', flush=True)
            if args.workbooks and q != 2:
                # Identical Q2/Q3 dynamics: Q3 supplies all Q2 times through strict completion.
                for output_q in ([2, 3] if q == 3 else [q]):
                    path = folder/f'result{output_q}.xlsx'
                    step = 1 if output_q <= 2 else 60
                    thermal = output_q <= 2
                    print(f'EXPORT {family} result{output_q}', flush=True)
                    info = workbook(model, path, step, thermal)
                    info['verification'] = verify_book(model, path, step, thermal)
                    cases[str(output_q)]['workbook'] = info
                    print(f'VERIFIED {family} result{output_q}: {info}', flush=True)
            del model
            gc.collect()
            (args.out/'progress.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    report.update(ready=True, exit_code=0, elapsed_s=time.perf_counter()-start)
    (args.out/'report.json').write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding='utf-8')
    print('PASS: eight fresh production solves; see report.json', flush=True)


if __name__ == '__main__':
    main()
