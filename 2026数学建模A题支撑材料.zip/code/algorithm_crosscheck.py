"""Fresh Radau solves against hash-verified production BDF records."""
import argparse
import gc
import hashlib
import json
import platform
import time
from pathlib import Path

import numpy as np
import scipy

from s2_solver import ROOT, Settings
from s2_stable_graded import StableModel
from latent_extension import LatentModel
from experiments import requested_table

CORE = ('s2_solver.py', 's2_stable_graded.py', 'latent_extension.py', 'experiments.py')


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')


def verify_bdf_identity():
    path = ROOT / 'runs/cold_dual_20260912/output/report.json'
    cold = json.loads(path.read_text(encoding='utf-8'))
    if not cold['ready'] or cold['exit_code'] != 0 or cold['cache_read']:
        raise ValueError('Historic BDF production did not pass its execution gate')
    for name in CORE:
        if digest(ROOT / 'code' / name) != cold['code'][name]:
            raise ValueError(f'Production core changed: {name}')
    for name, expected in cold['inputs'].items():
        if digest(ROOT / 'data' / name) != expected:
            raise ValueError(f'Production input changed: {name}')
    return cold, dict(report_sha256=digest(path), code={n: cold['code'][n] for n in CORE}, inputs=cold['inputs'])


def sample_like(model, rows):
    times = sorted({r['time_s'] for r in rows})
    states = model.state(times)
    index = {t: i for i, t in enumerate(times)}
    out = []
    for row in rows:
        t, p = row['time_s'], row['r_cm']
        radius = model.radius(t)
        inside = p == 'surface' or p/100 <= radius + 1e-12
        x = 1.0 if p == 'surface' else p/100/radius
        state = states[:, index[t]]
        out.append(dict(time_s=t, time_h=t/3600, r_cm=p, radius_cm=radius*100,
                        inside=bool(inside),
                        T_C=float(np.interp(x, model.x, state[:model.size])) if inside else None,
                        C_kg_kg=float(np.interp(x, model.x, state[model.size:])) if inside else None))
    return out


def compare(base, other):
    errors, mismatches, count = {'T_C': 0., 'C_kg_kg': 0.}, {'T_C': 0, 'C_kg_kg': 0}, 0
    for b, r in zip(base, other, strict=True):
        if (b['time_s'], b['r_cm'], b['inside']) != (r['time_s'], r['r_cm'], r['inside']):
            raise ValueError('Different sampling domain')
        for field in errors:
            if b[field] is None:
                if r[field] is not None:
                    raise ValueError('Undefined value replaced by a number')
            else:
                errors[field] = max(errors[field], abs(b[field] - r[field]))
                mismatches[field] += f'{b[field]:.4f}' != f'{r[field]:.4f}'
                count += 1
    return dict(max_absolute_difference=errors, four_decimal_mismatches=mismatches,
                finite_values=count, scope='Requested times/positions, not a continuous-field bound')


def run(out, smoke_n=None):
    out.mkdir(parents=True, exist_ok=False)
    cold, identity = verify_bdf_identity()
    report = dict(ready=False, identity=identity, python=platform.python_version(), scipy=scipy.__version__,
                  numpy=np.__version__, radau_cache_read=False, bdf_reference='fresh_smoke' if smoke_n else 'verified_cold_production',
                  production=smoke_n is None, cases={}, runner_sha256=digest(Path(__file__)))
    write(out / 'progress.json', report)
    started = time.perf_counter()
    for family, cls in [('baseline', StableModel), ('latent', LatentModel)]:
        for q in range(1, 5):
            name = f'{family}_q{q}'
            if smoke_n:
                bdf = cls(Settings(question=q, n=smoke_n)).run()
                baseline = dict(meta=bdf.meta, requested_rows=requested_table(bdf))
                del bdf
            else:
                path = ROOT / f'runs/cold_dual_20260912/output/{family}/q{q}.json'
                baseline = json.loads(path.read_text(encoding='utf-8'))
                if baseline['meta'] != cold['cases'][family][str(q)]['meta']:
                    raise ValueError('Per-case BDF record differs from run report')
            settings = dict(baseline['meta']['settings'], method='Radau')
            print(f'SOLVE {name} Radau N={settings["n"]}', flush=True)
            begin = time.perf_counter()
            model = cls(Settings(**settings)).run()
            own_meta = dict(model.meta)
            own_rows = requested_table(model)
            original_end = model.end
            common_end = max(r['time_s'] for r in baseline['requested_rows'])
            # Extend by an actual solve if the BDF display endpoint is later.
            # Never extrapolate Radau dense output past its solved interval.
            if common_end > model.end + 1e-8:
                initial = model.state([model.end])[:, 0]
                model.pieces.append(model._solve(model.end, common_end, initial))
                model.end = common_end
            matched = sample_like(model, baseline['requested_rows'])
            metrics = compare(baseline['requested_rows'], matched)
            metrics['critical_difference_s'] = None if q <= 2 else own_meta['critical_s']-baseline['meta']['critical_s']
            metrics['strict_difference_s'] = own_meta['end_s']-baseline['meta']['end_s']
            metrics['max_C_at_bdf_end'] = float(model.state([common_end])[model.size:, 0].max())
            metrics['adequate_for_table_comparison'] = (
                metrics['max_absolute_difference']['T_C'] < 1e-3
                and metrics['max_absolute_difference']['C_kg_kg'] < 1e-4
                and (q <= 2 or abs(metrics['critical_difference_s']) < 1.0))
            case = dict(bdf=baseline, radau_meta=own_meta, radau_own_requested_rows=own_rows,
                        radau_at_bdf_rows=matched, metrics=metrics,
                        continuation_s=max(0., common_end-original_end), elapsed_s=time.perf_counter()-begin)
            write(out / f'{name}.json', case)
            report['cases'][name] = dict(file=f'{name}.json', sha256=digest(out / f'{name}.json'),
                                        n=settings['n'], metrics=metrics, elapsed_s=case['elapsed_s'])
            write(out / 'progress.json', report)
            print(f'DONE {name}: {metrics}; elapsed={case["elapsed_s"]:.1f}s', flush=True)
            del model
            gc.collect()
    report.update(ready=True, exit_code=0, elapsed_s=time.perf_counter()-started)
    report['comparison_gate'] = all(c['metrics']['adequate_for_table_comparison'] for c in report['cases'].values())
    write(out / 'report.json', report)
    print(f'FINISHED: {len(report["cases"])} Radau runs; comparison_gate={report["comparison_gate"]}', flush=True)
    return report


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--out', required=True, type=Path)
    parser.add_argument('--smoke-n', type=int)
    args = parser.parse_args()
    run(args.out, args.smoke_n)
