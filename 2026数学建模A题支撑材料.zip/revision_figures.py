"""Deterministic diagrams and actual supplementary experiment plots."""
from pathlib import Path
import json
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Rectangle

ROOT = Path(__file__).resolve().parent
FIG = ROOT/'figures'
plt.rcParams.update({'font.family': 'sans-serif', 'font.sans-serif': ['Microsoft YaHei'],
    'font.size': 10, 'axes.unicode_minus': False, 'svg.fonttype': 'none',
    'pdf.fonttype': 42, 'axes.spines.top': False, 'axes.spines.right': False,
    'axes.linewidth': .65, 'lines.linewidth': 1.4, 'legend.frameon': False})
COL = {'input':'#E8EEDB','model':'#DBE7F0','solve':'#FBEDCE',
       'check':'#E4E0EF','output':'#F4DFDA','ink':'#304044','green':'#247F78','red':'#B45249'}


def save(fig, name):
    for ext in ('svg','pdf','png'):
        fig.savefig(FIG/f'{name}.{ext}', dpi=450, facecolor='white')
    plt.close(fig)


def canvas(height):
    fig = plt.figure(figsize=(155/25.4,height/25.4))
    ax = fig.add_axes([0,0,1,1], xlim=(0,155), ylim=(0,height))
    ax.axis('off')
    return fig, ax


def box(ax,x,y,w,h,label,kind='model',fs=9):
    ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0.15,rounding_size=.7',
                              lw=.55,ec='#899697',fc=COL[kind]))
    ax.text(x+w/2,y+h/2,label,ha='center',va='center',fontsize=fs,color=COL['ink'],linespacing=1.35)


def arrow(ax,start,end):
    ax.add_patch(FancyArrowPatch(start,end,arrowstyle='-|>',mutation_scale=7,lw=.65,color='#737E80'))


QUESTIONS = [
 ('问题一', '附录2物性 · 环境观测 · 均匀初态',
  ['径向热传导','含水率相关扩散','中心与表面边界','传递时间尺度'],
  ['显热收支','非线性通量','Robin交换','Biot / Fourier数'],
  '环形控制体守恒离散 + 表层加密 + BDF刚性积分',
  ['零维模型对照','系数扰动 / 端面诊断','网格误差 / 水热收支'],
  '七时刻 × 五位置表；逐秒温度与含水率'),
 ('问题二', '附录3统一公式 · 从初态重新开始',
  ['温度影响扩散','含水率改变物性','强退化状态积分','环境时序插值'],
  ['Arrhenius项','热容量与导热率','近状态高斯积分','观测区间线性插值'],
  '两场联立有效模型 + 稀疏Jacobian + 自适应积分',
  ['冻结物性实算对照','三系数扰动检验','全程逐秒网格复核'],
  '前3小时截面表；全过程逐秒数据与第三问同源'),
 ('问题三', '完整继承问题二动力系统 · 全域阈值0.15',
  ['全空间最大值','首次向下过阈值','后期薄层误差','外推环境不确定性'],
  ['不以均值判停','连续输出事件','三种数值方案','八个压力角点'],
  '临界时间定位 → 继续积分 → 未舍入严格可行检查',
  ['网格 / 事件误差','同一停机时间回代','情景范围与代价'],
  '名义严格停机；每6小时截面；有限情景停机'),
 ('问题四', '附录4独立物性 · 实测半径 · 干基状态',
  ['干物质连续性','水分连续性','随固体坐标','半径保形插值'],
  ['固体运动测度','相对扩散通量','坐标项相消','禁止无依据外推'],
  '固定物质网格求解 + 实际表面读取 + 域外掩膜',
  ['材料制造解 / 收支','物性×几何四格对照','八角点统一停机'],
  '收缩模型停机；变域截面；有条件的效应归因')]


def workflows():
    for q,(_,inp,top,bottom,solve,checks,out) in enumerate(QUESTIONS,1):
        fig,ax=canvas(91)
        box(ax,24,79,107,10,inp,'input',10)
        for i in range(4):
            x=3+i*38
            box(ax,x,60,35,10,top[i],'model',9.3)
            box(ax,x,45,35,10,bottom[i],'solve',8.9)
            arrow(ax,(77.5,79),(x+17.5,70))
            arrow(ax,(x+17.5,60),(x+17.5,55))
            arrow(ax,(x+17.5,45),(77.5,39))
        box(ax,10,28,135,11,solve,'model',9.2)
        for i in range(3):
            x=3+i*51
            box(ax,x,12,47,10,checks[i],'check',8.8)
            arrow(ax,(77.5,28),(x+23.5,22))
            arrow(ax,(x+23.5,12),(77.5,8))
        box(ax,10,.5,135,7.5,out,'output',9)
        save(fig,f'q{q}_flow')
    fig,ax=canvas(173)
    for q,(title,inp,top,bottom,solve,checks,out) in enumerate(QUESTIONS):
        y=132-q*43
        ax.add_patch(Rectangle((1,y),153,37,fill=False,ec='#ACBABB',lw=.65,linestyle=(0,(3,2))))
        box(ax,3,y+2,14,33,title.replace('问题','问题\n'),'input',10)
        box(ax,21,y+27,129,8,inp,'input',9)
        for j,label in enumerate(top):
            x=21+j*33
            box(ax,x,y+14,30,8,label,'model',8.5)
            arrow(ax,(85.5,y+27),(x+15,y+22))
        box(ax,21,y+2,81,8,['环形控制体守恒离散','两场联立有效模型','全空间事件 + 严格可行回代','固定物质网格求解'][q],'solve',8.8)
        box(ax,108,y+2,42,8,['两场输出与端面诊断','全场输出与扰动检验','严格判停与情景回代','变域输出与四格归因'][q],'output',8.5)
        for j in range(4): arrow(ax,(36+j*33,y+14),(61.5,y+10))
        arrow(ax,(102,y+6),(108,y+6))
        if q<3:
            ax.text(85, y-1, ['不同物性，独立重新初始化','相同动力系统，增加终止判据','独立物性与收缩闭合，不直接继承数值'][q],
                    ha='center',va='top',fontsize=7.8,color='#596568')
    save(fig,'overview')


def control_volume():
    fig,ax=canvas(64)
    ax.text(3,60,'(a) 共享界面通量与环形控制体',fontsize=10,weight='bold')
    for i in range(3):
        box(ax,5+i*23,27,22,18,[r'$C_{i-1}$',r'$C_i$',r'$C_{i+1}$'][i],'input' if i!=1 else 'solve',11)
    for x in (28,51):
        arrow(ax,(x-7,50),(x+7,50))
    ax.text(28,54,r'$J_{i-1/2}$',ha='center',fontsize=9)
    ax.text(51,54,r'$J_{i+1/2}$',ha='center',fontsize=9)
    ax.text(39,21,r'$w_i=(\eta_{i+1/2}^2-\eta_{i-1/2}^2)/2$',ha='center',fontsize=9)
    ax.text(39,9,'共享一次通量，左右相反入账\n全域求和后只剩边界交换',ha='center',va='center',fontsize=9)
    ax.plot([79,79],[4,60],color='#C5CECE',lw=.6)
    ax.text(83,60,'(b) 同一物质点的几何映射',fontsize=10,weight='bold')
    ax.plot([88,150],[44,44],color=COL['ink'])
    ax.plot([88,127],[26,26],color=COL['ink'])
    for eta in (0,.25,.5,.75,1):
        a,b=88+62*eta,88+39*eta
        ax.plot(a,44,'o',ms=3,color=COL['green'])
        ax.plot(b,26,'o',ms=3,color=COL['green'])
        arrow(ax,(a,42),(b,28))
    ax.text(119,49,r'$r=\eta R(0)$',ha='center',fontsize=10)
    ax.text(111,20,r'$r=\eta R(t)$',ha='center',fontsize=10)
    ax.text(117,7,'固定物质坐标η，不额外增加失水项',ha='center',fontsize=8.8)
    save(fig,'control_volume')


def diagnostic_figures():
    p=ROOT/'supplement/SUMMARY.json'
    if not p.exists(): return
    data=json.loads(p.read_text(encoding='utf8'))
    for q in (1,2):
        fig,axes=plt.subplots(1,2,figsize=(155/25.4,63/25.4),layout='constrained')
        rows=[r for r in data['sensitivity'] if r['question']==q]
        for ax,metric,label in zip(axes,['Ts','Cmean'],['表面温度变化 / ℃','平均含水率变化 / (kg/kg)']):
            for y,row in enumerate(rows):
                d=row[metric]
                for key,marker,color in [('minus','o',COL['green']),('plus','s',COL['red'])]:
                    val=d[key]-d['base']
                    ax.plot([0,val],[y,y],color=color,alpha=.6,lw=1)
                    ax.scatter(val,y,s=26,marker=marker,color=color,label=('-10%' if key=='minus' else '+10%') if y==0 else None)
            ax.axvline(0,lw=.7,color='#606D70',ls='--')
            ax.set_yticks(range(3),['扩散倍率','换热系数','传质系数'],fontsize=9)
            ax.set_xlabel(label,fontsize=9)
            ax.tick_params(labelsize=8)
            ax.set_ylim(-.6,2.7)
        axes[1].legend(fontsize=8,ncol=2,loc='upper center')
        save(fig,f'q{q}_sensitivity')
    base=json.loads((ROOT/'supplement/q1_base.json').read_text())
    lump=json.loads((ROOT/'supplement/q1_lumped.json').read_text())
    fig,ax=plt.subplots(figsize=(155/25.4,59/25.4),layout='constrained')
    for key,label,color,ls in [('Tc','径向模型：中心','#247F78','-'),('Ts','径向模型：表面','#B45249','-'),
                               ('Tmean','径向模型：体积均温','#677582','--')]:
        ax.plot(base['time_s'],base[key],label=label,color=color,ls=ls)
    ax.plot(lump['time_s'],lump['T'],label='集中参数：均温',color='#996F32',ls=':')
    ax.set(xlabel='时间 / s',ylabel='温度 / ℃',xlim=(0,1800))
    ax.legend(fontsize=8.5,ncol=2)
    save(fig,'q1_physical_compare')


def tables():
    p=ROOT/'supplement/SUMMARY.json'
    if not p.exists(): return
    s=json.loads(p.read_text())
    for q in (1,2):
        rows=[r for r in s['sensitivity'] if r['question']==q]
        text=[r'\begin{table}[htbp]\centering\small',
              rf'\caption{{问题{q}终点的单因素扰动结果（160区间诊断）}}\label{{tab:sensitivity{q}}}',
              r'\begin{tabular}{llrrrr}\toprule',
              r'参数 & 倍率 & $T_c$/℃ & $T_s$/℃ & $C_c$ & $\bar C$\\\midrule']
        for row,name in zip(rows,['扩散系数','换热系数','传质系数']):
            for k,mult in [('minus',.9),('plus',1.1)]:
                vals=' & '.join(f"{row[z][k]:.4f}" for z in ('Tc','Ts','Cc','Cmean'))
                text.append(f'{name} & {mult:.1f} & {vals}'+r'\\')
        text += [r'\bottomrule\end{tabular}',r'\par\smallskip\footnotesize 含水率单位为kg/kg；每行仅改变一项系数，其余条件不变。',r'\end{table}']
        (ROOT/f'tables/q{q}_sensitivity.tex').write_text('\n'.join(text),encoding='utf8')
    c=s['comparison']
    text=[r'\begin{table}[htbp]\centering\small',
          r'\caption{问题二冻结与变物性的同网格终点对照}\label{tab:frozen}',
          r'\begin{tabular}{lrrrr}\toprule 模型 & $T_c$/℃ & $T_s$/℃ & $C_c$ & $C_s$\\\midrule']
    for key,label in [('q2_frozen','初态冻结物性'),('q2_variable_uniform','统一变物性')]:
        text.append(label+' & '+' & '.join(f'{c[key][k]:.4f}' for k in ('Tc','Ts','Cc','Cs'))+r'\\')
    text += [r'\bottomrule\end{tabular}',r'\par\smallskip\footnotesize 两者均为160区间均匀网格、相同初边值；终点3 h。含水率单位kg/kg。',r'\end{table}']
    (ROOT/'tables/q2_frozen.tex').write_text('\n'.join(text),encoding='utf8')


if __name__=='__main__':
    workflows()
    control_volume()
    diagnostic_figures()
    tables()
