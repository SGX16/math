/* Online ECharts editor export. Source values remain in the local browser. */
const fs=require('fs'),path=require('path'),crypto=require('crypto');
let pw;try {pw=require('playwright');} catch(e){pw=require(path.join(process.env.USERPROFILE,'.cache/codex-runtimes/codex-primary-runtime/dependencies/node/node_modules/playwright'));}
const ROOT=__dirname;
const hash=p=>crypto.createHash('sha256').update(fs.readFileSync(p)).digest('hex');
(async()=>{
  const source=path.join(ROOT,'evidence/improvement.json');
  const t=JSON.parse(fs.readFileSync(source,'utf8')).factorial.times_h;
  const fixed=[[t.p4_moving0,0],[t.p3_moving0,1]];
  const moving=[[t.p4_moving1,0],[t.p3_moving1,1]];
  const option={animation:false,backgroundColor:'#ffffff',
    textStyle:{fontFamily:'Microsoft YaHei',fontSize:22,color:'#252B30'},
    legend:{data:['固定半径','收缩半径'],top:13,left:'center',itemWidth:27,itemHeight:17,
      itemGap:36,textStyle:{fontSize:22,fontFamily:'Microsoft YaHei'}},
    grid:{left:166,right:90,top:100,bottom:90},
    xAxis:{type:'value',min:0,max:140,interval:20,name:'临界干燥时间 / h',nameLocation:'middle',nameGap:48,
      nameTextStyle:{fontSize:23},axisLabel:{fontSize:21,color:'#333'},axisLine:{show:true,lineStyle:{color:'#657078'}},
      splitLine:{lineStyle:{color:'#E4E8EB',type:'dashed'}}},
    yAxis:{type:'category',data:['附录4物性','附录3物性'],axisTick:{show:false},axisLine:{show:false},
      axisLabel:{fontSize:23,margin:24,color:'#252B30'}},
    series:[0,1].map(i=>({type:'line',data:[moving[i],fixed[i]],symbol:'none',silent:true,
      lineStyle:{color:'#A4AFB5',width:3},z:1})).concat([
      {name:'固定半径',type:'scatter',data:fixed,symbol:'circle',symbolSize:18,
        itemStyle:{color:'#fff',borderColor:'#56636B',borderWidth:3},
        label:{show:true,position:'top',distance:15,fontSize:23,color:'#414A50',formatter:p=>p.value[0].toFixed(4)}},
      {name:'收缩半径',type:'scatter',data:moving,symbol:'diamond',symbolSize:21,
        itemStyle:{color:'#286378'},label:{show:true,position:'bottom',distance:15,fontSize:23,
          color:'#286378',formatter:p=>p.value[0].toFixed(4)}}])};
  const code='option = '+JSON.stringify(option,(k,v)=>typeof v==='function'?'__FORMATTER__':v,2)
    .replaceAll('"__FORMATTER__"','function(p){return p.value[0].toFixed(4)}')+';';
  fs.mkdirSync(path.join(ROOT,'audit'),{recursive:true});
  fs.writeFileSync(path.join(ROOT,'audit/factorial_online_option.js'),code);
  const browser=await pw.chromium.launch({channel:'msedge',headless:true});
  try{
    const page=await browser.newPage({viewport:{width:1400,height:950},deviceScaleFactor:2});
    const url='https://echarts.apache.org/examples/en/editor.html?c=line-simple';
    await page.goto(url,{waitUntil:'domcontentloaded',timeout:45000});
    await page.waitForFunction(()=>window.ace&&document.getElementById('code-panel'),null,{timeout:30000});
    await page.waitForTimeout(5000);
    await page.evaluate(code=>ace.edit('code-panel').setValue(code,-1),code);
    await page.getByText('Run',{exact:true}).click();
    await page.waitForTimeout(6000);
    const frame=page.frames().find(f=>f!==page.mainFrame());
    const actual=await frame.evaluate(()=>{
      const el=document.getElementById('chart-container');
      const chart=echarts.getInstanceByDom(el);
      return chart.getOption().series.filter(x=>x.type==='scatter').map(x=>({name:x.name,data:x.data}));
    });
    if(JSON.stringify(actual.map(x=>x.data))!==JSON.stringify([fixed,moving])) throw Error('Website source-data mismatch');
    await page.screenshot({path:path.join(ROOT,'audit/factorial_website.png')});
    const exported=await frame.evaluate(()=>{
      const el=document.getElementById('chart-container'),old=echarts.getInstanceByDom(el),opt=old.getOption();
      old.dispose();el.style.width='1100px';el.style.height='560px';
      const chart=echarts.init(el,null,{renderer:'svg',width:1100,height:560});chart.setOption(opt);
      return {svg:chart.renderToSVGString(),version:echarts.version};
    });
    fs.writeFileSync(path.join(ROOT,'figures/factorial_online.svg'),exported.svg);
    const preview=await browser.newPage({viewport:{width:1100,height:560},deviceScaleFactor:3});
    await preview.setContent('<html><head><style>@page{margin:0}html,body{margin:0;width:100%;height:100%}svg{width:100%;height:100%;display:block}</style></head><body>'+exported.svg+'</body></html>');
    await preview.screenshot({path:path.join(ROOT,'figures/factorial_online.png')});
    await preview.pdf({path:path.join(ROOT,'figures/factorial_online.pdf'),width:'155mm',height:'78.91mm',printBackground:true,margin:{top:0,right:0,bottom:0,left:0}});
    fs.writeFileSync(path.join(ROOT,'audit/WEBSITE_EXPORT.json'),JSON.stringify({url,date:new Date().toISOString(),
      tool:'Apache ECharts online editor, Edge headless',version:exported.version,
      input_sha256:hash(source),data:actual,stages:{access:true,editor_config:true,run:true,visible:true,export:true,numeric_check:true},
      export:['svg','pdf','png'],effective_png_dpi:3300/155*25.4,
      note:'Editor code executed in official website iframe; no Share/publish or raw attachment upload.'},null,2));
    console.log('Online ECharts data and SVG/PDF/PNG exports verified.');
  }finally{await browser.close();}
})().catch(e=>{console.error(e);process.exitCode=1});
