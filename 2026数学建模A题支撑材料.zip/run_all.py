"""Reproducible primary answers, tests and deterministic manuscript figures."""
from pathlib import Path
import argparse
import datetime
import hashlib
import json
import platform
import subprocess
import sys
import time

ROOT=Path(__file__).resolve().parent


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--mode',choices=['smoke','full'],default='smoke')
    p.add_argument('--out',type=Path)
    p.add_argument('--redraw',action='store_true')
    args=p.parse_args()
    out=(args.out or ROOT/'runs'/datetime.datetime.now().strftime('%Y%m%d_%H%M%S')).resolve()
    out.mkdir(parents=True,exist_ok=False)
    log=[]
    def run(parts,name):
        command=[sys.executable,'-X','utf8',*parts]; start=time.perf_counter()
        with (out/f'{name}.log').open('w',encoding='utf8') as stream:
            result=subprocess.run(command,cwd=ROOT,stdout=stream,stderr=subprocess.STDOUT)
        log.append(dict(command=command,exit_code=result.returncode,seconds=time.perf_counter()-start))
        (out/'execution.json').write_text(json.dumps(log,indent=2),encoding='utf8')
        if result.returncode: raise RuntimeError(f'{name} failed; inspect log; no success report issued')
        print(name,'PASS',flush=True)
    inputs={str(x.relative_to(ROOT)):hashlib.sha256(x.read_bytes()).hexdigest()
            for x in (ROOT/'data').glob('*.xlsx')}
    (out/'environment.json').write_text(json.dumps(dict(python=platform.python_version(),
        platform=platform.platform(),inputs=inputs,seed='not applicable: deterministic PDE'),indent=2),encoding='utf8')
    run(['-m','unittest','discover','-s','code','-p','test_revision.py','-v'],'tests')
    run(['code/reproduce.py','--mode',args.mode,'--out',str(out)],'calculation')
    if args.mode=='full': run(['code/verify_reproduction.py','--out',str(out)],'verification')
    if args.redraw:
        for script in ('redraw.py','revision_figures.py','engineering_figures.py'):
            run([script],Path(script).stem)
    print('Output:',out)


if __name__=='__main__':
    main()
